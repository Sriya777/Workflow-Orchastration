const { Pool } = require('pg');
const pool = new Pool({ user: 'postgres', host: 'localhost', database: 'task_manager', password: 'postgres', port: 5432 });
async function seed() {
  try {
    await pool.query('CREATE TABLE IF NOT EXISTS my_users (id SERIAL PRIMARY KEY, name VARCHAR(100));');
    await pool.query('TRUNCATE TABLE my_users;');
    await pool.query('INSERT INTO my_users (name) VALUES (\'Lakshmi\'), (\'Kiran\'), (\'John\');');
    console.log('Successfully seeded task_manager database with my_users table!');
  } catch (err) {
    console.error(err);
  } finally {
    await pool.end();
  }
}
seed();
