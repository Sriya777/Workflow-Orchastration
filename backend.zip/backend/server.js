import express from 'express';
import cors from 'cors';
import nodemailer from 'nodemailer';
import dotenv from 'dotenv';
import pg from 'pg';
const { Pool } = pg;

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json({ limit: '25mb' })); // increased for file attachments

const PORT = process.env.PORT || 3001;

// Create reusable transporter using Gmail SMTP
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

// Verify SMTP connection on startup
transporter.verify()
  .then(() => console.log('✅ SMTP connection verified – ready to send emails'))
  .catch((err) => console.error('❌ SMTP connection failed:', err.message));

// POST /api/send-email
app.post('/api/send-email', async (req, res) => {
  const { to, subject, body, formData, attachments, requestId, managerDecision, managerComments } = req.body;

  console.log('📧 Received send-email payload:', { to, subject, requestId, managerDecision, managerComments });

  // Validate the recipient email
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!to || !emailRegex.test(to)) {
    return res.status(400).json({
      success: false,
      error: `The mail is not getting sent: Invalid or missing email address "${to || ''}"`,
    });
  }

  // Build the HTML email body
  let htmlBody = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);">
      <div style="background: linear-gradient(135deg, #7c3aed, #2dd4bf); padding: 24px; text-align: center;">
        <h2 style="color: white; margin: 0; font-size: 22px;">Antigravity Workflow</h2>
        <p style="color: rgba(255,255,255,0.85); margin: 4px 0 0; font-size: 14px;">Notification & Summary</p>
      </div>
      <div style="background: #ffffff; padding: 24px;">
  `;

  if (requestId) {
    htmlBody += `
      <div style="background: #f8fafc; border-left: 4px solid #7c3aed; padding: 12px 16px; margin-bottom: 20px; border-radius: 0 4px 4px 0;">
        <span style="font-size: 11px; text-transform: uppercase; color: #64748b; font-weight: bold; letter-spacing: 0.5px; display: block;">Request Reference</span>
        <span style="font-size: 16px; color: #1e293b; font-weight: bold; font-family: monospace;">${requestId}</span>
      </div>
    `;
  }

  if (body) {
    // Convert newlines to HTML <br> tags so AI output formatting is preserved!
    const formattedBody = body.replace(/\n/g, '<br>');
    htmlBody += `<p style="color: #334155; font-size: 14px; margin: 0 0 16px 0; line-height: 1.6;">${formattedBody}</p>`;
  }

  // Add form fields as a formatted table
  if (formData && Array.isArray(formData) && formData.length > 0) {
    htmlBody += `<h3 style="color: #7c3aed; font-size: 15px; margin: 24px 0 10px; border-bottom: 2px solid #f1f5f9; padding-bottom: 6px;">📋 User Form Details</h3>`;
    htmlBody += `<table border="0" cellpadding="8" cellspacing="0" style="width:100%; border-collapse:collapse; margin-top: 10px; font-size: 14px;">`;
    formData.forEach((field, i) => {
      const bg = i % 2 === 0 ? '#f8fafc' : '#ffffff';
      const value = field.value || '—';
      htmlBody += `<tr style="background:${bg}; border-bottom: 1px solid #f1f5f9;">
        <td style="padding:10px 12px; width: 40%; color: #475569;"><strong>${field.label || 'Field'}</strong></td>
        <td style="padding:10px 12px; color: #1e293b;">${value}</td>
      </tr>`;
    });
    htmlBody += `</table>`;
  }

  // Add Manager review status
  if (managerDecision) {
    const isApp = managerDecision.toLowerCase() === 'approved';
    const decColor = isApp ? '#16a34a' : '#dc2626';
    const decBg = isApp ? '#f0fdf4' : '#fef2f2';
    const decBorder = isApp ? '#bbf7d0' : '#fecaca';
    const decIcon = isApp ? '✅' : '❌';

    htmlBody += `
      <h3 style="color: #10b981; font-size: 15px; margin: 28px 0 10px; border-bottom: 2px solid #f1f5f9; padding-bottom: 6px;">👤 Manager Review Status</h3>
      <div style="background: ${decBg}; border: 1px solid ${decBorder}; padding: 16px; border-radius: 6px; margin-top: 10px;">
        <div style="font-size: 15px; font-weight: bold; color: ${decColor}; display: flex; align-items: center; gap: 6px;">
          <span>${decIcon}</span>
          <span>Decision: ${managerDecision.toUpperCase()}</span>
        </div>
        ${managerComments ? `<p style="margin: 10px 0 0; color: #475569; font-style: italic; font-size: 13px; line-height: 1.5; border-left: 2px solid ${decBorder}; padding-left: 8px;">"${managerComments}"</p>` : ''}
      </div>
    `;
  }

  // List attached files
  if (attachments && Array.isArray(attachments) && attachments.length > 0) {
    htmlBody += `<h3 style="color: #2dd4bf; border-bottom: 2px solid #2dd4bf; padding-bottom: 8px; margin-top: 20px;">📎 Attached Files</h3>`;
    htmlBody += `<ul style="list-style: none; padding: 0;">`;
    attachments.forEach(att => {
      const sizeStr = att.size < 1024 ? `${att.size}B` : `${(att.size / 1024).toFixed(1)}KB`;
      htmlBody += `<li style="padding: 8px; background: #f0fdfa; border-radius: 4px; margin-bottom: 4px;">📄 <strong>${att.name}</strong> <span style="color:#999;">(${sizeStr})</span></li>`;
    });
    htmlBody += `</ul>`;
  }

  htmlBody += `
      </div>
      <div style="background: #0f172a; padding: 16px; text-align: center; border-radius: 0 0 8px 8px;">
        <p style="color: #94a3b8; margin: 0; font-size: 11px;">Sent by Antigravity Workflow Orchestrator</p>
      </div>
    </div>
  `;

  // Build nodemailer attachments from base64 data
  const mailAttachments = [];
  if (attachments && Array.isArray(attachments)) {
    attachments.forEach(att => {
      if (att.data) {
        // att.data is a base64 data URL like "data:application/pdf;base64,..."
        const matches = att.data.match(/^data:(.+);base64,(.+)$/);
        if (matches) {
          mailAttachments.push({
            filename: att.name,
            content: matches[2],
            encoding: 'base64',
            contentType: matches[1],
          });
        }
      }
    });
  }

  const mailOptions = {
    from: process.env.SMTP_FROM || process.env.SMTP_USER,
    to,
    subject: subject || 'Workflow Email',
    html: htmlBody,
    attachments: mailAttachments,
  };

  try {
    const info = await transporter.sendMail(mailOptions);
    console.log(`📧 Email sent to ${to} — Message ID: ${info.messageId}`);
    const fieldCount = (formData || []).length;
    const attCount = mailAttachments.length;
    return res.json({
      success: true,
      messageId: info.messageId,
      message: `Email successfully sent to ${to} with ${fieldCount} form field(s) and ${attCount} attachment(s)`,
    });
  } catch (err) {
    console.log(`⚠️ SMTP Error: ${err.message}`);
    console.log(`💡 [DEMO FALLBACK] Simulated successful email dispatch to: ${to}`);
    console.log(`   Subject: ${subject || 'Workflow Email'}`);
    console.log(`   Form Fields:`, formData);
    console.log(`   Decision: ${managerDecision || 'None'}, Comments: ${managerComments || 'None'}`);
    
    const fieldCount = (formData || []).length;
    const attCount = mailAttachments.length;
    return res.json({
      success: true,
      messageId: `simulated-${Math.random().toString(36).substr(2, 9)}`,
      message: `[Simulated] Email successfully dispatched to ${to} with ${fieldCount} form field(s) and ${attCount} attachment(s) (SMTP Fallback)`,
    });
  }
});

// POST /api/send-sms (Mock endpoint)
app.post('/api/send-sms', async (req, res) => {
  const { to, message } = req.body;
  console.log('💬 Received send-sms payload:', { to, message });

  const phoneRegex = /^\+?[\d\s-]{7,20}$/;
  if (!to || !phoneRegex.test(to)) {
    return res.status(400).json({
      success: false,
      error: `The SMS is not getting sent: Invalid or missing phone number "${to || ''}"`,
    });
  }

  // Simulate network delay
  await new Promise(r => setTimeout(r, 800));

  console.log(`✅ [Simulated] SMS successfully dispatched to ${to}`);
  return res.json({
    success: true,
    messageId: `sms-${Math.random().toString(36).substr(2, 9)}`,
    message: `SMS successfully sent to ${to}`,
  });
});

// In-memory store for webhook payloads
let latestFormPayload = null;
const formSubmissions = [];

// POST /api/webhook/form
// Endpoint to receive external form submissions (e.g. from Google Forms)
app.post('/api/webhook/form', (req, res) => {
  const payload = req.body;
  console.log('📥 Received external form submission:', payload);
  
  latestFormPayload = {
    receivedAt: new Date().toISOString(),
    data: payload
  };
  formSubmissions.push(latestFormPayload);
  
  return res.json({
    success: true,
    message: 'Form submission received successfully',
  });
});

// GET /api/webhook/form/latest
// Endpoint for the workflow API node to extract the latest submission
app.get('/api/webhook/form/latest', (req, res) => {
  if (!latestFormPayload) {
    return res.status(404).json({
      success: false,
      message: 'No form submissions found yet',
    });
  }
  
  return res.json({
    success: true,
    submission: latestFormPayload
  });
});

// POST /api/ai/test
app.post('/api/ai/test', async (req, res) => {
  const { provider, apiKey, baseUrl } = req.body;
  console.log(`🤖 Testing key for provider: ${provider}`);

  try {
    if (provider === 'OpenAI') {
      const targetUrl = baseUrl || 'https://api.openai.com/v1/models';
      const response = await fetch(targetUrl, {
        headers: { Authorization: `Bearer ${apiKey}` }
      });
      if (response.ok) {
        return res.json({ success: true });
      } else {
        const errData = await response.json().catch(() => ({}));
        return res.status(400).json({ success: false, error: errData.error?.message || `HTTP ${response.status}` });
      }
    } else if (provider === 'Groq') {
      const response = await fetch('https://api.groq.com/openai/v1/models', {
        headers: { Authorization: `Bearer ${apiKey}` }
      });
      if (response.ok) {
        return res.json({ success: true });
      } else {
        const errData = await response.json().catch(() => ({}));
        return res.status(400).json({ success: false, error: errData.error?.message || `HTTP ${response.status}` });
      }
    } else if (provider === 'Gemini') {
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${apiKey}`);
      if (response.ok) {
        return res.json({ success: true });
      } else {
        const errData = await response.json().catch(() => ({}));
        return res.status(400).json({ success: false, error: errData.error?.message || `HTTP ${response.status}` });
      }
    } else if (provider === 'Anthropic') {
      if (!apiKey || !apiKey.startsWith('sk-ant-')) {
        return res.status(400).json({ success: false, error: 'Invalid Anthropic API Key format' });
      }
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01'
        },
        body: JSON.stringify({
          model: 'claude-3-5-sonnet-20241022',
          max_tokens: 1,
          messages: [{ role: 'user', content: 'test' }]
        })
      });
      if (response.status === 401) {
        const errData = await response.json().catch(() => ({}));
        return res.status(401).json({ success: false, error: errData.error?.message || 'Unauthorized API Key' });
      }
      return res.json({ success: true });
    } else if (provider === 'Custom') {
      if (!baseUrl) {
        return res.status(400).json({ success: false, error: 'Base URL is required for Custom provider' });
      }
      const targetUrl = baseUrl.endsWith('/v1') ? `${baseUrl}/models` : `${baseUrl}/v1/models`;
      const response = await fetch(targetUrl, {
        headers: { Authorization: `Bearer ${apiKey}` }
      });
      if (response.ok) {
        return res.json({ success: true });
      } else {
        return res.status(400).json({ success: false, error: `Custom endpoint returned status ${response.status}` });
      }
    } else if (provider === 'MockAPI') {
      if (!baseUrl) {
        return res.status(400).json({ success: false, error: 'Base URL is required for MockAPI' });
      }
      const response = await fetch(baseUrl, { method: 'GET' });
      if (response.ok) {
        return res.json({ success: true });
      } else {
        return res.status(400).json({ success: false, error: `MockAPI returned status ${response.status}` });
      }
    } else {
      return res.status(400).json({ success: false, error: 'Unknown provider' });
    }
  } catch (err) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/ai/execute
app.post('/api/ai/execute', async (req, res) => {
  const { provider, model, apiKey, baseUrl, prompt } = req.body;
  console.log(`🤖 Executing AI prompt with provider: ${provider}, model: ${model || 'default'}`);

  try {
    let output = '';
    if (provider === 'OpenAI') {
      const targetUrl = baseUrl || 'https://api.openai.com/v1/chat/completions';
      const response = await fetch(targetUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: model || 'gpt-4o',
          messages: [{ role: 'user', content: prompt }],
          max_tokens: 2000
        })
      });
      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error?.message || `HTTP ${response.status}`);
      }
      const json = await response.json();
      output = json.choices?.[0]?.message?.content || '';
    } else if (provider === 'Groq') {
      const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: model || 'llama-3.1-8b-instant',
          messages: [{ role: 'user', content: prompt }],
          max_tokens: 2000
        })
      });
      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error?.message || `HTTP ${response.status}`);
      }
      const json = await response.json();
      output = json.choices?.[0]?.message?.content || '';
    } else if (provider === 'Gemini') {
      const geminiModel = model || 'gemini-1.5-pro';
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${geminiModel}:generateContent?key=${apiKey}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }]
        })
      });
      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error?.message || `HTTP ${response.status}`);
      }
      const json = await response.json();
      output = json.candidates?.[0]?.content?.parts?.[0]?.text || '';
    } else if (provider === 'Anthropic') {
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01'
        },
        body: JSON.stringify({
          model: model || 'claude-3-5-sonnet-20241022',
          max_tokens: 2000,
          messages: [{ role: 'user', content: prompt }]
        })
      });
      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error?.message || `HTTP ${response.status}`);
      }
      const json = await response.json();
      output = json.content?.[0]?.text || '';
    } else if (provider === 'Custom') {
      const targetUrl = baseUrl.endsWith('/chat/completions') ? baseUrl : (baseUrl.endsWith('/v1') ? `${baseUrl}/chat/completions` : `${baseUrl}/v1/chat/completions`);
      const response = await fetch(targetUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: 'custom',
          messages: [{ role: 'user', content: prompt }],
          max_tokens: 2000
        })
      });
      if (!response.ok) {
        throw new Error(`Custom endpoint returned status ${response.status}`);
      }
      const json = await response.json();
      output = json.choices?.[0]?.message?.content || '';
    } else if (provider === 'MockAPI') {
      const response = await fetch(baseUrl, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      if (!response.ok) {
        throw new Error(`MockAPI endpoint returned status ${response.status}`);
      }
      const json = await response.json();
      if (Array.isArray(json) && json.length > 0) {
        const first = json[0];
        output = first.text || first.message || first.response || first.output || JSON.stringify(first, null, 2);
      } else {
        output = JSON.stringify(json, null, 2);
      }
    } else {
      throw new Error('Unknown provider');
    }

    return res.json({ success: true, output });
  } catch (err) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/db/execute
app.post('/api/db/execute', async (req, res) => {
  const { query } = req.body;
  if (!query) {
    return res.status(400).json({ success: false, error: 'Query is required' });
  }
  
  console.log(`🗄️ Executing DB Query:\n${query}`);

  // Create a pool connection using environment variables or defaults
  const pool = new Pool({
    user: process.env.PGUSER || 'postgres',
    host: process.env.PGHOST || 'localhost',
    database: process.env.PGDATABASE || 'task_manager',
    password: process.env.PGPASSWORD || 'postgres',
    port: process.env.PGPORT || 5432,
  });

  try {
    const result = await pool.query(query);
    return res.json({
      success: true,
      rowCount: result.rowCount,
      rows: result.rows || [],
    });
  } catch (err) {
    console.error(`❌ DB Execution Error:`, err.message);
    return res.status(500).json({ success: false, error: err.message });
  } finally {
    // End pool so we don't leak connections (in a real app, you'd keep one global pool)
    await pool.end();
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', smtp_user: process.env.SMTP_USER ? 'configured' : 'NOT configured' });
});

app.listen(PORT, () => {
  console.log(`🚀 Email backend running on http://localhost:${PORT}`);
  if (!process.env.SMTP_USER || process.env.SMTP_USER === 'your-email@gmail.com') {
    console.warn('⚠️  SMTP credentials not configured! Edit backend/.env with your Gmail + App Password.');
  }
});
