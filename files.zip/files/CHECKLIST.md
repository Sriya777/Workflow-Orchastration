# Antigravity Workflow — Development & Deployment Checklists

> Use these checklists before every feature merge, release candidate, and production deployment.  
> Each item is grounded in the actual Antigravity codebase — not generic boilerplate.

---

## Table of Contents

1. [Frontend Checklist](#frontend-checklist)
2. [Backend Checklist](#backend-checklist)
3. [Node Implementation Checklist](#node-implementation-checklist)
4. [Execution Engine Checklist](#execution-engine-checklist)
5. [Deployment Checklist](#deployment-checklist)
6. [Security Checklist](#security-checklist)
7. [Post-Deployment Verification](#post-deployment-verification)

---

## Frontend Checklist

### Input Validation

- [ ] All user-configurable node fields validate before execution begins (email regex, URL format, required fields)
- [ ] `FormTaskNode` `taskMode` is validated as `'form1'` or `'form2'` — no other values accepted
- [ ] `ApiCallNode` URL field validated: must begin with `http://` or `https://`, not empty
- [ ] `EmailNode` recipient (`to`) validated with the same regex as backend: `/^[^\s@]+@[^\s@]+\.[^\s@]+$/`
- [ ] File attachments validated for size before base64 encoding (recommend ≤ 5MB per file)
- [ ] Workflow graph validated before execution: no orphan nodes, at least one start node present

### Security (Frontend)

- [ ] No secrets, API keys, or SMTP credentials embedded in frontend source code
- [ ] `formData` field values sanitized before injecting into email HTML (prevent XSS via `formData.value`)
- [ ] `customUrl` in `FormTaskNode` / `ApiCallNode` validated to prevent `javascript:` URI schemes
- [ ] `window.open()` popup URLs use `window.location.origin` — not user-supplied origin strings
- [ ] `localStorage` entries (`form_fill_*`, `node_data_*`) cleared after consumption
- [ ] No PII (email addresses, form payloads) persisted beyond the active session
- [ ] `postMessage` handler in `handleFormMessage` validates `event.data.type === 'FORM_SUBMITTED'` explicitly before processing

### Accessibility

- [ ] All interactive buttons have accessible labels (`aria-label` or visible text)
- [ ] Modal dialogs trap focus within the modal while open
- [ ] Form inputs have associated `<label>` elements
- [ ] Color-coded node status indicators (green/red/blue) have text fallbacks for color-blind users
- [ ] Keyboard navigation works for: node palette, canvas pan, properties panel inputs

### Responsive UI

- [ ] Workflow canvas is usable on 1280px+ desktop widths (primary target)
- [ ] NodePanel and PropertiesPanel do not overflow at 1024px width
- [ ] Popup windows (form fill) open at `width=500,height=600` — verify on 1080p and 4K screens

### Error Handling

- [ ] All `fetch()` calls wrapped in `try/catch` with node `execStatus` set to `'failed'` on error
- [ ] `stopExecutionRef` is checked before each node execution step
- [ ] `formResolvers`, `managerResolvers`, `emailResolvers` are cleaned up on workflow stop/reset
- [ ] Toast notifications shown for: form submitted, email sent, manager decision recorded, execution errors
- [ ] Popup window (`window.open`) failure handled gracefully if browser blocks popups

### API Handling

- [ ] `POST /api/send-email` response parsed and `success` field checked before marking node complete
- [ ] `GET /api/webhook/form/latest` 404 response (no submissions yet) handled without crashing node
- [ ] `GET /api/health` checked on app init; user warned if backend is unreachable
- [ ] Request timeout implemented for all `fetch()` calls (recommend `AbortController` with 30s timeout)
- [ ] Network errors (no backend) produce user-readable error in `globalExecutionError` state

### State Management

- [ ] `latestNodesRef` kept in sync with `nodes` state via `useEffect` — verify no stale closure bugs
- [ ] Execution run data (`allExecutionRuns`) does not grow unboundedly — cap at last N runs per workflow
- [ ] `workflowVersion` incremented on every save/export to detect concurrent edits
- [ ] `selectedNode` cleared when switching to execution mode

---

## Backend Checklist

### Input Validation

- [ ] `to` (recipient email) validated with regex before attempting SMTP send
- [ ] `subject` field length capped (recommend ≤ 255 chars)
- [ ] `body` field sanitized — strip `<script>` tags if embedding in HTML
- [ ] `formData` array items: each entry must have `label` (string) and `value` (string|null)
- [ ] `attachments` array: `att.data` verified to match `data:...;base64,...` format before parsing
- [ ] `managerDecision` validated as `'approved'` or `'rejected'` only
- [ ] Webhook payload (`POST /api/webhook/form`) size capped (current: 25MB limit on `express.json`)
- [ ] `request.body` existence verified before destructuring on all endpoints

### Logging

- [ ] Every email dispatch logged with: `to`, `subject`, `requestId`, `messageId` — **NOT** `formData` field values
- [ ] SMTP errors logged with error message only — **NOT** with SMTP credentials
- [ ] Webhook payloads logged with field names only — **NOT** field values (may contain PII)
- [ ] No JWT tokens, session IDs, or passwords appear in any `console.log` / `console.error`
- [ ] Log lines include ISO timestamps for correlation

### Rate Limiting

- [ ] `express-rate-limit` applied to `POST /api/send-email` (recommend: 10 requests/minute/IP)
- [ ] `express-rate-limit` applied to `POST /api/webhook/form` (recommend: 30 requests/minute/IP)
- [ ] Rate limit exceeded returns `429 Too Many Requests` with `Retry-After` header

### CORS

- [ ] `cors()` middleware configured with explicit `origin` allowlist — not open `cors()`
- [ ] Allowed origins list matches production frontend URL(s)
- [ ] `Access-Control-Allow-Methods` restricted to `GET, POST`
- [ ] `Access-Control-Allow-Headers` restricted to `Content-Type, Authorization`

### Authentication & Authorization

- [ ] All routes except `GET /api/health` require valid JWT in `Authorization: Bearer` header
- [ ] JWT validation middleware verifies signature, expiry, and issuer
- [ ] SMTP credentials accessed only from `process.env` — never from request body
- [ ] Admin-only routes (e.g. view all form submissions) protected by role check

### Security Headers

- [ ] `helmet` middleware installed and active
- [ ] `Content-Security-Policy` set appropriately for API responses
- [ ] `X-Content-Type-Options: nosniff` header present
- [ ] `X-Frame-Options: DENY` header present
- [ ] `Strict-Transport-Security` header present (HTTPS deployments only)

---

## Node Implementation Checklist

When adding or modifying a node type:

- [ ] Node registered in `src/nodes/index.js` `nodeTypes` object
- [ ] Node handles both `appMode === 'editor'` and `appMode === 'execution'` states distinctly
- [ ] Node reads `data.execStatus` to render correct visual state (draft / running / completed / failed)
- [ ] Node dispatches the correct `CustomEvent` or sets `execStatus` via `setNodes` to unblock execution
- [ ] Node does not directly mutate `data` props — uses `setNodes` from `useReactFlow()`
- [ ] Node renders a React Flow `<Handle>` for each connection point (input/output)
- [ ] Node shows a loading/running indicator while `execStatus === 'running'`
- [ ] `PropertiesPanel.jsx` updated with configuration fields for the new node type
- [ ] `NodePanel.jsx` updated with the new node type in the draggable palette

---

## Execution Engine Checklist

Before shipping changes to `App.jsx` execution logic:

- [ ] `stopExecutionRef.current` checked at the top of each node execution step
- [ ] All resolver refs (`formResolvers`, `managerResolvers`, `emailResolvers`) deleted after resolution to prevent memory leaks
- [ ] Execution start/end timestamps recorded for TAT calculation
- [ ] `allExecutionRuns` updated atomically — no partial run records
- [ ] Execution errors caught per-node and stored in `globalExecutionError` without crashing the entire loop
- [ ] `appMode` reset to `'editor'` on workflow stop/complete/error (or kept `'execution'` with clear UI state)
- [ ] `window.removeEventListener` calls match exactly with `window.addEventListener` calls (event name + handler reference)

---

## Deployment Checklist

### Environment & Configuration

- [ ] `backend/.env` is NOT committed to version control (`.gitignore` must include `backend/.env`)
- [ ] Production environment uses environment variables from secrets manager (not `.env` files)
- [ ] `SMTP_USER` and `SMTP_PASS` are production credentials — not development credentials
- [ ] `PORT` set to production port (default: 3001 — verify not conflicting)
- [ ] Frontend `fetch()` base URL updated to production backend URL (not `localhost:3001`)

### HTTPS

- [ ] TLS certificate installed and valid (check expiry date)
- [ ] HTTP → HTTPS redirect configured at reverse proxy level
- [ ] `Strict-Transport-Security` header enabled with `max-age=31536000; includeSubDomains`
- [ ] SMTP connection uses TLS (`service: 'gmail'` does this by default via Nodemailer)

### Build Verification

- [ ] `npm run build` completes with zero errors
- [ ] `dist/index.html` references correct hashed asset filenames
- [ ] Vite `base` config set if deploying to a subdirectory path
- [ ] Frontend build tested against production backend before going live

### Production Logging

- [ ] `console.log` replaced with structured logger (e.g. `pino`, `winston`) in production
- [ ] Log level set to `info` in production (not `debug`)
- [ ] Logs shipped to centralized log aggregator (Datadog, Loki, CloudWatch, etc.)
- [ ] Log rotation configured to prevent disk exhaustion

### Monitoring & Alerts

- [ ] `GET /api/health` endpoint monitored by uptime checker (e.g. UptimeRobot, Pingdom)
- [ ] SMTP send failure rate alerted (> 5% failure rate triggers alert)
- [ ] Memory usage monitored — in-memory `formSubmissions[]` can grow unboundedly
- [ ] PM2 or equivalent process manager configured to restart backend on crash

### Database & Persistence

- [ ] ⚠️ Current build has **no persistent storage** — all workflow state lost on page refresh
- [ ] Before production: implement server-side workflow state persistence (PostgreSQL recommended)
- [ ] `formSubmissions[]` in-memory store replaced with database table
- [ ] Workflow definitions exportable/importable as JSON (already partial via `localStorage`)

---

## Security Checklist

### Secrets & Credentials

- [ ] No hardcoded credentials in any source file (check with `git grep -i "password\|secret\|token\|smtp_pass"`)
- [ ] `.gitignore` includes: `backend/.env`, `*.env`, `*.pem`, `*.key`
- [ ] Gmail App Password rotated if it appears in any commit history
- [ ] Production secrets stored in vault/secrets manager — not in CI environment variables as plain text

### Data Protection

- [ ] PII in form submissions (`filledData`) not logged to console
- [ ] Email addresses not logged in full (log domain only, e.g. `***@gmail.com`)
- [ ] Attachment content (base64 data) never logged
- [ ] `localStorage` entries containing form data cleared after use (current code does this — verify not regressed)

### Token & Session Handling

- [ ] (When auth is implemented) JWT stored in memory only — not `localStorage` or `sessionStorage`
- [ ] Refresh tokens stored in `HttpOnly; Secure; SameSite=Strict` cookies
- [ ] Token expiry enforced server-side — not just client-side
- [ ] Logout clears all resolver refs and resets execution state

### Input Sanitization

- [ ] `formData[].value` HTML-escaped before embedding in email body string
- [ ] `managerComments` HTML-escaped before embedding in email body
- [ ] `requestId` validated as alphanumeric before embedding in email HTML
- [ ] Webhook payloads from external sources treated as untrusted input

---

## Post-Deployment Verification

Run this sequence within 15 minutes of every deployment:

```bash
# 1. Health check
curl https://your-api-domain.com/api/health
# Expected: { "status": "ok", "smtp_user": "configured" }

# 2. SMTP connectivity
# Trigger a test email via the UI to a known inbox

# 3. Webhook ingestion
curl -X POST https://your-api-domain.com/api/webhook/form \
  -H "Content-Type: application/json" \
  -d '{"name":"Test User","email":"test@example.com"}'
# Expected: { "success": true, "message": "Form submission received successfully" }

# 4. Latest submission retrieval
curl https://your-api-domain.com/api/webhook/form/latest
# Expected: { "success": true, "submission": { ... } }

# 5. Frontend loads correctly
curl -I https://your-frontend-domain.com
# Expected: HTTP/2 200, Content-Type: text/html
```
