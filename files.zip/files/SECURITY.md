# Security Documentation

> OWASP-aligned security guidelines for the Antigravity Workflow Orchestration platform

---

## Table of Contents

- [Security Philosophy](#security-philosophy)
- [Current Security Posture](#current-security-posture)
- [OWASP Top 10 — Applicability](#owasp-top-10--applicability)
- [Rate Limiting](#rate-limiting)
- [XSS Prevention](#xss-prevention)
- [CSRF Prevention](#csrf-prevention)
- [SQL Injection Prevention](#sql-injection-prevention)
- [Secure Headers](#secure-headers)
- [API Protection](#api-protection)
- [Workflow Execution Isolation](#workflow-execution-isolation)
- [Secure Logging](#secure-logging)
- [Encryption Strategy](#encryption-strategy)
- [HTTPS Enforcement](#https-enforcement)
- [Input Sanitisation](#input-sanitisation)
- [Secret Management](#secret-management)
- [Environment Variable Protection](#environment-variable-protection)
- [File Upload Validation](#file-upload-validation)
- [Secure Token Handling](#secure-token-handling)
- [Audit Logging](#audit-logging)
- [Security Monitoring](#security-monitoring)

---

## Security Philosophy

Security in Antigravity Workflow follows the principle of **defence in depth**: multiple independent security controls so that the failure of any single control does not compromise the system. Controls are applied at the network, transport, application, and data layers.

Key principles:
- **Least privilege** — each component accesses only what it needs
- **Fail securely** — errors default to denial, not access
- **Input never trusted** — validate and sanitise all external input
- **Sensitive data minimisation** — never store more than required

---

## Current Security Posture

| Control | Status | Risk |
|---------|--------|------|
| Authentication | ❌ None | High — open to any user |
| HTTPS enforcement | ❌ Not configured | High — credentials in transit unencrypted |
| CORS | ⚠️ Open (all origins) | Medium — any site can call the API |
| Rate limiting | ❌ None | High — email endpoint abusable |
| Input validation | ⚠️ Partial (email regex only) | Medium |
| SMTP credentials | ⚠️ Plaintext `.env` | High if committed to git |
| Secure headers | ❌ None (no Helmet) | Medium |
| Audit logging | ❌ None | Medium |
| XSS prevention | ✅ React escaping | Low |
| SQL injection | ✅ No database (N/A) | N/A |

---

## OWASP Top 10 — Applicability

| OWASP Category | Applicable | Mitigation |
|---------------|-----------|-----------|
| A01: Broken Access Control | Yes | Implement JWT + RBAC |
| A02: Cryptographic Failures | Yes | HTTPS, bcrypt, no plaintext secrets |
| A03: Injection | Partial | Email header injection, JS eval prevention |
| A04: Insecure Design | Yes | Threat model, auth design |
| A05: Security Misconfiguration | Yes | Helmet, restricted CORS, no debug mode |
| A06: Vulnerable Components | Yes | Dependency audits (`npm audit`) |
| A07: Auth Failures | Yes | JWT, secure cookies, no password logging |
| A08: Data Integrity Failures | Yes | Verify webhook payloads, no eval |
| A09: Logging Failures | Yes | Structured logs, no PII in logs |
| A10: Server-Side Request Forgery | Yes | Validate API call node URLs |

---

## Rate Limiting

Without rate limiting, the `/api/send-email` endpoint is an open email relay — anyone with the URL can send unlimited emails from the configured Gmail account.

### Recommended Configuration

```javascript
import rateLimit from 'express-rate-limit';

// General API rate limit
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100,
  standardHeaders: true,      // Return `RateLimit-*` headers
  legacyHeaders: false,
  message: { success: false, error: 'Too many requests. Please try again later.' },
});

// Strict limit for email endpoint (prevent abuse)
const emailLimiter = rateLimit({
  windowMs: 60 * 1000,        // 1 minute
  max: 10,                    // 10 emails per minute per IP
  message: { success: false, error: 'Email rate limit exceeded.' },
});

// Strict limit for login (brute-force prevention)
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: { success: false, error: 'Too many login attempts.' },
});

app.use('/api/', apiLimiter);
app.use('/api/send-email', emailLimiter);
app.use('/api/v1/auth/login', loginLimiter);
```

### IP-Based vs. User-Based

For authenticated endpoints, rate limit by `req.user.sub` (user ID) instead of IP to prevent shared-IP false positives:

```javascript
keyGenerator: (req) => req.user?.sub || req.ip,
```

---

## XSS Prevention

### Frontend (React)

React's JSX automatically escapes all dynamic content rendered via `{}` syntax. This prevents most reflected and stored XSS attacks.

**Safe:**
```jsx
<div>{userInput}</div>   // React escapes this
```

**Dangerous — never use:**
```jsx
<div dangerouslySetInnerHTML={{ __html: userInput }} />  // Direct injection
```

The application does not use `dangerouslySetInnerHTML` anywhere.

### Backend (Email HTML Construction)

The email HTML body is constructed via string templates with raw user data interpolated. **All user-provided values must be HTML-escaped before interpolation:**

```javascript
// Safe HTML escaping
function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// Use when building the email body
const safeValue = escapeHtml(field.value);
htmlBody += `<td>${safeValue}</td>`;
```

**Current gap:** The production `server.js` does not HTML-escape form field values before interpolating them into the email HTML body. This must be fixed before deploying to production.

### Content Security Policy

```javascript
// Via Helmet
helmet.contentSecurityPolicy({
  directives: {
    defaultSrc: ["'self'"],
    scriptSrc: ["'self'"],
    styleSrc: ["'self'", "'unsafe-inline'"], // Required for React inline styles
    imgSrc: ["'self'", "data:", "blob:"],
    connectSrc: ["'self'", process.env.BACKEND_URL],
    frameSrc: ["'none'"],
    objectSrc: ["'none'"],
    upgradeInsecureRequests: [],
  },
});
```

---

## CSRF Prevention

### Current Protection

The API currently has no state-changing operations that require cookies (no authentication), so CSRF is not an active risk in the current architecture.

### Production CSRF Protection

Once refresh tokens are stored in cookies, implement:

1. **SameSite=Strict cookies** — prevents cross-site cookie sending (primary protection)
2. **CSRF token in custom header** — secondary protection for older browsers

```javascript
// Generate CSRF token on login
const csrfToken = crypto.randomBytes(32).toString('hex');

// Set as non-HttpOnly cookie (readable by JS for inclusion in header)
res.cookie('csrfToken', csrfToken, {
  secure: true,
  sameSite: 'Strict',
  maxAge: 7 * 24 * 60 * 60 * 1000,
});

// Validate on state-changing endpoints
app.use('/api/v1/', (req, res, next) => {
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
    const csrfHeader = req.headers['x-csrf-token'];
    const csrfCookie = req.cookies['csrfToken'];
    if (!csrfHeader || csrfHeader !== csrfCookie) {
      return res.status(403).json({ success: false, error: 'CSRF validation failed' });
    }
  }
  next();
});
```

---

## SQL Injection Prevention

The current backend has no database — no SQL injection risk exists.

When a database is added, use an ORM (Prisma, Drizzle) or parameterised queries exclusively:

```javascript
// Safe — parameterised query
const user = await db.query(
  'SELECT * FROM users WHERE email = $1',
  [email]  // Parameterised — never string-concatenated
);

// Never do this
const unsafe = `SELECT * FROM users WHERE email = '${email}'`; // SQL injection
```

With Prisma:
```javascript
const user = await prisma.user.findUnique({ where: { email } }); // Safe by default
```

---

## Secure Headers

Install and configure Helmet to set security headers on all responses:

```javascript
import helmet from 'helmet';

app.use(helmet());
// Sets: X-DNS-Prefetch-Control, X-Frame-Options, X-Content-Type-Options,
//       Referrer-Policy, X-Permitted-Cross-Domain-Policies,
//       Strict-Transport-Security (HTTPS only), Content-Security-Policy
```

### Required Headers

| Header | Value | Purpose |
|--------|-------|---------|
| `Strict-Transport-Security` | `max-age=63072000; includeSubDomains` | Force HTTPS |
| `X-Content-Type-Options` | `nosniff` | Prevent MIME sniffing |
| `X-Frame-Options` | `DENY` | Prevent clickjacking |
| `Referrer-Policy` | `strict-origin-when-cross-origin` | Limit referrer leakage |
| `Content-Security-Policy` | See above | Prevent XSS |
| `X-XSS-Protection` | `0` | Disable legacy XSS filter (CSP is better) |

---

## API Protection

### Webhook Endpoint Security

The `POST /api/webhook/form` endpoint accepts arbitrary JSON from any source. Production hardening:

1. **HMAC signature verification** — Google Forms, Typeform, etc. support signing webhooks with a shared secret
2. **IP allowlist** — If the form provider's IP range is known, restrict to it
3. **Payload size limit** — Already set at 25MB; consider reducing for webhook payloads

```javascript
// HMAC verification for Typeform webhooks
import crypto from 'crypto';

function verifyWebhookSignature(req, res, next) {
  const signature = req.headers['typeform-signature'];
  const expectedSignature = 'sha256=' + crypto
    .createHmac('sha256', process.env.WEBHOOK_SECRET)
    .update(JSON.stringify(req.body))
    .digest('base64');

  if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSignature))) {
    return res.status(403).json({ success: false, error: 'Invalid webhook signature' });
  }
  next();
}
```

### API Call Node — SSRF Prevention

The `ApiCallNode` allows users to configure any URL. This is a **Server-Side Request Forgery (SSRF) risk** if the API calls were executed server-side. Currently, API calls execute in the browser (client-side fetch), which limits SSRF risk but allows users to call internal browser-accessible resources.

For production, validate user-configured URLs on the backend:

```javascript
function isAllowedUrl(url) {
  try {
    const parsed = new URL(url);
    // Block private IP ranges and localhost
    const blocked = ['localhost', '127.0.0.1', '0.0.0.0', '169.254', '10.', '192.168.', '172.16.'];
    return parsed.protocol === 'https:' && !blocked.some(b => parsed.hostname.startsWith(b));
  } catch {
    return false;
  }
}
```

---

## Workflow Execution Isolation

The workflow execution engine runs in the browser (client-side JavaScript). Key isolation considerations:

- **No `eval()`** — Workflow node logic does not use dynamic code evaluation
- **No `new Function()`** — Configuration values are treated as data, not code
- **Variable interpolation** — URL/body templates use string replacement, not template literal evaluation
- **Attachment handling** — Files are read via `FileReader` API (sandboxed), not filesystem access

---

## Secure Logging

See [PII_LOGGING.md](./PII_LOGGING.md) for the full PII logging policy.

### Core Rules

- Never log SMTP passwords, JWT tokens, session IDs, or form field values with PII
- Log events (email dispatched, webhook received) with metadata only (recipient domain, field count)
- Use structured JSON logging in production
- Rotate logs and set appropriate retention policies

---

## Encryption Strategy

### Data in Transit

- All production traffic must use TLS 1.2+ (enforced by reverse proxy)
- SMTP uses STARTTLS (Gmail enforces this)
- Internal service-to-service traffic should use mTLS in containerised environments

### Data at Rest

- No database is currently used — no at-rest encryption needed today
- When a database is added: enable encryption at rest (PostgreSQL `pgcrypto`, or disk-level encryption)
- Refresh token table: store bcrypt hashes of tokens, never plaintext

### Secret Keys

- `JWT_SECRET`: minimum 256-bit random string (`crypto.randomBytes(32).toString('hex')`)
- Rotate secrets periodically; invalidate all sessions on rotation
- Never reuse secrets across environments (dev/staging/prod)

---

## HTTPS Enforcement

### Nginx Configuration

```nginx
server {
  listen 80;
  server_name api.your-domain.com;
  return 301 https://$host$request_uri;  # Redirect all HTTP to HTTPS
}

server {
  listen 443 ssl http2;
  server_name api.your-domain.com;

  ssl_certificate /etc/letsencrypt/live/your-domain.com/fullchain.pem;
  ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;
  ssl_protocols TLSv1.2 TLSv1.3;
  ssl_ciphers HIGH:!aNULL:!MD5;

  add_header Strict-Transport-Security "max-age=63072000; includeSubDomains; preload" always;

  location / {
    proxy_pass http://localhost:3001;
  }
}
```

---

## Input Sanitisation

### Email Address

```javascript
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
// Validate before processing
```

### HTML Email Content (Fix Required)

All user-supplied values interpolated into email HTML must be escaped:

```javascript
// Add this utility to server.js
const escapeHtml = (s) => String(s || '')
  .replace(/&/g, '&amp;')
  .replace(/</g, '&lt;')
  .replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;');
```

### Attachment Filenames

Strip path separators and limit to safe characters:

```javascript
const safeFilename = att.name.replace(/[^a-zA-Z0-9._-]/g, '_').substring(0, 255);
```

---

## Secret Management

### Development

Use `.env` files (never committed to git). Add `.env` to `.gitignore`.

### Production

| Platform | Solution |
|---------|---------|
| AWS | AWS Secrets Manager + IAM roles |
| GCP | Google Secret Manager |
| Azure | Azure Key Vault |
| Self-hosted | HashiCorp Vault |
| Docker/K8s | Kubernetes Secrets (base64 only — use Sealed Secrets or Vault) |

Never embed secrets in Docker images, source code, or CI/CD logs.

---

## Environment Variable Protection

- Never log environment variable values
- Validate required env vars on startup and exit if missing:

```javascript
const required = ['SMTP_USER', 'SMTP_PASS', 'JWT_SECRET'];
for (const key of required) {
  if (!process.env[key]) {
    console.error(`Missing required environment variable: ${key}`);
    process.exit(1);
  }
}
```

- Use a `.env.example` file (with placeholder values, no real secrets) committed to git for documentation

---

## File Upload Validation

Attachments are base64-encoded and sent in the email payload. Validate before processing:

```javascript
const ALLOWED_MIME_TYPES = [
  'application/pdf', 'image/png', 'image/jpeg', 'image/gif',
  'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'text/plain', 'text/csv',
];
const MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024; // 10MB

function validateAttachment(att) {
  const matches = att.data?.match(/^data:(.+);base64,/);
  if (!matches) throw new Error('Invalid attachment data URL');
  const mimeType = matches[1];
  if (!ALLOWED_MIME_TYPES.includes(mimeType)) throw new Error(`Disallowed file type: ${mimeType}`);
  if (att.size > MAX_FILE_SIZE_BYTES) throw new Error('Attachment exceeds 10MB limit');
}
```

---

## Secure Token Handling

| Token | Do | Don't |
|-------|-----|-------|
| JWT access token | Store in React state (memory) | Store in localStorage, sessionStorage, cookies |
| Refresh token | HttpOnly Secure cookie | Expose via JavaScript |
| SMTP password | Environment variable only | Hardcode in source, log, or return to client |
| Gmail App Password | backend/.env only | Commit to git |
| CSRF token | Non-HttpOnly Secure cookie | Include in URL parameters |

---

## Audit Logging

Every significant security event should be logged with structured metadata:

| Event | Fields to Log |
|-------|--------------|
| Login attempt | timestamp, ip, email (domain only), success |
| Login failure | timestamp, ip, failure reason (no password detail) |
| Token refresh | timestamp, userId, ip |
| Logout | timestamp, userId |
| Email dispatched | timestamp, userId, recipient domain, fieldCount |
| Webhook received | timestamp, ip, payload keys (not values) |
| Execution started | timestamp, userId, workflowId, nodeCount |
| Permission denied | timestamp, userId, resource, action |
| Rate limit hit | timestamp, ip, endpoint |

---

## Security Monitoring

### Recommended Tooling

| Category | Tool |
|---------|------|
| Dependency vulnerabilities | `npm audit`, Snyk, Dependabot |
| Runtime anomaly detection | Datadog, New Relic, AWS GuardDuty |
| Log aggregation | ELK Stack, Logtail, Papertrail |
| Uptime monitoring | Uptime Robot, Better Uptime |
| SAST | ESLint security rules, SonarCloud |
| Secrets scanning | GitGuardian, GitHub secret scanning |

### Automated Checks

```bash
# Run on every CI pipeline
npm audit --audit-level=high   # Fail on high severity vulnerabilities
npx eslint-plugin-security      # Static analysis for security patterns
```

### Incident Response Checklist

1. Identify and contain the breach
2. Rotate all secrets (JWT_SECRET, SMTP_PASS, WEBHOOK_SECRET)
3. Invalidate all active sessions (delete all refresh token records)
4. Review audit logs for scope of compromise
5. Notify affected users per your data breach notification policy
6. Patch the vulnerability
7. Post-incident review
