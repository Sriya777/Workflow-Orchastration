# API Documentation

> REST API reference for the Antigravity Workflow Orchestration backend

---

## Table of Contents

- [API Overview](#api-overview)
- [Base URL](#base-url)
- [Endpoint Naming Conventions](#endpoint-naming-conventions)
- [Authentication Headers](#authentication-headers)
- [Request / Response Format](#request--response-format)
- [Endpoints](#endpoints)
  - [Email API](#email-api)
  - [Webhook / Form API](#webhook--form-api)
  - [Health API](#health-api)
- [Error Response Structure](#error-response-structure)
- [Validation Error Format](#validation-error-format)
- [HTTP Status Codes](#http-status-codes)
- [Pagination](#pagination)
- [Retry Strategy](#retry-strategy)
- [API Versioning](#api-versioning)

---

## API Overview

The Antigravity Workflow backend exposes a minimal REST API with four endpoints. All requests and responses use `application/json`. The API is consumed exclusively by the React frontend during workflow execution.

| Method | Path | Purpose |
|--------|------|---------|
| `POST` | `/api/send-email` | Dispatch an HTML email via SMTP |
| `POST` | `/api/webhook/form` | Receive an external form submission |
| `GET` | `/api/webhook/form/latest` | Retrieve the most recent form submission |
| `GET` | `/api/health` | Server and SMTP health check |

---

## Base URL

| Environment | Base URL |
|-------------|----------|
| Development | `http://localhost:3001` |
| Production | `https://api.your-domain.com` |

All endpoint paths are prefixed with `/api/`.

---

## Endpoint Naming Conventions

- Resource paths use **kebab-case** (`/send-email`, `/webhook/form`)
- Sub-resources are appended with a forward slash (`/webhook/form/latest`)
- No trailing slashes
- Versioning uses a `v1/` prefix in the path for production (see [API Versioning](#api-versioning))

Future endpoint naming pattern:
```
/api/v1/emails
/api/v1/workflows
/api/v1/workflows/{id}/executions
/api/v1/webhook/forms
```

---

## Authentication Headers

The current API has **no authentication**. For production deployments, all endpoints must require a JWT Bearer token:

```http
Authorization: Bearer <accessToken>
Content-Type: application/json
```

### Token Handling

- The frontend stores `accessToken` in memory (React state), never in `localStorage`
- The token is attached per-request via the `Authorization` header
- On `401 Unauthorized` response, the frontend silently refreshes the token via `/api/v1/auth/refresh`
- The refresh token is stored in an `HttpOnly` cookie

---

## Request / Response Format

### Request

All `POST` requests must include:

```http
Content-Type: application/json
```

Request bodies are JSON objects. Array fields (`formData`, `attachments`) must be arrays even when empty.

### Response Envelope

All responses follow a consistent envelope:

```json
{
  "success": true | false,
  "data": { ... } | null,
  "message": "Human-readable description",
  "error": "Error detail (only on failure)"
}
```

---

## Endpoints

---

### Email API

#### `POST /api/send-email`

Dispatches a structured HTML email through the configured Gmail SMTP transport.

**Headers:**

```http
Content-Type: application/json
Authorization: Bearer <token>   (future requirement)
```

**Request Body:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `to` | string | Yes | Recipient email address |
| `subject` | string | No | Email subject line |
| `body` | string | No | Plain text body (shown if no `requestId`) |
| `requestId` | string | No | Reference ID displayed prominently in email |
| `formData` | array | No | Collected form fields: `[{ label, value }]` |
| `attachments` | array | No | File attachments: `[{ name, size, data }]` |
| `managerDecision` | string | No | `"approved"` or `"rejected"` |
| `managerComments` | string | No | Manager's free-text remarks |

**`formData` item schema:**

```json
{
  "label": "Employee Name",
  "value": "Alice Johnson"
}
```

**`attachments` item schema:**

```json
{
  "name": "leave-policy.pdf",
  "size": 204800,
  "data": "data:application/pdf;base64,JVBERi0x..."
}
```

**Example Request:**

```bash
curl -X POST http://localhost:3001/api/send-email \
  -H "Content-Type: application/json" \
  -d '{
    "to": "alice@example.com",
    "subject": "Your Leave Request — REQ-2024-0523",
    "requestId": "REQ-2024-0523",
    "formData": [
      { "label": "Employee Name", "value": "Alice Johnson" },
      { "label": "Leave Type", "value": "Annual Leave" },
      { "label": "Days Requested", "value": "5" }
    ],
    "managerDecision": "approved",
    "managerComments": "Approved. Please hand over to Bob before you leave."
  }'
```

**Success Response (200):**

```json
{
  "success": true,
  "messageId": "<abc123@mail.gmail.com>",
  "message": "Email successfully sent to alice@example.com with 3 form field(s) and 0 attachment(s)"
}
```

**Simulated Success Response (200 — SMTP fallback, development only):**

```json
{
  "success": true,
  "messageId": "simulated-k3j9m2xpq",
  "message": "[Simulated] Email successfully dispatched to alice@example.com with 3 form field(s) and 0 attachment(s) (SMTP Fallback)"
}
```

**Validation Error (400):**

```json
{
  "success": false,
  "error": "The mail is not getting sent: Invalid or missing email address \"\""
}
```

---

### Webhook / Form API

#### `POST /api/webhook/form`

Accepts a raw JSON form submission from an external system. No schema is enforced — any valid JSON body is accepted.

Intended for integration with external form providers (Google Forms, Typeform, Jotform) via their webhook/notification features.

**Example Request (Google Forms webhook format):**

```bash
curl -X POST http://localhost:3001/api/webhook/form \
  -H "Content-Type: application/json" \
  -d '{
    "employee_name": "Alice Johnson",
    "employee_id": "EMP-4521",
    "leave_type": "annual",
    "start_date": "2024-06-01",
    "end_date": "2024-06-05",
    "reason": "Family vacation"
  }'
```

**Success Response (200):**

```json
{
  "success": true,
  "message": "Form submission received successfully"
}
```

---

#### `GET /api/webhook/form/latest`

Returns the most recently received webhook form submission. Used by the frontend's `apiCall` node to pull form data into the workflow.

**Example Request:**

```bash
curl http://localhost:3001/api/webhook/form/latest
```

**Success Response (200):**

```json
{
  "success": true,
  "submission": {
    "receivedAt": "2024-05-23T10:30:45.123Z",
    "data": {
      "employee_name": "Alice Johnson",
      "employee_id": "EMP-4521",
      "leave_type": "annual",
      "start_date": "2024-06-01",
      "end_date": "2024-06-05",
      "reason": "Family vacation"
    }
  }
}
```

**Not Found Response (404):**

```json
{
  "success": false,
  "message": "No form submissions found yet"
}
```

---

### Health API

#### `GET /api/health`

Returns the operational status of the backend server and SMTP configuration.

**Example Request:**

```bash
curl http://localhost:3001/api/health
```

**Response (200):**

```json
{
  "status": "ok",
  "smtp_user": "configured"
}
```

If SMTP credentials are missing or set to the placeholder value:

```json
{
  "status": "ok",
  "smtp_user": "NOT configured"
}
```

> The health endpoint always returns `200 OK` — `smtp_user` status is informational, not a failure indicator.

---

## Error Response Structure

All error responses use a consistent format:

```json
{
  "success": false,
  "error": "Human-readable error description",
  "code": "ERROR_CODE",        (future — for programmatic handling)
  "details": { ... }           (future — field-level validation errors)
}
```

### Common Error Codes (Planned)

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `INVALID_EMAIL` | 400 | Recipient email address failed validation |
| `MISSING_FIELD` | 400 | Required field absent in request body |
| `ATTACHMENT_TOO_LARGE` | 400 | Single attachment exceeds 10MB |
| `PAYLOAD_TOO_LARGE` | 413 | Total request body exceeds 25MB |
| `SMTP_FAILURE` | 502 | Nodemailer failed to send the email |
| `RATE_LIMITED` | 429 | Too many requests from this client |
| `UNAUTHORIZED` | 401 | Missing or invalid JWT token |
| `FORBIDDEN` | 403 | Authenticated but insufficient permissions |
| `NOT_FOUND` | 404 | Requested resource does not exist |
| `INTERNAL_ERROR` | 500 | Unexpected server-side failure |

---

## Validation Error Format

Planned format using Zod validation (recommended production enhancement):

```json
{
  "success": false,
  "error": "Validation failed",
  "details": {
    "to": ["Invalid email address"],
    "attachments[0].size": ["File size exceeds 10MB limit"],
    "managerDecision": ["Expected 'approved' or 'rejected'"]
  }
}
```

---

## HTTP Status Codes

| Status | Meaning | When Used |
|--------|---------|-----------|
| `200 OK` | Success | All successful responses |
| `400 Bad Request` | Client error | Validation failures, invalid input |
| `401 Unauthorized` | Auth required | Missing/expired token (future) |
| `403 Forbidden` | Access denied | Insufficient role/permissions (future) |
| `404 Not Found` | Not found | No webhook submission exists |
| `413 Payload Too Large` | Body too big | Request exceeds 25MB limit |
| `429 Too Many Requests` | Rate limited | After rate limiter is added |
| `500 Internal Server Error` | Server error | Unhandled exceptions |
| `502 Bad Gateway` | Upstream failure | SMTP relay failure (future) |

---

## Pagination

The current API does not expose paginated resources. The `/api/webhook/form/latest` endpoint returns only the most recent record.

For a production implementation exposing submission history:

```
GET /api/v1/webhook/forms?page=1&limit=20&sort=receivedAt:desc

Response:
{
  "success": true,
  "data": [...],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 143,
    "totalPages": 8
  }
}
```

---

## Retry Strategy

### Client-Side (Frontend)

The frontend does not implement automatic retries. If an email dispatch fails, the execution engine marks the email node as `error` and halts execution. The user must re-trigger execution from the Start node.

**Recommended production strategy:**

- Implement exponential backoff with jitter for transient network failures
- Retry up to 3 times with delays: 1s, 2s, 4s
- Only retry on 5xx responses or network errors (not 4xx validation errors)

### Server-Side (Backend)

Email dispatch is currently synchronous. The recommended production strategy is a **queue-based approach**:

1. `POST /api/send-email` enqueues the job in a Bull queue (Redis-backed)
2. Returns `202 Accepted` immediately with a job ID
3. Worker processes the queue with automatic retries (3 attempts, exponential backoff)
4. `GET /api/emails/{jobId}/status` endpoint for polling delivery status

---

## API Versioning

The current API is **unversioned**. All endpoints are at `/api/*`.

### Recommended Versioning Strategy

Use **URL path versioning** for breaking changes:

```
/api/v1/send-email    ← Current stable
/api/v2/send-email    ← Future breaking change
```

Rules:
- Never remove or rename fields from existing versions without a version bump
- Deprecate old versions with a `Deprecation` response header and sunset date
- Support at least two versions concurrently during transition periods
- Document breaking changes in a `CHANGELOG.md`

### Version Header (Alternative)

For non-breaking additions, use `X-API-Version` response header to communicate the server's version:

```http
X-API-Version: 1.3.0
```
