# Backend Documentation

> Node.js + Express — Email Relay, Webhook Reception, and SMTP Orchestration

---

## Table of Contents

- [Backend Architecture](#backend-architecture)
- [Technology Stack](#technology-stack)
- [Service Layer](#service-layer)
- [Controller Structure](#controller-structure)
- [API Endpoints](#api-endpoints)
- [Request Validation Pipeline](#request-validation-pipeline)
- [Email Dispatch Engine](#email-dispatch-engine)
- [Webhook Handling](#webhook-handling)
- [In-Memory Data Store](#in-memory-data-store)
- [SMTP Configuration](#smtp-configuration)
- [Environment Variables](#environment-variables)
- [Error Handling](#error-handling)
- [Logging](#logging)
- [Security Middleware](#security-middleware)
- [Production Deployment](#production-deployment)
- [Scalability Strategy](#scalability-strategy)
- [Recommended Production Enhancements](#recommended-production-enhancements)

---

## Backend Architecture

The backend is a **lightweight Express.js application** that serves as a stateless relay between the frontend workflow engine and external services (Gmail SMTP, future webhook sources).

```
┌────────────────────────────────────────────────────────┐
│                   Express Application                    │
│                                                        │
│  ┌────────────────┐    ┌──────────────────────────┐   │
│  │   Middleware   │    │       Route Handlers      │   │
│  │                │    │                          │   │
│  │  cors()        │    │  POST /api/send-email    │   │
│  │  express.json  │    │  POST /api/webhook/form  │   │
│  │  dotenv.config │    │  GET  /api/webhook/form  │   │
│  │                │    │       /latest            │   │
│  └────────────────┘    │  GET  /api/health        │   │
│                        └──────────────────────────┘   │
│                                   │                    │
│              ┌────────────────────┘                    │
│              ▼                                         │
│  ┌──────────────────────────┐                         │
│  │    Nodemailer Transport  │                         │
│  │    (Gmail SMTP)          │                         │
│  └──────────────────────────┘                         │
│              │                                         │
│  ┌──────────────────────────┐                         │
│  │  In-Memory Form Store    │                         │
│  │  (latestFormPayload,     │                         │
│  │   formSubmissions[])     │                         │
│  └──────────────────────────┘                         │
└────────────────────────────────────────────────────────┘
```

---

## Technology Stack

| Package | Version | Role |
|---------|---------|------|
| Node.js | ≥ 18.x | JavaScript runtime |
| Express | 4.21.x | HTTP server and routing |
| Nodemailer | 6.9.x | SMTP email dispatch |
| dotenv | 16.4.x | Environment variable loading |
| cors | 2.8.x | Cross-origin request handling |

### ES Modules

The backend uses `"type": "module"` — all imports use `import`/`export` syntax, not `require()`. This requires Node.js ≥ 14.x (18+ recommended).

---

## Service Layer

### Email Service (inline in `server.js`)

Responsibilities:
- Validate recipient email address
- Construct branded HTML email body from structured data
- Append form data as a formatted table
- Append manager review status with colour-coded decision block
- Attach files from base64 data URL payloads
- Call `transporter.sendMail()` with assembled `mailOptions`
- Fall back to simulated success response on SMTP failure (development only)

### Webhook Service (inline in `server.js`)

Responsibilities:
- Accept raw JSON payloads from external form systems (e.g. Google Forms, Typeform)
- Timestamp and store the latest submission in memory
- Accumulate all submissions in `formSubmissions[]` array
- Expose the latest submission to the frontend via a GET endpoint

---

## Controller Structure

The current implementation is a **single-file monolith** (`server.js`). For production or growth, the recommended structure is:

```
backend/
├── server.js                  # Express app bootstrap, middleware, listen
├── routes/
│   ├── email.routes.js        # POST /api/send-email
│   ├── webhook.routes.js      # POST+GET /api/webhook/form
│   └── health.routes.js       # GET /api/health
├── controllers/
│   ├── email.controller.js    # Request validation, HTML builder, mail dispatch
│   └── webhook.controller.js  # Payload storage and retrieval
├── services/
│   ├── mailer.service.js      # Nodemailer transport, sendMail abstraction
│   └── formStore.service.js   # In-memory (or Redis) submission store
├── middleware/
│   ├── validate.js            # Request schema validation
│   ├── rateLimiter.js         # express-rate-limit config
│   └── errorHandler.js        # Global error handler
├── utils/
│   ├── emailBuilder.js        # HTML email template builder
│   └── logger.js              # Structured logger (pino/winston)
└── .env
```

---

## API Endpoints

### `POST /api/send-email`

Dispatches an HTML email via Gmail SMTP.

**Request body:**

```json
{
  "to": "recipient@example.com",
  "subject": "Workflow Notification",
  "body": "Optional plain text body",
  "requestId": "REQ-20240523-001",
  "formData": [
    { "label": "Employee Name", "value": "Alice Johnson" },
    { "label": "Leave Type", "value": "Annual" }
  ],
  "attachments": [
    {
      "name": "leave-policy.pdf",
      "size": 204800,
      "data": "data:application/pdf;base64,JVBERi0x..."
    }
  ],
  "managerDecision": "approved",
  "managerComments": "Approved. Enjoy your leave."
}
```

**Success response (200):**

```json
{
  "success": true,
  "messageId": "<abc123@mail.gmail.com>",
  "message": "Email successfully sent to recipient@example.com with 2 form field(s) and 1 attachment(s)"
}
```

**Validation error response (400):**

```json
{
  "success": false,
  "error": "The mail is not getting sent: Invalid or missing email address \"bad-email\""
}
```

---

### `POST /api/webhook/form`

Accepts external form submissions from third-party form providers.

**Request body:** Any valid JSON object (raw form payload)

**Success response (200):**

```json
{
  "success": true,
  "message": "Form submission received successfully"
}
```

---

### `GET /api/webhook/form/latest`

Returns the most recent form submission received via the webhook endpoint.

**Success response (200):**

```json
{
  "success": true,
  "submission": {
    "receivedAt": "2024-05-23T10:30:00.000Z",
    "data": {
      "employee_name": "Alice Johnson",
      "leave_type": "annual",
      "days_requested": 5
    }
  }
}
```

**Not found response (404):**

```json
{
  "success": false,
  "message": "No form submissions found yet"
}
```

---

### `GET /api/health`

Health check endpoint for monitoring and deployment readiness probes.

**Response (200):**

```json
{
  "status": "ok",
  "smtp_user": "configured"
}
```

If `SMTP_USER` is not set: `"smtp_user": "NOT configured"`

---

## Request Validation Pipeline

### Current Validation (Email Endpoint)

```javascript
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
if (!to || !emailRegex.test(to)) {
  return res.status(400).json({
    success: false,
    error: `Invalid or missing email address "${to || ''}"`
  });
}
```

### Recommended Production Validation (Zod)

```javascript
import { z } from 'zod';

const sendEmailSchema = z.object({
  to: z.string().email('Invalid recipient email'),
  subject: z.string().min(1).max(200).optional(),
  body: z.string().max(10000).optional(),
  requestId: z.string().max(100).optional(),
  formData: z.array(z.object({
    label: z.string().max(200),
    value: z.string().max(5000),
  })).max(100).optional(),
  attachments: z.array(z.object({
    name: z.string().max(255),
    size: z.number().max(10 * 1024 * 1024), // 10MB max per attachment
    data: z.string().startsWith('data:'),
  })).max(10).optional(),
  managerDecision: z.enum(['approved', 'rejected']).optional(),
  managerComments: z.string().max(2000).optional(),
});
```

---

## Email Dispatch Engine

### HTML Email Template

The backend assembles a fully styled HTML email using string template literals. The email structure:

```
┌─────────────────────────────────────────┐
│  Header: Gradient banner with brand name │
├─────────────────────────────────────────┤
│  Request Reference block (if requestId)  │
├─────────────────────────────────────────┤
│  Form Details table (if formData)        │
│  (alternating row colours)               │
├─────────────────────────────────────────┤
│  Manager Review block (if decision)      │
│  (green=approved / red=rejected)         │
├─────────────────────────────────────────┤
│  Attached Files list (if attachments)    │
├─────────────────────────────────────────┤
│  Footer: "Sent by Antigravity Workflow"  │
└─────────────────────────────────────────┘
```

### Attachment Handling

Attachments are sent as base64-encoded data URLs from the frontend. The backend:

1. Parses each attachment's `data` field using the regex: `/^data:(.+);base64,(.+)$/`
2. Extracts the MIME type (`matches[1]`) and base64 content (`matches[2]`)
3. Passes them to Nodemailer as `{ filename, content, encoding: 'base64', contentType }`

Maximum payload size is configured at `25MB` (`express.json({ limit: '25mb' })`).

### SMTP Fallback (Development Only)

If `transporter.sendMail()` throws (e.g. invalid credentials in dev), the handler catches the error and returns a simulated success response with a randomly generated `messageId` prefixed `simulated-`. This allows end-to-end workflow testing without valid SMTP credentials.

**This fallback must be removed or disabled in production.**

---

## Webhook Handling

### In-Memory Form Store

```javascript
let latestFormPayload = null;    // Most recent submission
const formSubmissions = [];      // All submissions (append-only)
```

**Limitations:**
- Data is lost on server restart
- Not suitable for concurrent deployments (multiple instances have separate memory)
- No submission deduplication

**Production replacement:** Redis or PostgreSQL with a `form_submissions` table.

### Webhook Payload Processing

```javascript
app.post('/api/webhook/form', (req, res) => {
  const payload = req.body;
  latestFormPayload = {
    receivedAt: new Date().toISOString(),
    data: payload
  };
  formSubmissions.push(latestFormPayload);
  res.json({ success: true });
});
```

---

## SMTP Configuration

### Nodemailer Transport

```javascript
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,  // Gmail App Password
  },
});
```

### Startup Verification

On server start, `transporter.verify()` is called to confirm SMTP connectivity. A success or failure message is logged. This is a non-blocking operation — the server starts regardless.

### Gmail App Password Requirements

Standard Gmail passwords do not work with Nodemailer. A 16-character App Password must be generated:
1. Enable 2-Step Verification on the Google account
2. Generate an App Password at [https://myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords)
3. Use the generated password as `SMTP_PASS`

For production, consider migrating to an SMTP relay service (SendGrid, Mailgun, AWS SES) for better deliverability, rate limits, and credential management.

---

## Environment Variables

| Variable | Required | Example | Description |
|----------|----------|---------|-------------|
| `SMTP_USER` | Yes | `sender@gmail.com` | Gmail account address |
| `SMTP_PASS` | Yes | `xxxx xxxx xxxx xxxx` | Gmail App Password |
| `SMTP_FROM` | No | `sender@gmail.com` | From address (defaults to SMTP_USER) |
| `PORT` | No | `3001` | Express listen port (default: 3001) |

All variables are loaded via `dotenv.config()` at startup. The `.env` file must never be committed to version control.

---

## Error Handling

### Route-Level Error Handling

Each route handler uses try/catch. On error:

```javascript
try {
  const info = await transporter.sendMail(mailOptions);
  return res.json({ success: true, messageId: info.messageId });
} catch (err) {
  // Log error details server-side (never expose to client)
  console.log(`⚠️ SMTP Error: ${err.message}`);
  // Fallback or error response
  return res.status(500).json({ success: false, error: 'Email dispatch failed' });
}
```

### Recommended Global Error Handler

```javascript
// Catch all unhandled errors
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err.message);
  res.status(err.status || 500).json({
    success: false,
    error: process.env.NODE_ENV === 'production' ? 'Internal server error' : err.message,
  });
});
```

---

## Logging

### Current Logging

The backend uses `console.log` / `console.error` with emoji prefixes for readability:

```
✅ SMTP connection verified – ready to send emails
📧 Received send-email payload: { to, subject, requestId, ... }
📧 Email sent to alice@example.com — Message ID: <abc@mail.gmail.com>
📥 Received external form submission: { ... }
⚠️ SMTP Error: Invalid credentials
```

### Production Logging (Recommended)

Replace `console.log` with a structured logger (pino or winston):

```javascript
import pino from 'pino';
const logger = pino({ level: process.env.LOG_LEVEL || 'info' });

logger.info({ to, subject, requestId }, 'Email dispatch initiated');
logger.error({ err: err.message }, 'SMTP dispatch failed');
```

**Never log:** SMTP credentials, full email bodies (PII), attachment content, JWT tokens. See [PII_LOGGING.md](./PII_LOGGING.md).

---

## Security Middleware

### Current State

- `cors()` — permissive, all origins allowed
- `express.json({ limit: '25mb' })` — body parsing with size limit

### Production Requirements

```javascript
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';

// Security headers
app.use(helmet());

// CORS — restrict to frontend origin
app.use(cors({ origin: process.env.FRONTEND_URL, credentials: true }));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100,                  // 100 requests per window
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api/', limiter);

// Email endpoint stricter limit
const emailLimiter = rateLimit({ windowMs: 60 * 1000, max: 10 });
app.use('/api/send-email', emailLimiter);
```

---

## Production Deployment

### PM2 (Recommended for VPS)

```bash
pm2 start backend/server.js --name antigravity-backend --env production
pm2 save
pm2 startup
```

### Docker

```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY server.js .
EXPOSE 3001
CMD ["node", "server.js"]
```

```bash
docker build -t antigravity-backend .
docker run -d -p 3001:3001 \
  -e SMTP_USER=your@gmail.com \
  -e SMTP_PASS=xxxxxxxxxxxx \
  -e SMTP_FROM=your@gmail.com \
  antigravity-backend
```

### Reverse Proxy (Nginx)

```nginx
server {
  listen 443 ssl;
  server_name api.your-domain.com;

  location /api/ {
    proxy_pass http://localhost:3001;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
  }
}
```

---

## Scalability Strategy

### Current Limitations

| Concern | Current State | Impact |
|---------|--------------|--------|
| Form store | In-memory only | Lost on restart; breaks with multiple instances |
| SMTP | Single Gmail account | Rate-limited (500/day free tier) |
| No queue | Synchronous email dispatch | High latency, no retry |
| No auth | Open endpoints | Abuse risk |

### Production Scalability Path

1. **Persistent form store:** Replace `latestFormPayload` with Redis (`ioredis`) or PostgreSQL table
2. **Email queue:** Use Bull (Redis-backed) to queue emails asynchronously with retry logic
3. **SMTP upgrade:** Switch to SendGrid/Mailgun/AWS SES for higher volume and analytics
4. **Horizontal scaling:** Session-less stateless API scales horizontally behind a load balancer once in-memory store is removed
5. **Authentication:** Add JWT middleware to protect `/api/send-email` and webhook endpoints

---

## Recommended Production Enhancements

| Feature | Package | Priority |
|---------|---------|---------|
| Input validation | `zod` | High |
| Rate limiting | `express-rate-limit` | High |
| Security headers | `helmet` | High |
| Structured logging | `pino` | High |
| Email queue | `bull` + Redis | Medium |
| Authentication | `jsonwebtoken` | High |
| Request tracing | `uuid` per request | Medium |
| Health checks | Custom middleware | Medium |
| Persistent store | `ioredis` or `pg` | Medium |
| HTTPS enforcement | Nginx / reverse proxy | High |
