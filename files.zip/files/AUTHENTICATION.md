# Authentication Documentation

> JWT-based authentication design for the Antigravity Workflow Orchestration platform

---

> **Current State:** The application does not implement authentication — it operates as a single-user local tool. This document specifies the authentication architecture required for multi-user production deployment.

---

## Table of Contents

- [Authentication Overview](#authentication-overview)
- [JWT Authentication Flow](#jwt-authentication-flow)
- [Login Flow](#login-flow)
- [Token Architecture](#token-architecture)
- [Refresh Token Strategy](#refresh-token-strategy)
- [Session Handling](#session-handling)
- [Access Control](#access-control)
- [Role-Based Authorization](#role-based-authorization)
- [Permission Model](#permission-model)
- [Secure Password Storage](#secure-password-storage)
- [Token Expiration Handling](#token-expiration-handling)
- [Logout Flow](#logout-flow)
- [Multi-Session Handling](#multi-session-handling)
- [Secure Cookie Strategy](#secure-cookie-strategy)
- [CSRF Protection](#csrf-protection)
- [Authentication Middleware](#authentication-middleware)
- [OAuth Integration](#oauth-integration)

---

## Authentication Overview

The recommended authentication system uses:

- **JWT (JSON Web Tokens)** for stateless access token verification
- **Refresh tokens** stored in HttpOnly cookies for session persistence
- **bcrypt** for password hashing (never store plaintext)
- **RBAC (Role-Based Access Control)** for workflow and execution permissions

```
Client                          Backend
  │                               │
  │  POST /api/v1/auth/login      │
  │  { email, password }  ───────►│
  │                               │  Validate credentials
  │                               │  Issue accessToken (15m)
  │                               │  Issue refreshToken (7d)
  │◄─── { accessToken }  ─────────│
  │     Set-Cookie: refreshToken  │
  │                               │
  │  GET /api/v1/workflows        │
  │  Authorization: Bearer <AT>  ►│
  │                               │  Verify JWT signature
  │                               │  Check expiry
  │◄─── { data }  ────────────────│
```

---

## JWT Authentication Flow

### Token Issuance

On successful login, the backend issues two tokens:

| Token | Type | Storage | Expiry | Purpose |
|-------|------|---------|--------|---------|
| Access Token | JWT | In-memory (React state) | 15 minutes | Authenticate API requests |
| Refresh Token | Opaque | HttpOnly cookie | 7 days | Obtain new access tokens |

### JWT Payload Structure

```json
{
  "sub": "user-uuid-here",
  "email": "alice@example.com",
  "role": "workflow_admin",
  "iat": 1716460000,
  "exp": 1716460900
}
```

**Never include in JWT payload:** passwords, plaintext credentials, PII beyond email, sensitive workflow data.

### JWT Signing

```javascript
import jwt from 'jsonwebtoken';

const accessToken = jwt.sign(
  { sub: user.id, email: user.email, role: user.role },
  process.env.JWT_SECRET,           // Min 256-bit secret
  { expiresIn: '15m', algorithm: 'HS256' }
);
```

Use `RS256` (asymmetric) for multi-service architectures where other services need to verify tokens without the secret.

---

## Login Flow

```
1. User submits { email, password } to POST /api/v1/auth/login

2. Backend:
   a. Lookup user by email (timing-safe — always hash even if not found)
   b. Compare password with bcrypt.compare(password, user.passwordHash)
   c. On failure: return 401 { error: "Invalid credentials" }
      (never specify whether email or password was wrong)
   d. On success:
      - Generate accessToken (JWT, 15m)
      - Generate refreshToken (crypto.randomBytes(64).toString('hex'))
      - Store hashed refreshToken in database with userId and expiry
      - Set refreshToken as HttpOnly, Secure, SameSite=Strict cookie
      - Return { accessToken, user: { id, email, role, name } }

3. Frontend:
   a. Store accessToken in React state (memory only)
   b. Store user metadata in React state
   c. Set up axios/fetch interceptor to attach Authorization header
```

### Login Request

```http
POST /api/v1/auth/login
Content-Type: application/json

{
  "email": "alice@example.com",
  "password": "userPassword123"
}
```

### Login Response

```json
{
  "success": true,
  "accessToken": "eyJhbGci...",
  "user": {
    "id": "usr_abc123",
    "email": "alice@example.com",
    "name": "Alice Johnson",
    "role": "workflow_admin"
  }
}
```

### Login Error Response

```json
{
  "success": false,
  "error": "Invalid credentials"
}
```

Always use a generic message — never indicate whether the email or password was wrong.

---

## Token Architecture

### Access Token (JWT)

- Short-lived (15 minutes)
- Stored in JavaScript memory only (React `useState`)
- Attached as `Authorization: Bearer <token>` header on every API request
- Verified server-side on every protected request
- Never stored in `localStorage`, `sessionStorage`, or cookies (XSS risk)

### Refresh Token

- Long-lived (7 days)
- Stored as an `HttpOnly; Secure; SameSite=Strict` cookie
- Not accessible via JavaScript (XSS-safe)
- Opaque random string (not a JWT)
- Stored as a bcrypt hash in the database (theft-safe)
- Single-use or sliding window depending on security requirements

---

## Refresh Token Strategy

When the access token expires (or on app startup), the frontend automatically requests a new one:

```javascript
// Interceptor: retry with refresh if 401
async function fetchWithRefresh(url, options) {
  let response = await fetch(url, options);

  if (response.status === 401) {
    // Attempt token refresh (cookie is sent automatically)
    const refreshResponse = await fetch('/api/v1/auth/refresh', {
      method: 'POST',
      credentials: 'include',  // Send HttpOnly cookie
    });

    if (refreshResponse.ok) {
      const { accessToken } = await refreshResponse.json();
      setAccessToken(accessToken);  // Update React state
      // Retry original request
      response = await fetch(url, {
        ...options,
        headers: { ...options.headers, Authorization: `Bearer ${accessToken}` },
      });
    } else {
      // Refresh token expired — redirect to login
      redirectToLogin();
    }
  }

  return response;
}
```

### Refresh Endpoint

```http
POST /api/v1/auth/refresh
Cookie: refreshToken=<opaque-token>

Response (200):
{
  "success": true,
  "accessToken": "eyJhbGci..."
}

Response (401 — refresh token expired/invalid):
{
  "success": false,
  "error": "Session expired. Please log in again."
}
```

---

## Session Handling

- Sessions are **stateless on the access token side** — the backend verifies JWTs without a database lookup
- Sessions are **stateful on the refresh token side** — the database records active refresh tokens
- A user can be forcibly logged out by deleting their refresh token record from the database

### Session Expiry Behaviour

| Scenario | Outcome |
|----------|---------|
| Access token expires (15m) | Silently refreshed using cookie |
| Refresh token expires (7d) | User redirected to login |
| User logs out | Both tokens invalidated |
| Admin revokes session | Refresh token deleted from DB |

---

## Access Control

API routes are protected by two layers:

1. **Authentication middleware** — verifies JWT is valid and not expired
2. **Authorization middleware** — checks the user's role against the required permission

```javascript
// Protect all workflow routes
router.use('/api/v1/workflows', authenticate, authorize('workflow:read'));

// Protect execution routes
router.post('/api/v1/workflows/:id/execute', authenticate, authorize('workflow:execute'));
```

---

## Role-Based Authorization

### Roles

| Role | Description |
|------|-------------|
| `super_admin` | Full system access including user management |
| `workflow_admin` | Create, edit, delete, and execute any workflow |
| `workflow_editor` | Create and edit own workflows; execute any |
| `workflow_viewer` | View workflows and execution history; no edit/execute |
| `form_user` | Submit form data only; no canvas access |
| `manager` | Access manager approval view; no canvas access |

### Role Hierarchy

```
super_admin
    └── workflow_admin
            └── workflow_editor
                    └── workflow_viewer
                            └── form_user / manager
```

---

## Permission Model

| Resource | Action | Minimum Role |
|---------|--------|-------------|
| Workflow canvas | View | `workflow_viewer` |
| Workflow canvas | Edit nodes/edges | `workflow_editor` |
| Workflow canvas | Create workflow | `workflow_editor` |
| Workflow canvas | Delete workflow | `workflow_admin` |
| Execution | Trigger | `workflow_editor` |
| Execution history | View | `workflow_viewer` |
| Form popup | Submit | `form_user` |
| Manager approval | Submit decision | `manager` |
| User management | CRUD | `super_admin` |
| System config | Edit | `super_admin` |

---

## Secure Password Storage

```javascript
import bcrypt from 'bcrypt';

const SALT_ROUNDS = 12; // ~250ms on modern hardware

// On registration / password change:
const passwordHash = await bcrypt.hash(plaintext, SALT_ROUNDS);
await db.users.update({ id: userId }, { passwordHash });

// On login:
const isValid = await bcrypt.compare(candidatePassword, user.passwordHash);
```

**Rules:**
- Minimum password length: 12 characters
- Require complexity (uppercase, lowercase, number, symbol) or use passphrase policy
- Never log or transmit plaintext passwords
- Use bcrypt with ≥ 10 salt rounds (12 recommended)
- Hash at the same cost even when the user is not found (prevent timing attacks)

---

## Token Expiration Handling

| Scenario | Frontend Behaviour |
|----------|-------------------|
| Access token expires mid-request | Interceptor catches 401, refreshes token, retries |
| Refresh token expired | Clear in-memory state, redirect to `/login` |
| Refresh endpoint returns 401 | Clear all state, redirect to `/login` |
| User idle > 7 days | Next refresh attempt fails, redirect to login |

---

## Logout Flow

```
1. User clicks "Logout"

2. Frontend:
   a. Call POST /api/v1/auth/logout (sends cookie automatically)
   b. Clear accessToken from React state
   c. Clear all user state
   d. Redirect to /login

3. Backend:
   a. Read refreshToken from cookie
   b. Delete the refresh token record from database
   c. Set Set-Cookie: refreshToken=; Max-Age=0 (clear cookie)
   d. Return 200 { success: true }
```

---

## Multi-Session Handling

Each login creates a new refresh token record tied to a device/session identifier:

```json
{
  "id": "rt_abc123",
  "userId": "usr_456",
  "tokenHash": "bcrypt_hash_here",
  "deviceInfo": "Chrome 124 / macOS",
  "createdAt": "2024-05-23T10:00:00Z",
  "expiresAt": "2024-05-30T10:00:00Z",
  "lastUsedAt": "2024-05-23T12:30:00Z"
}
```

Users can view and revoke active sessions from a "Security" settings page.

---

## Secure Cookie Strategy

```javascript
res.cookie('refreshToken', token, {
  httpOnly: true,       // Not accessible via JavaScript
  secure: true,         // HTTPS only
  sameSite: 'Strict',   // No cross-site requests
  maxAge: 7 * 24 * 60 * 60 * 1000,  // 7 days in ms
  path: '/api/v1/auth', // Scoped to auth endpoints only
});
```

---

## CSRF Protection

Since the refresh token is in an `HttpOnly` cookie with `SameSite=Strict`, CSRF attacks cannot trigger a token refresh from a malicious site. For additional protection on state-changing endpoints:

- Use the **Synchronizer Token Pattern** (CSRF token in a header, not a cookie)
- Include a `X-CSRF-Token` header with all non-GET requests
- Backend validates that the header matches a session-bound token

```javascript
// Frontend: Read CSRF token from a non-HttpOnly cookie
const csrfToken = getCookie('csrfToken');
fetch('/api/v1/workflows', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${accessToken}`,
    'X-CSRF-Token': csrfToken,
  },
  ...
});
```

---

## Authentication Middleware

```javascript
// middleware/authenticate.js
import jwt from 'jsonwebtoken';

export function authenticate(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ success: false, error: 'Authentication required' });
  }

  const token = authHeader.split(' ')[1];
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = payload; // { sub, email, role, iat, exp }
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ success: false, error: 'Token expired' });
    }
    return res.status(401).json({ success: false, error: 'Invalid token' });
  }
}

// middleware/authorize.js
export function authorize(...permissions) {
  return (req, res, next) => {
    const userPermissions = getRolePermissions(req.user.role);
    const hasPermission = permissions.every(p => userPermissions.includes(p));
    if (!hasPermission) {
      return res.status(403).json({ success: false, error: 'Insufficient permissions' });
    }
    next();
  };
}
```

---

## OAuth Integration

For enterprise deployments, OAuth 2.0 / OIDC integration with Google Workspace or Microsoft Entra (Azure AD) is recommended:

```
User clicks "Sign in with Google"
         │
         ▼
Redirect to Google OAuth consent screen
         │
         ▼
Google redirects to /api/v1/auth/oauth/google/callback?code=...
         │
         ▼
Backend exchanges code for ID token
         │
         ▼
Verify ID token, extract email
         │
         ▼
Find or create user in database
         │
         ▼
Issue internal JWT + refresh token (same flow as password login)
```

Recommended library: `passport.js` with `passport-google-oauth20` or `openid-client`.
