# Error Handling Documentation

> Global error handling strategy for frontend execution, backend API, and SMTP dispatch

---

## Table of Contents

- [Error Handling Philosophy](#error-handling-philosophy)
- [Error Classification](#error-classification)
- [Frontend Error Handling](#frontend-error-handling)
- [Execution Engine Error Handling](#execution-engine-error-handling)
- [API Error Responses](#api-error-responses)
- [Authentication and Login Errors](#authentication-and-login-errors)
- [Validation Errors](#validation-errors)
- [Workflow Execution Errors](#workflow-execution-errors)
- [Node Execution Failures](#node-execution-failures)
- [Retry Logic](#retry-logic)
- [Timeout Handling](#timeout-handling)
- [Graceful Degradation](#graceful-degradation)
- [Logging Strategy](#logging-strategy)
- [Monitoring and Alerting](#monitoring-and-alerting)
- [User-Friendly Error Messages](#user-friendly-error-messages)
- [Internal vs External Errors](#internal-vs-external-errors)

---

## Error Handling Philosophy

1. **Fail fast at boundaries** — catch errors as close to the source as possible
2. **Surface clearly to users** — never swallow errors silently; show actionable UI feedback
3. **Never expose internals** — stack traces, file paths, and DB details stay server-side
4. **Log everything internally** — detailed errors logged for debugging; sanitised message shown to user
5. **Recover where possible** — distinguish fatal errors (halt execution) from transient ones (retry)

---

## Error Classification

| Class | Severity | Examples | Recovery |
|-------|----------|---------|---------|
| Validation Error | Low | Invalid email, missing required field | User corrects input |
| Configuration Error | Medium | API URL not set, form has no fields | User edits node config |
| Network Error | Medium | Backend unreachable, fetch timeout | Retry or manual re-trigger |
| SMTP Error | Medium | Invalid credentials, quota exceeded | Check credentials, retry |
| Execution Halt | High | Critical node fails, stop signal | Re-trigger from start |
| Unhandled Exception | High | Unexpected JavaScript error | Global error boundary |
| System Error | Critical | OOM, disk full, process crash | Infrastructure intervention |

---

## Frontend Error Handling

### Toast Notification System

A lightweight transient toast is used for non-blocking feedback:

```javascript
const [showToast, setShowToast] = useState(null);

function flashToast(message, type = 'info') {
  setShowToast({ message, type });
  setTimeout(() => setShowToast(null), 3000);
}

// Usage
flashToast('Email sent successfully!', 'success');
flashToast('Form submission failed. Please try again.', 'error');
```

### Global Execution Error Banner

For fatal execution errors, a persistent banner is shown above the canvas:

```javascript
const [globalExecutionError, setGlobalExecutionError] = useState('');

// Show banner
setGlobalExecutionError('Execution failed at EmailNode: Invalid recipient address');

// Clear on re-trigger
setGlobalExecutionError('');
```

### React Error Boundary (Recommended)

Wrap the application in an error boundary to catch unexpected component crashes:

```jsx
class AppErrorBoundary extends React.Component {
  state = { hasError: false, error: null };

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, info) {
    // Log to monitoring service
    console.error('React error boundary caught:', error.message, info.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="error-fallback">
          <h2>Something went wrong</h2>
          <p>Please refresh the page to continue.</p>
          <button onClick={() => window.location.reload()}>Refresh</button>
        </div>
      );
    }
    return this.props.children;
  }
}

// In main.jsx
<AppErrorBoundary>
  <App />
</AppErrorBoundary>
```

---

## Execution Engine Error Handling

The `handleTrigger()` async function uses `try/catch` at multiple levels:

### Node-Level Error Isolation

```javascript
// Per-node try/catch in the execution engine
for (const nodeId of currentLayer) {
  try {
    await executeNode(nodeId);
    markNodeStatus(nodeId, 'completed');
  } catch (err) {
    markNodeStatus(nodeId, 'error', err.message);
    setGlobalExecutionError(`Failed at node "${nodeLabel}": ${err.message}`);
    stopExecutionRef.current = true; // Signal to halt the loop
    break;
  }
}
```

### Layer-Level Error Check

```javascript
// After each layer, check if a stop signal was set
if (stopExecutionRef.current) {
  console.warn('Execution halted by stop signal');
  break; // Exit the BFS loop
}
```

### Execution Record on Error

Even failed executions write a record:

```javascript
const executionRecord = {
  runNumber: executionRuns.length + 1,
  startedAt: new Date(executionStartTime).toISOString(),
  completedAt: new Date().toISOString(),
  tat: ((Date.now() - executionStartTime) / 1000).toFixed(2),
  status: 'error',
  error: globalExecutionError,
  nodes: captureNodeStates(),
};
setAllExecutionRuns(prev => ({
  ...prev,
  [currentWorkflowId]: [...(prev[currentWorkflowId] || []), executionRecord],
}));
```

---

## API Error Responses

### Consistent Error Envelope

All backend error responses follow the same structure:

```json
{
  "success": false,
  "error": "Human-readable description",
  "code": "ERROR_CODE",
  "details": {}
}
```

### HTTP Status → Error Category Mapping

```javascript
// Frontend error handler
async function callApi(url, options) {
  const response = await fetch(url, options);
  const data = await response.json();

  if (!response.ok) {
    switch (response.status) {
      case 400:
        throw new ValidationError(data.error, data.details);
      case 401:
        throw new AuthError('Session expired. Please log in again.');
      case 403:
        throw new PermissionError('You do not have permission for this action.');
      case 404:
        throw new NotFoundError(data.error || 'Resource not found.');
      case 429:
        throw new RateLimitError('Too many requests. Please wait and try again.');
      case 500:
      default:
        throw new ServerError('A server error occurred. Please try again.');
    }
  }

  return data;
}
```

---

## Authentication and Login Errors

### Login Error Examples

```javascript
// server-side login handler (recommended implementation)
app.post('/api/v1/auth/login', async (req, res) => {
  const { email, password } = req.body;

  const user = await db.users.findByEmail(email);

  // ALWAYS hash even when user not found — timing attack prevention
  const dummyHash = '$2b$12$invalidhashforcomparisonpurposes';
  const hashToCompare = user ? user.passwordHash : dummyHash;
  const isValid = await bcrypt.compare(password, hashToCompare);

  if (!user || !isValid) {
    // Generic message — never specify which field was wrong
    return res.status(401).json({
      success: false,
      error: 'Invalid credentials',
    });
  }

  if (user.isLocked) {
    return res.status(403).json({
      success: false,
      error: 'Account is locked. Please contact support.',
    });
  }

  // Issue tokens...
});
```

### Login Error UX (Frontend)

```javascript
try {
  const result = await login(email, password);
  redirectToDashboard();
} catch (err) {
  if (err instanceof AuthError) {
    setLoginError('Incorrect email or password. Please try again.');
  } else if (err instanceof RateLimitError) {
    setLoginError('Too many login attempts. Please wait 15 minutes.');
  } else {
    setLoginError('An error occurred. Please try again later.');
  }
}
```

**UI rules for login errors:**
- Never indicate which field (email vs password) was wrong
- Lock the form for 30 seconds after 5 failed attempts (client-side throttle)
- Show a generic "account locked" message if backend returns 403
- Never expose internal server errors to the login form

---

## Validation Errors

### Frontend Validation Error Display

```javascript
// Inline field-level errors
const [fieldErrors, setFieldErrors] = useState({});

function handleSubmit() {
  const errors = validateFormData(formValues);
  if (Object.keys(errors).length > 0) {
    setFieldErrors(errors);
    return; // Do not submit
  }
  submitForm(formValues);
}

// In JSX
<input ... />
{fieldErrors.email && (
  <span className="field-error" role="alert">{fieldErrors.email}</span>
)}
```

### Backend Validation Error Response

```json
{
  "success": false,
  "error": "Validation failed",
  "details": {
    "to": "Invalid recipient email address",
    "attachments[1].size": "File exceeds 10MB limit",
    "managerDecision": "Must be 'approved' or 'rejected'"
  }
}
```

### Execution-Time Validation Error

When a node fails validation at execution time:

```javascript
// Node visual: red border + error tooltip
setNodes(nds => nds.map(n => n.id === nodeId ? {
  ...n,
  data: {
    ...n.data,
    execStatus: 'error',
    execError: 'Invalid recipient email: john@invalid',
  }
} : n));

// Global banner
setGlobalExecutionError('Email node failed: Invalid recipient address');
```

---

## Workflow Execution Errors

### Error Categories in Execution

| Error Type | Cause | Handling |
|-----------|-------|---------|
| Config error | Missing/invalid node config | Mark node error, halt |
| Network error | API call or email dispatch failed | Mark node error, halt |
| Timeout error | Interactive node not resolved | Mark node error, halt (if timeout configured) |
| Stop signal | User switched to editor mid-execution | Gracefully halt, reset statuses |
| SMTP error | Backend returned non-success | Mark email node error, halt |
| Webhook 404 | No form submission received yet | Mark API node error, halt |

### Stop Signal Handling

When the user switches to editor mode during execution:

```javascript
// Resolve all pending interactive node promises (unblock the loop)
Object.values(formResolvers.current).forEach(resolve => resolve());
Object.values(managerResolvers.current).forEach(resolve => resolve());
Object.values(emailResolvers.current).forEach(resolve => resolve());
formResolvers.current = {};
managerResolvers.current = {};
emailResolvers.current = {};

// Set stop signal
stopExecutionRef.current = true;

// Reset all node statuses
setNodes(nds => nds.map(n => ({
  ...n,
  data: { ...n.data, execStatus: 'idle', execError: undefined, appMode: 'editor' }
})));
```

---

## Node Execution Failures

### API Call Node Failure

```javascript
// In execution engine
try {
  const response = await fetch(resolvedUrl, fetchOptions);
  if (!response.ok) {
    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
  }
  const result = await response.json();
  markNodeCompleted(nodeId, { apiResponse: result });
} catch (err) {
  markNodeError(nodeId, `API call failed: ${err.message}`);
  throw err; // Re-throw to halt execution layer
}
```

### Email Node Failure

```javascript
try {
  const result = await fetch('/api/send-email', { method: 'POST', body: payload });
  const data = await result.json();
  if (!data.success) {
    throw new Error(data.error || 'Email dispatch failed');
  }
  markNodeCompleted(nodeId);
} catch (err) {
  markNodeError(nodeId, `Email failed: ${err.message}`);
  throw err;
}
```

### Form Node Failure (Timeout — Planned)

```javascript
// Wrap the form wait in a race with a timeout
const FORM_TIMEOUT_MS = 30 * 60 * 1000; // 30 minutes

await Promise.race([
  new Promise(resolve => { formResolvers.current[nodeId] = resolve; }),
  new Promise((_, reject) => setTimeout(() => reject(new Error('Form submission timed out')), FORM_TIMEOUT_MS)),
]);
```

---

## Retry Logic

### Current State

The frontend does not implement automatic retries. On failure, the user must re-trigger the workflow.

### Recommended Retry Strategy

For transient network errors (not validation errors):

```javascript
async function fetchWithRetry(url, options, maxRetries = 3) {
  let lastError;
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const response = await fetch(url, options);
      if (!response.ok && response.status >= 500) {
        throw new Error(`Server error: ${response.status}`);
      }
      return response;
    } catch (err) {
      lastError = err;
      if (attempt < maxRetries) {
        const delay = Math.min(1000 * Math.pow(2, attempt - 1), 8000); // Exponential backoff, max 8s
        const jitter = Math.random() * 500;
        await new Promise(resolve => setTimeout(resolve, delay + jitter));
      }
    }
  }
  throw lastError;
}
```

**Do not retry on:**
- 400 Bad Request (validation error — fix the input)
- 401 Unauthorized (auth issue — refresh token instead)
- 403 Forbidden (permission issue)
- 404 Not Found

**Do retry on:**
- 500 / 502 / 503 / 504 (transient server error)
- Network timeout (`AbortError`)
- Connection refused (backend temporarily down)

---

## Timeout Handling

### Fetch Timeout

```javascript
async function fetchWithTimeout(url, options, timeoutMs = 30000) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, { ...options, signal: controller.signal });
    clearTimeout(timeoutId);
    return response;
  } catch (err) {
    clearTimeout(timeoutId);
    if (err.name === 'AbortError') {
      throw new Error('Request timed out after 30 seconds');
    }
    throw err;
  }
}
```

### Email Dispatch Timeout

The email endpoint involves SMTP communication which can be slow. Configure a 60-second timeout for email dispatch:

```javascript
// Apply 60s timeout to email fetch
const emailResponse = await fetchWithTimeout('/api/send-email', emailOptions, 60000);
```

---

## Graceful Degradation

### SMTP Fallback (Current — Development Only)

If SMTP dispatch fails, the backend currently returns a simulated success. This is intentional for development but **must be removed or gated for production**:

```javascript
// Production: remove the fallback, return proper error
} catch (err) {
  logger.error({ err: err.message, to }, 'SMTP dispatch failed');
  return res.status(502).json({
    success: false,
    error: 'Email delivery failed. Please try again later.',
  });
}
```

### UI Graceful Degradation

If the backend is unreachable when the app loads:

```javascript
// Health check on startup
async function checkBackendHealth() {
  try {
    const resp = await fetchWithTimeout('/api/health', {}, 5000);
    const data = await resp.json();
    if (data.smtp_user === 'NOT configured') {
      flashToast('Email dispatch is not configured. Email nodes will simulate.', 'warning');
    }
  } catch {
    flashToast('Backend server is offline. Email nodes will not function.', 'error');
  }
}
```

---

## Logging Strategy

### Current Backend Logging

```javascript
// Current: console.log with emojis (development friendly)
console.log('📧 Email sent to alice@example.com — Message ID: <abc@mail.gmail.com>');
console.log(`⚠️ SMTP Error: Connection refused`);
```

### Production Logging (Recommended — pino)

```javascript
import pino from 'pino';

const logger = pino({
  level: process.env.LOG_LEVEL || 'info',
  transport: process.env.NODE_ENV === 'development'
    ? { target: 'pino-pretty' }
    : undefined,
});

// Usage
logger.info({ recipientDomain: to.split('@')[1], fieldCount: formData?.length }, 'Email dispatched');
logger.error({ err: err.message, endpoint: '/api/send-email' }, 'Email dispatch failed');
logger.warn({ endpoint: '/api/webhook/form', payloadKeys: Object.keys(payload) }, 'Webhook received');
```

**See [PII_LOGGING.md](./PII_LOGGING.md) for what must never be logged.**

---

## Monitoring and Alerting

### Recommended Alerts

| Metric | Threshold | Alert |
|--------|-----------|-------|
| SMTP error rate | > 5% of email requests | PagerDuty / Slack |
| API 5xx rate | > 1% in 5 minutes | PagerDuty |
| Rate limit hits | > 50 in 1 minute | Slack warning |
| Backend downtime | Health check fails for 2 minutes | PagerDuty / SMS |
| Response time P99 | > 10 seconds | Slack warning |

### Error Tracking

Integrate Sentry for real-time error capture:

```javascript
// Backend (Node.js)
import * as Sentry from '@sentry/node';
Sentry.init({ dsn: process.env.SENTRY_DSN, environment: process.env.NODE_ENV });

// Frontend (React)
import * as Sentry from '@sentry/react';
Sentry.init({ dsn: process.env.VITE_SENTRY_DSN });
```

---

## User-Friendly Error Messages

Map internal errors to user-facing messages:

| Internal Error | User-Facing Message |
|---------------|-------------------|
| `ECONNREFUSED` (backend down) | "Service temporarily unavailable. Please try again." |
| `TokenExpiredError` | "Your session has expired. Please log in again." |
| `SMTP EAUTH` (bad credentials) | "Email delivery is not configured correctly. Please contact support." |
| `ValidationError: invalid email` | "Please enter a valid email address." |
| `404 Not Found` | "The requested item could not be found." |
| `AbortError` (timeout) | "The request took too long. Please try again." |
| `TypeError: Failed to fetch` | "Cannot connect to the server. Check your connection." |

---

## Internal vs External Errors

### Never expose to clients:

- Stack traces (`err.stack`)
- File system paths (`/home/user/app/server.js:42`)
- Database query details (`SELECT * FROM users WHERE...`)
- Internal IP addresses or host names
- Environment variable names or values
- Third-party API keys or credentials

### Always log internally (not returned to client):

```javascript
// Server-side error handler
app.use((err, req, res, next) => {
  // Log full details internally
  logger.error({
    err: err.message,
    stack: err.stack,     // Internal log only
    url: req.url,
    method: req.method,
    userId: req.user?.sub,
  }, 'Unhandled error');

  // Return sanitised message to client
  res.status(err.status || 500).json({
    success: false,
    error: process.env.NODE_ENV === 'production'
      ? 'An internal error occurred. Please try again later.'
      : err.message,    // Dev only: show actual message for debugging
  });
});
```
