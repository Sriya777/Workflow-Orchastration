# Validation Documentation

> Input validation strategy for frontend, backend, and workflow execution layers

---

## Table of Contents

- [Validation Philosophy](#validation-philosophy)
- [Validation Layers](#validation-layers)
- [Frontend Validation](#frontend-validation)
- [Backend Validation](#backend-validation)
- [Schema Validation with Zod](#schema-validation-with-zod)
- [Form Validation Rules](#form-validation-rules)
- [Workflow Node Validation](#workflow-node-validation)
- [API Payload Validation](#api-payload-validation)
- [Type Validation](#type-validation)
- [Sanitisation](#sanitisation)
- [Error Message Structure](#error-message-structure)
- [Validation Middleware](#validation-middleware)
- [Runtime Validation](#runtime-validation)
- [Approval Form Validation](#approval-form-validation)
- [URL Validation](#url-validation)
- [Preventing Malicious Input](#preventing-malicious-input)

---

## Validation Philosophy

Validation is applied at **every boundary** where data enters the system:

- When a user types in the canvas (editor config)
- When a user submits a form during execution
- When a manager submits an approval decision
- When an API payload arrives at the backend
- When an external webhook delivers a form submission

**Never trust the frontend.** Backend validation is mandatory even when the frontend validates first. The two layers may use different rule implementations but should enforce the same logical constraints.

---

## Validation Layers

```
User Input
    │
    ▼
┌──────────────────────────────────────┐
│  Layer 1: Frontend Input Validation  │
│  (React state, onChange handlers)    │
│  — Immediate user feedback           │
│  — Prevent clearly invalid data      │
└──────────────────────────────────────┘
    │
    ▼
┌──────────────────────────────────────┐
│  Layer 2: Execution-Time Validation  │
│  (handleTrigger, node execution)     │
│  — Pre-flight checks before API call │
│  — Cross-node consistency checks     │
└──────────────────────────────────────┘
    │  HTTP Request
    ▼
┌──────────────────────────────────────┐
│  Layer 3: Backend Schema Validation  │
│  (Express middleware, Zod)           │
│  — Authoritative validation          │
│  — Type enforcement                  │
│  — Size and format limits            │
└──────────────────────────────────────┘
    │
    ▼
┌──────────────────────────────────────┐
│  Layer 4: Business Logic Validation  │
│  (Service layer)                     │
│  — Domain-specific rules             │
│  — Cross-field constraints           │
└──────────────────────────────────────┘
```

---

## Frontend Validation

### PropertiesPanel Validation

Configuration fields are validated in `PropertiesPanel.jsx` when the user blurs a field or saves:

#### Email Node

| Field | Rule | Error Message |
|-------|------|---------------|
| `to` | Valid email format | "Invalid email address" |
| `subject` | Non-empty, ≤ 200 chars | "Subject is required" |
| `body` | ≤ 10,000 chars | "Body exceeds maximum length" |

#### API Call Node

| Field | Rule | Error Message |
|-------|------|---------------|
| `apiUrl` | Non-empty, valid URL format | "Enter a valid URL" |
| `method` | One of `GET`, `POST`, `PUT`, `PATCH`, `DELETE` | — |
| `headers` | Valid JSON object string | "Headers must be valid JSON" |
| `body` | Valid JSON (for POST/PUT) | "Request body must be valid JSON" |

#### Form Node / FormTaskNode

| Field | Rule | Error Message |
|-------|------|---------------|
| Field label | Non-empty, ≤ 100 chars | "Field label is required" |
| Field type | Must be a known type | — |
| Min fields | At least 1 field defined | "Add at least one form field" |

### Inline Validation Pattern (React)

```javascript
function EmailNodeConfig({ data, onUpdate }) {
  const [toError, setToError] = useState('');

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  const handleToChange = (e) => {
    const value = e.target.value;
    if (value && !emailRegex.test(value)) {
      setToError('Invalid email address');
    } else {
      setToError('');
    }
    onUpdate({ ...data, to: value });
  };

  return (
    <div>
      <input value={data.to || ''} onChange={handleToChange} />
      {toError && <span className="field-error">{toError}</span>}
    </div>
  );
}
```

---

## Backend Validation

### Current Validation (`server.js`)

The only validation currently implemented in the backend is recipient email format checking:

```javascript
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
if (!to || !emailRegex.test(to)) {
  return res.status(400).json({
    success: false,
    error: `The mail is not getting sent: Invalid or missing email address "${to || ''}"`,
  });
}
```

This is insufficient for production. A full Zod-based validation schema is required.

---

## Schema Validation with Zod

### Installation

```bash
npm install zod
```

### Send Email Schema

```javascript
import { z } from 'zod';

const AttachmentSchema = z.object({
  name: z.string().min(1).max(255),
  size: z.number().int().min(0).max(10 * 1024 * 1024), // 10MB max
  data: z.string().regex(/^data:[a-z/+]+;base64,/, 'Invalid data URL format'),
});

const FormFieldSchema = z.object({
  label: z.string().min(1).max(200),
  value: z.string().max(5000),
});

export const SendEmailSchema = z.object({
  to: z.string().email('Invalid recipient email address'),
  subject: z.string().min(1).max(200).optional(),
  body: z.string().max(10000).optional(),
  requestId: z.string().max(100).optional(),
  formData: z.array(FormFieldSchema).max(100).optional(),
  attachments: z.array(AttachmentSchema).max(10).optional(),
  managerDecision: z.enum(['approved', 'rejected']).optional(),
  managerComments: z.string().max(2000).optional(),
}).strict(); // Reject unknown fields
```

### Webhook Schema

```javascript
export const WebhookFormSchema = z.record(z.string(), z.unknown())
  .refine(obj => Object.keys(obj).length > 0, 'Webhook payload cannot be empty')
  .refine(obj => Object.keys(obj).length <= 200, 'Too many fields in payload');
```

---

## Form Validation Rules

### Built-in Form Field Types and Rules

| Field Type | Validation Rules |
|-----------|-----------------|
| `text` | Non-empty if required, max 1000 chars |
| `email` | Valid email format |
| `number` | Must be numeric; optionally min/max |
| `date` | Valid ISO date format |
| `textarea` | Max 5000 chars |
| `select` | Value must be one of the configured options |
| `file` | Max 10MB; allowed MIME types enforced |
| `url` | Valid URL format; must start with https:// |

### Required Field Enforcement

```javascript
function validateFormSubmission(fields, values) {
  const errors = {};
  for (const field of fields) {
    if (field.required && !values[field.id]) {
      errors[field.id] = `${field.label} is required`;
    }
    if (field.type === 'email' && values[field.id]) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(values[field.id])) {
        errors[field.id] = 'Invalid email address';
      }
    }
    if (field.type === 'number' && values[field.id]) {
      if (isNaN(Number(values[field.id]))) {
        errors[field.id] = 'Must be a number';
      }
    }
  }
  return errors;
}
```

---

## Workflow Node Validation

### Pre-Execution Validation (Planned)

Before triggering workflow execution, the engine should validate all configured nodes:

```javascript
function validateWorkflow(nodes, edges) {
  const errors = [];

  for (const node of nodes) {
    if (node.type === 'emailNode') {
      if (!node.data.to) errors.push({ nodeId: node.id, field: 'to', message: 'Recipient email required' });
      if (node.data.to && !isValidEmail(node.data.to)) errors.push({ nodeId: node.id, field: 'to', message: 'Invalid email' });
    }
    if (node.type === 'apiCall') {
      if (!node.data.apiUrl) errors.push({ nodeId: node.id, field: 'apiUrl', message: 'API URL required' });
    }
    if (node.type === 'formNode' || node.type === 'formTask') {
      if (!node.data.fields || node.data.fields.length === 0) {
        errors.push({ nodeId: node.id, message: 'Form node must have at least one field' });
      }
    }
  }

  // Structural validation
  const startNodes = nodes.filter(n => n.type === 'antigravity');
  if (startNodes.length === 0) errors.push({ message: 'Workflow must have a Start node' });
  if (startNodes.length > 1) errors.push({ message: 'Workflow cannot have multiple Start nodes' });

  return errors;
}
```

---

## API Payload Validation

### Validation Middleware

```javascript
// middleware/validate.js
export function validate(schema) {
  return (req, res, next) => {
    const result = schema.safeParse(req.body);
    if (!result.success) {
      const details = {};
      for (const issue of result.error.issues) {
        const path = issue.path.join('.');
        details[path] = issue.message;
      }
      return res.status(400).json({
        success: false,
        error: 'Validation failed',
        details,
      });
    }
    req.body = result.data; // Replace with parsed (sanitised) data
    next();
  };
}
```

### Apply to Route

```javascript
import { validate } from './middleware/validate.js';
import { SendEmailSchema } from './schemas/email.schema.js';

app.post('/api/send-email', validate(SendEmailSchema), async (req, res) => {
  // req.body is now fully validated and typed
  const { to, subject, formData, attachments, managerDecision, managerComments } = req.body;
  // ...
});
```

---

## Type Validation

### Frontend (TypeScript — Planned)

The project uses JSX without TypeScript. Adding TypeScript types would significantly improve correctness:

```typescript
interface FormField {
  id: string;
  label: string;
  type: 'text' | 'email' | 'number' | 'date' | 'textarea' | 'select' | 'file' | 'url';
  required: boolean;
  options?: string[];   // For select fields
  maxLength?: number;
}

interface NodeData {
  label?: string;
  execStatus?: 'idle' | 'running' | 'completed' | 'error' | 'waiting';
  appMode?: 'editor' | 'execution';
  to?: string;          // emailNode
  subject?: string;     // emailNode
  apiUrl?: string;      // apiCall
  method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  fields?: FormField[]; // formNode, formTask
  taskMode?: 'form1' | 'form2';
}
```

---

## Sanitisation

### String Sanitisation

```javascript
// Trim whitespace
const cleaned = input.trim();

// Remove null bytes (prevent header injection)
const noNulls = cleaned.replace(/\0/g, '');

// Limit length
const truncated = noNulls.substring(0, maxLength);
```

### Email Header Injection Prevention

SMTP headers (To, Subject, From) can be exploited via header injection if newline characters are included:

```javascript
function sanitiseEmailHeader(value) {
  return String(value || '').replace(/[\r\n\t]/g, ' ').trim().substring(0, 998);
}

const safeSubject = sanitiseEmailHeader(subject);
const safeTo = sanitiseEmailHeader(to);
```

### HTML Sanitisation for Email Body

```javascript
function escapeHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
```

---

## Error Message Structure

### User-Facing Error Messages

Error messages shown to users must be:
- **Clear** — describe what is wrong in plain language
- **Actionable** — tell the user what to do
- **Non-technical** — no stack traces, file paths, or internal identifiers

| Scenario | Error Message |
|----------|---------------|
| Empty required field | "Employee Name is required" |
| Invalid email | "Please enter a valid email address" |
| File too large | "File exceeds the 10MB size limit" |
| Invalid URL | "Please enter a valid URL starting with https://" |
| Server error | "Something went wrong. Please try again." |

### API Error Response (Validation)

```json
{
  "success": false,
  "error": "Validation failed",
  "details": {
    "to": "Invalid recipient email address",
    "attachments[0].size": "File size exceeds 10MB limit",
    "managerDecision": "Expected 'approved' or 'rejected'"
  }
}
```

---

## Runtime Validation

During workflow execution, before calling each node's action:

### Email Node Pre-Flight

```javascript
// In handleTrigger(), before executing emailNode:
if (!node.data.to || !isValidEmail(node.data.to)) {
  setNodeError(nodeId, 'Invalid or missing recipient email');
  throw new Error('Email node validation failed');
}
```

### API Call Node Pre-Flight

```javascript
// Before fetching:
if (!node.data.apiUrl) {
  setNodeError(nodeId, 'API URL is not configured');
  throw new Error('API Call node validation failed');
}
try {
  new URL(node.data.apiUrl); // Throws if invalid
} catch {
  setNodeError(nodeId, 'API URL is not a valid URL');
  throw new Error('Invalid API URL');
}
```

---

## Approval Form Validation

Manager approval (Form 2 / ManagerNode) requires:

| Field | Rule |
|-------|------|
| Decision | Must be "approved" or "rejected" — no default/empty allowed |
| Comments | Required when decision is "rejected"; optional for approval |
| Comments | Max 2000 characters |

```javascript
function validateManagerDecision({ decision, comments }) {
  const errors = {};
  if (!decision) {
    errors.decision = 'Please select Approve or Reject';
  }
  if (decision === 'rejected' && !comments?.trim()) {
    errors.comments = 'Comments are required when rejecting a request';
  }
  if (comments && comments.length > 2000) {
    errors.comments = 'Comments cannot exceed 2000 characters';
  }
  return errors;
}
```

---

## URL Validation

For the API Call node's `apiUrl` field:

```javascript
function isValidApiUrl(url) {
  if (!url) return false;
  try {
    const parsed = new URL(url);
    // Production: require HTTPS
    if (parsed.protocol !== 'https:' && process.env.NODE_ENV === 'production') return false;
    // Block localhost and private IPs in production
    const privatePatterns = ['localhost', '127.', '0.0.0.0', '192.168.', '10.', '172.16.', '169.254.'];
    if (process.env.NODE_ENV === 'production' &&
        privatePatterns.some(p => parsed.hostname.startsWith(p))) return false;
    return true;
  } catch {
    return false;
  }
}
```

---

## Preventing Malicious Input

### Template Injection

The API Call node supports `{variableName}` interpolation in the URL and body. Ensure interpolation is purely string replacement — never `eval()` or `new Function()`:

```javascript
// Safe interpolation
function interpolateVariables(template, variables) {
  return template.replace(/\{(\w+)\}/g, (match, key) => {
    const value = variables[key];
    return value !== undefined ? String(value) : match;
  });
}

// NEVER:
// eval(`\`${template}\``)          — Code injection
// new Function('return ' + template)()  — Code injection
```

### Attachment Content-Type Spoofing

A file named `malware.pdf` with MIME type `application/pdf` in the data URL header could actually be an executable. Validate the declared MIME type against an allowlist and consider magic-byte verification for critical deployments.

### Webhook Payload Size

Enforce a tight size limit on the webhook endpoint to prevent memory exhaustion via large payloads:

```javascript
// Override global 25MB limit for the webhook endpoint
app.post('/api/webhook/form', express.json({ limit: '1mb' }), (req, res) => { ... });
```
