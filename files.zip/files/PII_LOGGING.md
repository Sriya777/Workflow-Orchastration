# PII & Logging Guidelines

> **Scope:** Antigravity Workflow Orchestration — Backend (`server.js`) and Frontend (`App.jsx`, node components)  
> **Applies to:** All developers, all environments (development, staging, production)

---

## Table of Contents

1. [What Qualifies as PII in This System](#what-qualifies-as-pii-in-this-system)
2. [What Must NEVER Be Logged](#what-must-never-be-logged)
3. [Sensitive Data Masking](#sensitive-data-masking)
4. [Secure Logging Practices](#secure-logging-practices)
5. [Authentication Data Restrictions](#authentication-data-restrictions)
6. [Password Handling](#password-handling)
7. [Token Handling](#token-handling)
8. [GDPR & Privacy Considerations](#gdpr--privacy-considerations)
9. [Audit Logging Strategy](#audit-logging-strategy)
10. [Safe Debugging Practices](#safe-debugging-practices)
11. [Secure Error Reporting](#secure-error-reporting)
12. [Examples: Safe vs Unsafe vs Masked Logs](#examples-safe-vs-unsafe-vs-masked-logs)

---

## What Qualifies as PII in This System

Personally Identifiable Information (PII) is any data that can identify a specific individual. In Antigravity Workflow, PII can appear in multiple places:

| Data Field | Source | PII Classification |
|---|---|---|
| Email address (`to`, `SMTP_USER`, `SMTP_FROM`) | Backend `.env`, email dispatch | **Direct PII** |
| `formData[].value` (user-submitted form responses) | Form 1 fill flow, webhook | **Direct or Indirect PII** |
| `requestId` (if contains user identifier) | Generated in `FormTaskNode` | **Indirect PII** (context-dependent) |
| `managerComments` | Manager review modal | **Potential PII** (may reference individuals) |
| `attachments[].name` | File upload in email flow | **Potential PII** (filename may contain name/ID) |
| `attachments[].data` (base64) | File upload | **High-risk PII** (document content) |
| Webhook payload (`POST /api/webhook/form`) | External form submission | **Uncontrolled PII** — treat as highest risk |
| Browser `localStorage` entries (`form_fill_*`, `node_data_*`) | Frontend form state | **Session PII** |

### PII Risk Levels

```
CRITICAL: SMTP credentials, authentication tokens, raw attachment data
HIGH:     Email addresses, form field values, manager comments
MEDIUM:   Request IDs, workflow execution timestamps
LOW:      Node labels, workflow titles, execution status codes
```

---

## What Must NEVER Be Logged

The following data categories must **never** appear in any log output — console, file, or remote aggregator — in any environment.

### Absolute Prohibitions

```
NEVER LOG:
  ✗ Passwords (SMTP_PASS or any future user password)
  ✗ JWT tokens (access tokens, refresh tokens)
  ✗ Session IDs
  ✗ OTPs / one-time codes
  ✗ Full email addresses in production logs
  ✗ formData field values (may contain name, DOB, salary, medical data, etc.)
  ✗ managerComments (may reference individuals or contain decisions)
  ✗ Attachment base64 data (att.data)
  ✗ Attachment binary content
  ✗ Raw webhook payloads from external sources
  ✗ SMTP_USER / SMTP_FROM environment variable values
  ✗ Google App Passwords or any OAuth tokens
  ✗ Financial data (salaries, account numbers) from form submissions
  ✗ Government IDs, national identity numbers
  ✗ Health or medical information from form fields
```

### Currently Risky Patterns in Codebase

The following existing log statements in `server.js` need remediation:

```javascript
// ⚠️ CURRENT CODE — RISKY:
console.log('📧 Received send-email payload:', { to, subject, requestId, managerDecision, managerComments });
// Problem: logs `managerComments` (may contain PII) and `to` (email address)

// ⚠️ CURRENT CODE — RISKY:
console.log('📥 Received external form submission:', payload);
// Problem: logs the ENTIRE webhook payload including all form field values
```

---

## Sensitive Data Masking

When a field is required in logs for debugging, use masking:

### Email Address Masking

```javascript
// Utility function
function maskEmail(email) {
  if (!email || !email.includes('@')) return '[invalid-email]';
  const [local, domain] = email.split('@');
  const maskedLocal = local.length > 2
    ? local[0] + '***' + local[local.length - 1]
    : '***';
  return `${maskedLocal}@${domain}`;
}

// Usage
maskEmail('sriyanistala@gmail.com');
// Output: 's***a@gmail.com'
```

### Form Data Masking

```javascript
// Log field names only, never values
function maskFormData(formData) {
  if (!Array.isArray(formData)) return [];
  return formData.map(field => ({
    label: field.label,
    hasValue: field.value !== null && field.value !== undefined && field.value !== '',
    type: typeof field.value
  }));
}

// Usage
console.log('Form fields received:', maskFormData(formData));
// Output: [{ label: 'Full Name', hasValue: true, type: 'string' }, ...]
```

### Attachment Masking

```javascript
// Log metadata only, never data content
function maskAttachments(attachments) {
  if (!Array.isArray(attachments)) return [];
  return attachments.map(att => ({
    name: att.name,           // filename is acceptable (low risk)
    size: att.size,           // size is acceptable
    hasData: Boolean(att.data) // boolean only, never the actual base64
  }));
}
```

### Webhook Payload Masking

```javascript
// Log structure only
function maskWebhookPayload(payload) {
  return {
    fieldCount: Object.keys(payload).length,
    fields: Object.keys(payload),  // field names only, not values
    receivedAt: new Date().toISOString()
  };
}
```

---

## Secure Logging Practices

### Backend Logging Standard

Replace raw `console.log` calls with structured, level-aware logging. Use a library like `pino` in production:

```javascript
import pino from 'pino';

const logger = pino({
  level: process.env.LOG_LEVEL || 'info',
  redact: ['body.formData[*].value', 'body.attachments[*].data', 'body.to', 'body.managerComments'],
  // pino-redact automatically replaces matched paths with '[Redacted]'
});
```

### Safe Log Structure for Email Dispatch

```javascript
// ✅ SAFE — acceptable log at INFO level
logger.info({
  event: 'email_dispatch_attempt',
  recipient: maskEmail(to),
  subject_length: (subject || '').length,
  request_id: requestId,
  form_field_count: (formData || []).length,
  attachment_count: (attachments || []).length,
  has_manager_decision: Boolean(managerDecision)
});
```

### Safe Log Structure for Webhook Receipt

```javascript
// ✅ SAFE
logger.info({
  event: 'webhook_received',
  field_count: Object.keys(payload).length,
  field_names: Object.keys(payload),
  received_at: new Date().toISOString()
});
```

### Log Levels

| Level | When to Use | Examples |
|---|---|---|
| `error` | Unrecoverable failures | SMTP auth failed, server crash |
| `warn` | Recoverable issues requiring attention | SMTP not configured, rate limit hit |
| `info` | Normal operational events | Email dispatched, webhook received |
| `debug` | Developer diagnostics (dev/staging only) | Node execution steps, resolver callbacks |
| `trace` | Verbose internals (never in production) | Raw request/response bodies |

---

## Authentication Data Restrictions

When authentication is implemented:

```javascript
// ❌ NEVER
console.log('Login attempt:', { username, password });
console.log('JWT issued:', token);
console.log('Session created:', { sessionId, userId });

// ✅ SAFE
logger.info({ event: 'login_attempt', username: maskEmail(username) });
logger.info({ event: 'jwt_issued', user_id: userId, expires_in: '900s' });
logger.info({ event: 'session_created', user_id: userId });
```

---

## Password Handling

Antigravity currently stores SMTP credentials in `backend/.env`. These rules apply:

```
RULE 1: SMTP_PASS must NEVER appear in any log, error message, or stack trace
RULE 2: SMTP_PASS must NEVER be returned in any API response
RULE 3: SMTP_PASS must NEVER be embedded in frontend source code
RULE 4: SMTP credentials must be rotated immediately if exposed in a commit
```

```javascript
// ❌ NEVER (even in error handling)
catch (err) {
  console.error('SMTP failed:', process.env.SMTP_USER, process.env.SMTP_PASS, err);
}

// ✅ SAFE
catch (err) {
  logger.error({
    event: 'smtp_failure',
    smtp_user_configured: Boolean(process.env.SMTP_USER),
    error_code: err.code,
    error_message: err.message  // Nodemailer errors do not include credentials in .message
  });
}
```

### If Credentials Are Exposed

1. Immediately revoke the Gmail App Password at `https://myaccount.google.com/apppasswords`
2. Generate a new App Password
3. Update `backend/.env` with the new credential
4. Purge git history if the credential was committed: `git filter-branch` or BFG Repo Cleaner
5. Rotate all other credentials that share the same password pattern

---

## Token Handling

When JWT authentication is implemented:

```javascript
// ❌ NEVER
localStorage.setItem('accessToken', token);   // Exposed to XSS
console.log('Token:', token);                  // Appears in browser console

// ✅ SAFE — access token in memory only
let accessToken = null; // Module-level variable, reset on page unload

// ✅ SAFE — refresh token in HttpOnly cookie
// Set by server:
res.cookie('refreshToken', token, {
  httpOnly: true,       // Not accessible via JavaScript
  secure: true,         // HTTPS only
  sameSite: 'Strict',   // CSRF protection
  maxAge: 7 * 24 * 60 * 60 * 1000  // 7 days
});
```

---

## GDPR & Privacy Considerations

Antigravity processes personal data submitted via forms and email. GDPR obligations apply if any EU users are involved.

### Data Minimization

- Collect only the form fields necessary for the workflow step
- Do not replicate `formData` across nodes — pass by reference via predecessor data (`predecessorData` in `FormTaskNode`)
- Clear `localStorage` form data immediately after consumption (current code already does this — do not regress)

### Data Retention

| Data Type | Current State | Recommended Retention |
|---|---|---|
| `formSubmissions[]` in-memory store | Grows indefinitely, lost on restart | Cap at last 100 entries, persist with 90-day TTL |
| `allExecutionRuns` in React state | Lost on page refresh | Persist to server with 30-day TTL |
| Email logs (Nodemailer) | Not stored by backend | Store message IDs only, not content, for 90 days |
| `localStorage` form data | Cleared after use (correct) | Verify this on every `FormTaskNode` code change |

### Right to Erasure

If a user requests deletion of their data:
1. Delete all `formSubmissions` entries where `data` contains their identifiable information
2. Delete workflow execution records containing their form responses
3. Purge any email logs referencing their `requestId`

### Data Transfer

Form data submitted in the EU must not be transmitted to servers outside the EU without adequacy decision or Standard Contractual Clauses. Verify Gmail SMTP server locations if EU data is in scope.

---

## Audit Logging Strategy

An audit log records **who did what, when**, without exposing sensitive content.

### Events to Audit Log

```javascript
// Audit log entry structure
{
  timestamp: ISO8601,
  event_type: string,       // e.g. 'email_dispatched', 'form_submitted', 'manager_decision'
  actor: string,            // user ID or masked identifier
  target_id: string,        // requestId, workflowId, nodeId
  outcome: 'success' | 'failure',
  metadata: {}              // Non-PII context only
}
```

### Events That Must Be Audit Logged

| Event | Fields to Log |
|---|---|
| Email dispatched | `timestamp`, `requestId`, `recipient_domain`, `outcome`, `messageId` |
| Form submitted (Form 1) | `timestamp`, `requestId`, `nodeId`, `field_count`, `outcome` |
| Manager decision recorded | `timestamp`, `requestId`, `nodeId`, `decision` (approved/rejected), `outcome` |
| Webhook form received | `timestamp`, `field_count`, `source_ip`, `outcome` |
| Workflow execution started | `timestamp`, `workflowId`, `workflowVersion`, `node_count` |
| Workflow execution completed | `timestamp`, `workflowId`, `duration_ms`, `outcome` |

---

## Safe Debugging Practices

### In Development

Use browser DevTools with these precautions:

- Do not screenshot or share DevTools console output if it shows form field values or email addresses
- Clear `localStorage` after debugging form fill flows: `localStorage.clear()`
- Use mock/test email addresses — never test with real user data

### Redacting Before Log Sharing

Before sharing logs in GitHub issues, Slack, or error tickets:

```bash
# Strip email addresses from log output before sharing
sed 's/[a-zA-Z0-9._%+-]\+@[a-zA-Z0-9.-]\+\.[a-zA-Z]\{2,\}/[EMAIL]/g' log.txt

# Strip anything that looks like a JWT (three base64 segments)
sed 's/eyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*/[JWT]/g' log.txt
```

### Safe Reproduction Steps

When filing a bug:
1. Describe the form fields **by type and label name** — not actual submitted values
2. Use `requestId` to identify the workflow run — not user names or emails
3. Share sanitized logs only (run through redaction script above)

---

## Secure Error Reporting

### API Error Responses — Information Leakage Prevention

```javascript
// ❌ UNSAFE — exposes internal details
res.status(500).json({
  error: err.message,         // May include SMTP auth details, file paths
  stack: err.stack,           // Full stack trace exposed externally
  smtp_user: process.env.SMTP_USER  // Credential leaked!
});

// ✅ SAFE — generic external message, full detail logged internally
logger.error({ event: 'email_failure', error_code: err.code, error_message: err.message });
res.status(500).json({
  success: false,
  error: 'Failed to send email. Please try again or contact support.',
  error_code: 'EMAIL_DISPATCH_FAILED'  // Stable code clients can handle
});
```

### Sentry / Error Tracking Integration

If using Sentry or similar:

```javascript
import * as Sentry from '@sentry/node';

Sentry.init({
  dsn: process.env.SENTRY_DSN,
  beforeSend(event) {
    // Strip PII from Sentry events before transmission
    if (event.request?.data) {
      const data = event.request.data;
      if (data.formData) data.formData = maskFormData(data.formData);
      if (data.to) data.to = maskEmail(data.to);
      if (data.attachments) data.attachments = maskAttachments(data.attachments);
      delete data.managerComments;
    }
    return event;
  }
});
```

---

## Examples: Safe vs Unsafe vs Masked Logs

### Email Dispatch Logging

```javascript
// ❌ UNSAFE LOG
console.log('Sending email:', { to: 'john.doe@company.com', subject: 'Salary Approval REQ-ABC123', formData: [{ label: 'Salary', value: '₹85,000' }] });

// ⚠️ PARTIALLY MASKED
console.log('Sending email:', { to: 'j***e@company.com', subject: '[subject omitted]', form_fields: 1 });

// ✅ SAFE LOG
logger.info({ event: 'email_dispatch', recipient: 'j***e@company.com', request_id: 'REQ-ABC123', form_field_count: 1, attachment_count: 0 });
```

### Webhook Receipt Logging

```javascript
// ❌ UNSAFE LOG
console.log('Received:', { name: 'John Doe', email: 'john@company.com', department: 'Finance', salary_band: 'L5' });

// ✅ SAFE LOG
logger.info({ event: 'webhook_received', field_count: 4, field_names: ['name', 'email', 'department', 'salary_band'], received_at: '2026-05-27T19:24:00.000Z' });
```

### SMTP Failure Logging

```javascript
// ❌ UNSAFE LOG
console.error('SMTP error:', err, { user: 'sriyanistala@gmail.com', pass: 'hfsn dlyp gqhk hzen' });

// ✅ SAFE LOG
logger.error({ event: 'smtp_failure', error_code: 'EAUTH', error_type: 'Authentication', smtp_configured: true });
```

### Manager Decision Logging

```javascript
// ❌ UNSAFE LOG
console.log('Manager decided:', { decision: 'approved', comments: 'John\'s salary hike looks justified based on his Q4 performance.' });

// ✅ SAFE LOG
logger.info({ event: 'manager_decision', node_id: 'node-abc', decision: 'approved', has_comments: true, request_id: 'REQ-ABC123' });
```

### localStorage Usage

```javascript
// ❌ UNSAFE — persists PII in browser storage beyond session
localStorage.setItem('last_form_user', JSON.stringify({ name: 'John Doe', email: 'john@company.com' }));

// ✅ SAFE — scoped to node/request, cleared after use
localStorage.setItem(`form_fill_${nodeId}`, JSON.stringify({ requestId, formData }));
// ... after consumption:
localStorage.removeItem(`form_fill_${nodeId}`); // ← current code correctly does this
```
