# Antigravity Workflow Orchestration — Project Documentation

> **Platform:** Antigravity Workflow  
> **Stack:** React 19 + Vite (Frontend) · Node.js + Express (Backend)  
> **Frontend Library:** `@xyflow/react` v12 (React Flow)  
> **Version:** 0.0.0 (Development)

---

## Table of Contents

1. [Project Overview](#project-overview)
2. [System Architecture](#system-architecture)
3. [Folder Structure](#folder-structure)
4. [How Frontend and Backend Communicate](#how-frontend-and-backend-communicate)
5. [API Flow](#api-flow)
6. [Execution Flow](#execution-flow)
7. [Authentication Flow](#authentication-flow)
8. [Environment Setup](#environment-setup)
9. [Installation](#installation)
10. [Deployment Overview](#deployment-overview)
11. [Security Overview](#security-overview)
12. [Workflow Execution Lifecycle](#workflow-execution-lifecycle)
13. [Data Flow Between Services](#data-flow-between-services)
14. [Runtime Execution Explanation](#runtime-execution-explanation)

---

## Project Overview

Antigravity Workflow Orchestration is a **visual, browser-native workflow builder and executor** that enables teams to design, configure, and run multi-step approval processes without writing code.

### Core Capabilities

| Capability | Description |
|---|---|
| **Visual Workflow Builder** | Drag-and-drop canvas powered by React Flow (`@xyflow/react`) |
| **Node-Based Execution** | Each workflow step is a typed node (Form, Email, Manager Review, API Call, etc.) |
| **Dual-Mode Forms** | Form 1 (data entry) and Form 2 (manager review/approval) with popup windows |
| **Email Orchestration** | Nodemailer-backed Gmail SMTP dispatch with structured HTML payloads |
| **Webhook Integration** | Accepts external form submissions (e.g. Google Forms), stores and serves them |
| **Execution History** | Per-workflow run tracking with status, timestamps, and TAT |
| **Two App Modes** | `editor` (workflow design) and `execution` (live runtime orchestration) |

---

## System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     BROWSER (Frontend)                       │
│                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐  │
│  │  React Flow   │  │  Node Panel  │  │ Properties Panel │  │
│  │   Canvas      │  │  (Sidebar)   │  │   (Config)       │  │
│  └──────┬───────┘  └──────────────┘  └──────────────────┘  │
│         │                                                     │
│  ┌──────▼───────────────────────────────────────────────┐   │
│  │                    App.jsx (Orchestrator)              │   │
│  │  State: nodes[], edges[], appMode, executionRuns      │   │
│  │  Refs:  formResolvers, managerResolvers, emailResolvers│  │
│  └──────────────────────┬────────────────────────────────┘   │
│                         │  fetch() / POST                     │
└─────────────────────────┼───────────────────────────────────┘
                          │ HTTP REST (localhost:3001)
┌─────────────────────────▼───────────────────────────────────┐
│                     BACKEND (Node.js / Express)              │
│                                                              │
│  ┌────────────────┐  ┌──────────────────┐  ┌─────────────┐ │
│  │ /api/send-email│  │/api/webhook/form  │  │ /api/health │ │
│  └────────┬───────┘  └────────┬─────────┘  └─────────────┘ │
│           │                   │                               │
│  ┌────────▼───────────────────▼──────────────────────────┐  │
│  │  Nodemailer (Gmail SMTP) · In-Memory Submission Store  │  │
│  └────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

**Architecture pattern:** Single-page React application with a thin Express backend handling SMTP relay and external webhook ingestion. All workflow state lives in React component state — there is no persistent database in the current build.

---

## Folder Structure

```
antigravity-workflow/
├── backend/                        # Express email/webhook server
│   ├── .env                        # SMTP credentials (NEVER commit)
│   ├── package.json                # express, cors, nodemailer, dotenv
│   └── server.js                   # Single-file Express API (all routes)
│
├── public/                         # Static assets (served by Vite)
│   ├── favicon.svg
│   └── icons.svg
│
├── src/                            # React application source
│   ├── App.jsx                     # Root component + global orchestrator
│   ├── App.css                     # Global styles (canvas, panels, nodes)
│   ├── main.jsx                    # React DOM entry point
│   ├── index.css                   # Base CSS reset
│   │
│   ├── components/                 # Shared UI components
│   │   ├── NodePanel.jsx           # Left sidebar – draggable node palette
│   │   └── PropertiesPanel.jsx     # Right sidebar – node configuration forms
│   │
│   ├── nodes/                      # Node type implementations
│   │   ├── index.js                # nodeTypes registry (React Flow)
│   │   ├── AntigravityNode.jsx     # Branded start/trigger node
│   │   ├── ApiCallNode.jsx         # HTTP API call node
│   │   ├── EmailNode.jsx           # Email dispatch node
│   │   ├── FormNode.jsx            # Legacy standalone form node
│   │   ├── FormTaskNode.jsx        # Unified Form 1 + Form 2 task node
│   │   ├── GenericNode.jsx         # Base node scaffold
│   │   ├── ManagerNode.jsx         # Manager approval decision node
│   │   ├── ModeControllerNode.jsx  # Execution mode switch node
│   │   ├── SwimlaneNode.jsx        # Lane separator / grouping node
│   │   └── TaskNode.jsx            # Generic task/milestone node
│   │
│   └── assets/                     # Images, SVGs
│
├── dist/                           # Vite production build output
├── index.html                      # SPA shell
├── vite.config.js                  # Vite build config
├── package.json                    # React, @xyflow/react, uuid
└── eslint.config.js
```

---

## How Frontend and Backend Communicate

The frontend and backend communicate exclusively over **HTTP REST**. There is no WebSocket, GraphQL, or real-time push layer.

| Direction | Trigger | Endpoint | Protocol |
|---|---|---|---|
| Frontend → Backend | EmailNode triggers send | `POST /api/send-email` | JSON/HTTP |
| Frontend → Backend | App init health check | `GET /api/health` | HTTP |
| External → Backend | Google Forms or third-party webhook | `POST /api/webhook/form` | JSON/HTTP |
| Frontend → Backend | ApiCallNode polls for latest submission | `GET /api/webhook/form/latest` | HTTP |

The frontend uses the native browser `fetch()` API — no Axios or HTTP client library.

```javascript
// Example: EmailNode dispatches to backend
const response = await fetch('http://localhost:3001/api/send-email', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    to, subject, body, formData,
    attachments, requestId,
    managerDecision, managerComments
  })
});
const result = await response.json();
// { success: true, messageId: "...", message: "..." }
```

---

## API Flow

```
EmailNode triggers send
        │
        ▼
App.jsx calls POST /api/send-email with full payload
        │
        ▼
Backend validates recipient email (regex: /^[^\s@]+@[^\s@]+\.[^\s@]+$/)
        │
        ├── Invalid → 400 { success: false, error: "Invalid or missing email address" }
        │
        ▼
Backend builds HTML email body:
  - requestId banner
  - formData as formatted table
  - managerDecision badge (approved/rejected)
  - attachments list
        │
        ▼
Nodemailer encodes base64 attachments and sends via Gmail SMTP
        │
        ├── SMTP failure → 500 { success: false, error: "SMTP error message" }
        │
        ▼
200 { success: true, messageId: "...", message: "Email dispatched" }
        │
        ▼
EmailNode sets execStatus = 'completed', resolves emailResolvers[nodeId]
```

---

## Execution Flow

Execution is **sequential, promise-based, and fully client-side**. The backend is only called for email dispatch and webhook data retrieval.

```
User clicks "Execute Workflow"
        │
        ▼
appMode switches 'editor' → 'execution'
isExecuting = true, stopExecutionRef.current = false
        │
        ▼
handleTrigger() walks nodes in topological order (edges define sequence)
        │
        ▼
For each node type:
  ├── task / generic     → execStatus = 'completed' immediately
  ├── apiCall            → fetch(node.data.url), awaits response, extracts data
  ├── formNode / formTask (form1)
  │     → window.open('#/fill-form/:nodeId/:reqId', popup window)
  │     → awaits formResolvers[nodeId] Promise
  │     → resolved by postMessage('FORM_SUBMITTED') from popup
  ├── emailNode          → POST /api/send-email
  │     → awaits emailResolvers[nodeId] Promise
  │     → resolved by 'email-confirm' CustomEvent
  ├── managerNode        → renders inline approval UI
  │     → awaits managerResolvers[nodeId] Promise
  │     → resolved by 'manager-submit' CustomEvent
  └── formTask (form2)   → showReviewModal = true in node component
        → awaits managerResolvers[nodeId] Promise
        │
        ▼
On node complete: execTat recorded, execStatus = 'completed'
        │
        ▼
After all nodes: run appended to allExecutionRuns[workflowId]
isExecuting = false
```

### Promise Resolution Pattern

Blocking nodes use a resolver ref map to suspend execution until user action:

```javascript
// Suspension
await new Promise((resolve) => {
  formResolvers.current[nodeId] = resolve;
  // Execution pauses here until the resolver is called
});

// Resolution (when popup posts FORM_SUBMITTED message)
window.addEventListener('message', (event) => {
  if (event.data.type === 'FORM_SUBMITTED') {
    const { nodeId } = event.data;
    formResolvers.current[nodeId]?.(); // Unblocks execution
    delete formResolvers.current[nodeId];
  }
});
```

---

## Authentication Flow

> ⚠️ **Current state:** No authentication is implemented. All backend endpoints are public, and the frontend has no login/session management.

**Recommended implementation:**

```
User submits credentials
        │
        ▼
POST /api/auth/login → validate against user store
        │
        ▼
Issue JWT: short-lived access token (15m) + long-lived refresh token (7d)
        │
        ▼
Access token: stored in JavaScript memory (NOT localStorage)
Refresh token: set as HttpOnly; Secure; SameSite=Strict cookie
        │
        ▼
All API requests: Authorization: Bearer <accessToken>
        │
        ▼
Backend middleware: verifyJWT() on every protected route
        │
        ▼
Token expiry: silent refresh via POST /api/auth/refresh using cookie
```

See [`AUTHENTICATION.md`](./AUTHENTICATION.md) for the complete implementation guide.

---

## Environment Setup

### Prerequisites

| Tool | Version | Notes |
|---|---|---|
| Node.js | ≥ 18.x | Required for both frontend (Vite) and backend |
| npm | ≥ 9.x | Bundled with Node.js |
| Gmail Account | — | 2-Step Verification must be enabled |
| Gmail App Password | 16 characters | Generated at `myaccount.google.com/apppasswords` |

### Backend `.env` Configuration

```env
# backend/.env
SMTP_USER=your-email@gmail.com
SMTP_PASS=xxxx xxxx xxxx xxxx   # 16-character Gmail App Password (spaces are OK)
SMTP_FROM=your-email@gmail.com
PORT=3001
```

> The `.gitignore` already excludes `backend/.env`. Verify before every push.

---

## Installation

```bash
# 1. Clone the repository
git clone <repo-url>
cd antigravity-workflow

# 2. Install frontend dependencies
npm install

# 3. Install backend dependencies
cd backend && npm install && cd ..

# 4. Configure environment
# Create backend/.env with your SMTP credentials (see above)

# 5. Start backend (terminal 1)
cd backend && node server.js
# Expected: "✅ SMTP connection verified – ready to send emails"
# Expected: "🚀 Email backend running on http://localhost:3001"

# 6. Start frontend dev server (terminal 2)
npm run dev
# Frontend: http://localhost:5173
```

---

## Deployment Overview

### Frontend (Static)

```bash
npm run build
# Produces: dist/index.html + dist/assets/index-[hash].js + index-[hash].css
```

Deploy `dist/` to: Netlify, Vercel, AWS S3 + CloudFront, or Nginx static hosting.

Update the hardcoded backend URL in the source before building for production:
```javascript
// Replace all occurrences of:
'http://localhost:3001'
// With your production backend URL:
process.env.VITE_API_BASE_URL || 'https://api.your-domain.com'
```

### Backend (Node.js Process)

```bash
# Install PM2 globally
npm install -g pm2

# Start with PM2
pm2 start backend/server.js --name antigravity-api --env production

# Auto-restart on server reboot
pm2 startup && pm2 save
```

Expose via Nginx reverse proxy on port 443 (HTTPS). Never expose port 3001 directly to the internet.

---

## Security Overview

| Area | Current State | Priority Fix |
|---|---|---|
| SMTP credentials | In `.env` — correct | Use secrets manager in production |
| Backend auth | ❌ None | Implement JWT middleware |
| CORS | `cors()` — open to all origins | Restrict to known frontend origin |
| Rate limiting | ❌ None | Add `express-rate-limit` |
| XSS in email HTML | `formData.value` injected raw | Sanitize before HTML concatenation |
| HTTPS | Not enforced | Enforce at reverse proxy level |
| Input validation | Email regex only | Add Zod/Joi schema validation |

See [`SECURITY.md`](./SECURITY.md) for the full security hardening guide.

---

## Workflow Execution Lifecycle

```
DRAFT ──► EXECUTING ──► WAITING_FOR_INPUT ──► COMPLETED
                    │                     └──► FAILED
                    └──────────────────────►   STOPPED
```

| State | `execStatus` Value | Visual |
|---|---|---|
| Not started | `undefined` | Grey |
| Active step | `'running'` | Pulsing blue |
| User input needed | `'running'` + resolver pending | Blue + interactive UI |
| Completed | `'completed'` | Green check |
| Failed | `'failed'` | Red X |
| Stopped by user | Loop exits via `stopExecutionRef` | Partial green/grey |

---

## Data Flow Between Services

```
External Form (Google Forms webhook)
        │  POST /api/webhook/form { ...formFields }
        ▼
Backend: stores in formSubmissions[] (in-memory)
        │
        ▼
ApiCallNode: GET /api/webhook/form/latest
        │  response.submission.data extracted
        ▼
FormTaskNode (Form 2): reads predecessor node's filledData
        │  via useReactFlow().getNodes() + getEdges()
        ▼
Manager Review Modal: shows formData to reviewer
        │
        ▼
'manager-submit' CustomEvent: { nodeId, decision, comments }
        │
        ▼
App.jsx resolves managerResolvers[nodeId]
        │  updates node.data.managerDecision
        ▼
EmailNode: POST /api/send-email {
  to, subject, formData, managerDecision, managerComments, requestId
}
        │
        ▼
Recipient receives structured HTML email with:
  - Request reference banner
  - Form data table
  - Manager decision badge
  - File attachments
```

---

## Runtime Execution Explanation

Runtime mode (`appMode === 'execution'`) transforms the canvas from a design tool into an interactive execution interface:

### What Changes in Execution Mode

- **Canvas becomes read-only** — dragging, adding, and deleting nodes is disabled
- **Nodes become interactive** — Form nodes show "Open Form" buttons, Email nodes show confirmation UI, Manager nodes show decision modals
- **Execution engine runs** — `handleTrigger()` steps through nodes sequentially

### Stale Closure Prevention

The execution engine uses `latestNodesRef` — a `useRef` kept in sync with `nodes` state — to avoid reading stale node data inside async callbacks:

```javascript
// Keep ref in sync
useEffect(() => {
  latestNodesRef.current = nodes;
}, [nodes]);

// Read from ref (not closure-captured nodes) inside async execution
const currentNode = latestNodesRef.current.find(n => n.id === nodeId);
```

### TAT (Turnaround Time) Tracking

Each node records start and end timestamps in `node.data.execTat`:

```javascript
// On node start
const startTime = Date.now();

// On node complete
const execTat = Date.now() - startTime; // milliseconds
setNodes(nds => nds.map(n =>
  n.id === nodeId ? { ...n, data: { ...n.data, execStatus: 'completed', execTat } } : n
));
```

TATs are aggregated per execution run in `allExecutionRuns[workflowId]` and displayed in the execution history panel.

---

## Documentation Index

| File | Contents |
|---|---|
| `README.md` | This file — project overview and architecture |
| [`FRONTEND.md`](./FRONTEND.md) | Frontend architecture, components, state, node rendering |
| [`BACKEND.md`](./BACKEND.md) | Backend architecture, routes, SMTP, webhook handling |
| [`API.md`](./API.md) | REST API reference with request/response examples |
| [`AUTHENTICATION.md`](./AUTHENTICATION.md) | JWT auth implementation guide |
| [`SECURITY.md`](./SECURITY.md) | OWASP-aligned security hardening guide |
| [`VALIDATION.md`](./VALIDATION.md) | Frontend and backend validation rules |
| [`ERROR_HANDLING.md`](./ERROR_HANDLING.md) | Error taxonomy, handling patterns, logging |
| [`CHECKLIST.md`](./CHECKLIST.md) | Development and deployment checklists |
| [`PII_LOGGING.md`](./PII_LOGGING.md) | PII classification, safe logging, GDPR considerations |
