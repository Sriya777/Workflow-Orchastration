# Frontend Documentation

> React 19 + Vite + @xyflow/react — Workflow Canvas, Node System, and Execution UI

---

## Table of Contents

- [Frontend Architecture](#frontend-architecture)
- [Technology Stack](#technology-stack)
- [Folder Organisation](#folder-organisation)
- [Component Structure](#component-structure)
- [State Management](#state-management)
- [Workflow Canvas Logic](#workflow-canvas-logic)
- [Node Rendering System](#node-rendering-system)
- [Execution Mode UI](#execution-mode-ui)
- [Form Popup Handling](#form-popup-handling)
- [API Integration Layer](#api-integration-layer)
- [Error Handling](#error-handling)
- [Validation Handling](#validation-handling)
- [Routing Structure](#routing-structure)
- [Security Considerations](#security-considerations)
- [Sensitive Data Handling](#sensitive-data-handling)
- [Performance Optimisation](#performance-optimisation)
- [Best Practices](#best-practices)

---

## Frontend Architecture

The frontend is a **single-page React application** with two distinct operational modes managed by a single root component (`App.jsx`). The execution engine is implemented entirely client-side using async/await with Promise-based coordination for interactive nodes.

```
App.jsx (Root)
├── Mode: 'editor'
│   ├── NodePanel (left sidebar — draggable node palette)
│   ├── ReactFlow Canvas (main area — node graph)
│   └── PropertiesPanel (right sidebar — node config)
│
└── Mode: 'execution'
    ├── ExecutionPanel (left sidebar — run history)
    ├── ReactFlow Canvas (read-only — live node status)
    └── FormTaskNode / ManagerNode popups (interactive overlays)
```

The canvas is powered by `@xyflow/react` (XYFlow v12), which handles:
- Node drag-and-drop positioning
- Edge rendering and connection logic
- Zoom, pan, minimap, and controls
- Custom node type rendering

---

## Technology Stack

| Technology | Version | Role |
|-----------|---------|------|
| React | 19.2.4 | UI component framework |
| Vite | 8.x | Build tool and dev server |
| @xyflow/react | 12.10.2 | Flow canvas (nodes + edges) |
| uuid | 13.x | Unique node/workflow ID generation |
| Vanilla CSS | — | Custom styling (App.css, ~65KB) |
| fetch (native) | — | HTTP calls to backend |

> **No global state library (Redux/Zustand) is used.** All state lives in `App.jsx` via `useState` and `useRef`, passed to child components via props or accessed through custom events.

---

## Folder Organisation

```
src/
├── App.jsx                  # Root: mode control, execution engine, canvas
├── App.css                  # All custom styles (~65KB, single file)
├── main.jsx                 # React entry: ReactDOM.createRoot
├── index.css                # CSS reset / base variables
│
├── components/
│   ├── NodePanel.jsx        # Left sidebar: draggable node templates
│   └── PropertiesPanel.jsx  # Right sidebar: node property editor
│
├── nodes/
│   ├── index.js             # Node type registry
│   ├── AntigravityNode.jsx  # Start/trigger node
│   ├── GenericNode.jsx      # Passthrough node
│   ├── ModeControllerNode.jsx
│   ├── TaskNode.jsx
│   ├── SwimlaneNode.jsx
│   ├── ApiCallNode.jsx      # HTTP API call node
│   ├── FormNode.jsx         # Legacy form popup node
│   ├── EmailNode.jsx        # Email dispatch node
│   ├── ManagerNode.jsx      # Manager approval node
│   └── FormTaskNode.jsx     # Unified form task (Form1 + Form2)
│
└── assets/
    ├── hero.png
    ├── react.svg
    └── vite.svg
```

---

## Component Structure

### App.jsx — Root Orchestrator

Responsibilities:
- Owns all global state: `nodes`, `edges`, `selectedNode`, `appMode`, `isExecuting`, `allExecutionRuns`
- Registers ReactFlow event handlers: `onNodesChange`, `onEdgesChange`, `onConnect`, `onNodeClick`, `onDrop`
- Implements `handleTrigger()` — the full async execution engine
- Manages mode switching (editor ↔ execution) including state resets
- Registers window-level event listeners for cross-component communication

### NodePanel.jsx — Node Palette

- Renders a categorised list of draggable node templates
- Each template has a `type` string matching the `nodeTypes` registry
- Drag events set `dataTransfer` with the node type; `App.jsx` handles `onDrop` to create the node
- In execution mode, this panel is replaced by the ExecutionPanel

### PropertiesPanel.jsx — Node Configuration

- Receives `selectedNode` and `onUpdate` callback as props
- Renders type-specific configuration fields:
  - `apiCall`: URL, method, headers, body
  - `emailNode`: to, subject, body
  - `formNode`/`formTask`: form field definitions, data source
  - `managerNode`: approver email
- Changes trigger `onUpdate(nodeId, newData)` which calls `setNodes()`

### Node Components — Canvas Nodes

Each node component receives ReactFlow's standard props: `id`, `data`, `selected`, `type`.

All nodes use `Handle` components (from `@xyflow/react`) for connection points. The `execStatus` field in `data` drives visual state: `idle`, `running`, `completed`, `error`.

---

## State Management

All state is managed locally in `App.jsx` with React hooks. There is no external state library.

### Primary State Variables

```javascript
// Graph state
const [nodes, setNodes] = useState([]);
const [edges, setEdges] = useState([]);
const [selectedNode, setSelectedNode] = useState(null);

// App mode
const [appMode, setAppMode] = useState('editor'); // 'editor' | 'execution'

// Execution state
const [isExecuting, setIsExecuting] = useState(false);
const [allExecutionRuns, setAllExecutionRuns] = useState({}); // keyed by workflowId
const [selectedRunIndex, setSelectedRunIndex] = useState(null);

// Workflow metadata
const [workflowTitle, setWorkflowTitle] = useState('Antigravity Workflow');
const [workflowVersion, setWorkflowVersion] = useState(0.0);
const [currentWorkflowId, setCurrentWorkflowId] = useState(() => uuidv4());
```

### Ref-Based State (Execution Closures)

```javascript
const latestNodesRef = useRef(nodes);   // Synced via useEffect to avoid stale closures
const managerResolvers = useRef({});    // { nodeId: resolveFn } — manager approval waits
const formResolvers = useRef({});       // { nodeId: resolveFn } — form submission waits
const emailResolvers = useRef({});      // { nodeId: resolveFn } — email confirm waits
const stopExecutionRef = useRef(false); // Interrupt signal for the execution loop
```

Refs are used for state that must be accessible inside long-running async closures (`handleTrigger`) without stale captures.

### Cross-Component Communication

Rather than prop drilling or a context, the application uses **custom DOM events** and `window.postMessage` for communication between isolated node components and the execution engine:

| Event | Direction | Purpose |
|-------|-----------|---------|
| `manager-submit` (CustomEvent) | ManagerNode → App | Manager approved/rejected |
| `custom-form-complete` (CustomEvent) | FormTaskNode → App | Form 2 submitted |
| `email-confirm` (CustomEvent) | EmailNode → App | Email confirmed |
| `FORM_SUBMITTED` (postMessage) | Form popup → App | Form 1 data from iframe/tab |
| `hashchange` | Browser → App | Hash-based routing for manager view |
| `focus` | Window → App | Poll localStorage on tab refocus for form fill |

---

## Workflow Canvas Logic

The canvas renders an interactive directed graph where:

- **Nodes** represent workflow steps (typed components)
- **Edges** represent execution dependencies (directed arrows)
- **Handles** are connection anchors on node borders

### Editor Mode Interactions

- **Drag from NodePanel** → `onDrop` creates a new node at the drop position with a UUID
- **Connect two nodes** → `onConnect` adds a new edge via `addEdge()`
- **Click a node** → `onNodeClick` sets `selectedNode`, opening PropertiesPanel
- **Drag a node** → `onNodeDragStop` updates node position
- **Delete** → ReactFlow's built-in delete key support

### Canvas Configuration

```javascript
<ReactFlow
  nodes={nodes}
  edges={edges}
  nodeTypes={nodeTypes}         // Custom node component registry
  onNodesChange={onNodesChange} // Disabled in execution mode
  onEdgesChange={onEdgesChange} // Disabled in execution mode
  onConnect={onConnect}         // Disabled in execution mode
  nodesDraggable={appMode === 'editor'}
  nodesConnectable={appMode === 'editor'}
>
  <Background variant="dots" />
  <Controls />
  <MiniMap />
</ReactFlow>
```

---

## Node Rendering System

### Node Type Registry

```javascript
// src/nodes/index.js
export const nodeTypes = {
  generic: GenericNode,
  antigravity: AntigravityNode,
  modeController: ModeControllerNode,
  task: TaskNode,
  swimlane: SwimlaneNode,
  apiCall: ApiCallNode,
  formNode: FormNode,
  emailNode: EmailNode,
  managerNode: ManagerNode,
  formTask: FormTaskNode,
};
```

All custom types must be registered here and passed to `<ReactFlow nodeTypes={nodeTypes}>`. Defining `nodeTypes` outside the component prevents ReactFlow from re-registering on every render.

### Execution Status Styling

Each node reads `data.execStatus` to apply CSS classes for visual feedback:

| `execStatus` | Visual Indicator |
|-------------|-----------------|
| `idle` | Default node border |
| `running` | Animated pulsing border (blue/teal) |
| `completed` | Green border + checkmark |
| `error` | Red border + error icon |
| `waiting` | Yellow/amber border (form/manager pending) |

### FormTaskNode — Unified Form Node

`FormTaskNode.jsx` is the most complex node. It handles two task modes:

- **`form1`** — User-facing data collection form (popup or external page)
- **`form2`** — Manager approval form (hash-routed view, separate browser tab/window)

It also supports `formSource`:
- **`custom`** — Renders an embedded form builder UI directly in the node
- **`external`** — Opens a new tab to a configured form URL

---

## Execution Mode UI

When `appMode === 'execution'`:

1. **NodePanel is hidden** — replaced by an ExecutionPanel showing run history
2. **Canvas becomes read-only** — no drag, connect, or delete interactions
3. **Clicking a Start node** (AntigravityNode) calls `handleTrigger(nodeId)`
4. **Node visual states update reactively** as execution progresses
5. **Interactive nodes render overlays** (forms, approval dialogs) directly on canvas

### Execution Panel (Left Sidebar in Execution Mode)

Shows:
- Total execution count for current workflow
- List of past runs with: run number, start time, TAT, status (completed/error)
- Expandable run details: node-level TAT, form data collected, manager decisions

---

## Form Popup Handling

### Form 1 (User Form — Popup)

When a FormNode or FormTaskNode with `taskMode === 'form1'` is reached:

1. Execution engine awaits a Promise stored in `formResolvers.current[nodeId]`
2. The node renders a popup overlay with configurable input fields
3. On submit, the node dispatches `window.postMessage({ type: 'FORM_SUBMITTED', nodeId, requestId, formData })`
4. App.jsx listener receives the message, updates node state (`filledData`, `formStatus: 'filled'`)
5. `formResolvers.current[nodeId]()` is called — execution unblocks

**Fallback via localStorage + window focus:**  
For external form pages opened in a new tab, the form page writes data to `localStorage` under key `form_fill_${nodeId}`. When the user returns focus to the main window, a `focus` event listener reads and clears this key.

### Form 2 (Manager Approval — Hash Route)

Manager approval uses URL hash routing (`#manager-${nodeId}`):

1. Execution reaches a ManagerNode or FormTaskNode with `taskMode === 'form2'`
2. App generates a shareable link with the node's hash
3. Manager opens the link (same tab or new tab)
4. On hash match, the Manager view renders with Approve/Reject controls
5. On submit, `CustomEvent('manager-submit', { detail: { nodeId, decision, comments } })` fires
6. App.jsx resolves the corresponding `managerResolvers.current[nodeId]` promise

---

## API Integration Layer

All backend communication uses native `fetch()`. There is no Axios or HTTP client library.

### Email Dispatch

```javascript
const response = await fetch('http://localhost:3001/api/send-email', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    to,
    subject,
    body,
    formData,        // Array of { label, value } pairs
    attachments,     // Array of { name, size, data: base64DataURL }
    requestId,
    managerDecision,
    managerComments,
  }),
});
const result = await response.json();
```

### API Call Node

```javascript
const response = await fetch(resolvedUrl, {
  method: node.data.method || 'GET',
  headers: parsedHeaders,
  body: node.data.method !== 'GET' ? node.data.body : undefined,
});
const result = await response.json();
```

The URL and body support `{variableName}` interpolation — variables are resolved from `formData` collected in preceding form nodes before the fetch is executed.

---

## Error Handling

### Execution-Level Errors

- Each node is wrapped in a try/catch in the execution engine
- On catch: node `execStatus` set to `'error'`, `execError` set to the message
- `globalExecutionError` state is set, displayed in the UI
- Execution halts for the current layer; remaining layers are skipped

### Network Errors

- `fetch()` rejections (network failure) are caught and surfaced as node errors
- Non-2xx HTTP responses from the backend are treated as errors
- A toast notification flashes the error message to the user

### UI Error Feedback

- **Toast notifications:** Transient messages (3 second auto-dismiss) for success/error
- **Node visual state:** `execStatus: 'error'` renders red border and error icon
- **Execution panel:** Failed runs show "error" badge with the error message
- **Global error banner:** `globalExecutionError` shown above the canvas

---

## Validation Handling

### Node Configuration Validation (Editor Mode)

PropertiesPanel validates fields before saving:

- **Email node:** Recipient address validated against `/^[^\s@]+@[^\s@]+\.[^\s@]+$/`
- **API call node:** URL validated for non-empty value; headers validated as parseable JSON
- **Form node:** At least one field must be defined before the node can be used in execution

### Execution-Time Validation

Before executing an email node, the execution engine re-validates the recipient:

```javascript
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
if (!to || !emailRegex.test(to)) {
  // Mark node as error, halt execution layer
}
```

Backend also independently validates the recipient before calling Nodemailer.

---

## Routing Structure

The application uses **hash-based routing** (no React Router):

| Hash | View |
|------|------|
| `` (empty) | Main workflow canvas |
| `#manager-{nodeId}` | Manager approval view for the specified node |

```javascript
const [currentHash, setCurrentHash] = useState(window.location.hash);

useEffect(() => {
  window.addEventListener('hashchange', () => setCurrentHash(window.location.hash));
}, []);

// Render decision based on hash
if (currentHash.startsWith('#manager-')) {
  return <ManagerView nodeId={extractedNodeId} />;
}
return <MainCanvas />;
```

---

## Security Considerations

### SMTP Credentials

SMTP credentials exist only in `backend/.env`. The frontend **never** receives or stores them. The frontend only sends email payload data; the backend handles SMTP authentication.

### Form Data Handling

- Form data (user inputs) exists only in React state during execution
- It is passed to the backend as the `formData` array in the email payload
- It is not persisted to any database or localStorage beyond the form fill handshake

### File Attachments

- Attachments are read via `FileReader` and stored as base64 data URLs in component state
- They are transmitted to the backend in the email payload
- They are never written to disk on the client side

### XSS Prevention

- React's JSX escapes all dynamic content by default
- Email HTML bodies constructed server-side using string templates (not `dangerouslySetInnerHTML` client-side)
- User inputs rendered in node overlays via React — not injected as raw HTML

### Sensitive Data in State

- No passwords or tokens are stored in React state
- `execStatus`, `filledData`, and `managerDecision` are transient execution-time values

---

## Sensitive Data Handling

| Data Type | Where It Lives | Cleared When |
|-----------|---------------|-------------|
| Form field values | `node.data.filledData` (React state) | Mode switch to editor; workflow reset |
| Manager decision | `node.data.managerDecision` (React state) | Mode switch to editor |
| Attachment base64 | `EmailNode` component state | Component unmount |
| SMTP credentials | `backend/.env` only | Never exposed to frontend |
| Execution history | `allExecutionRuns` (React state) | Page refresh |

No sensitive data is written to `localStorage` except the transient `form_fill_${nodeId}` key, which is read and immediately deleted on first access.

---

## Performance Optimisation

### Node Type Registration

`nodeTypes` is defined outside the `App` component to prevent ReactFlow from re-registering custom node types on every render (which causes a full canvas remount).

```javascript
// Correct: outside component
const nodeTypes = { antigravity: AntigravityNode, ... };

export default function App() {
  return <ReactFlow nodeTypes={nodeTypes} ... />;
}
```

### useCallback for Handlers

All ReactFlow event handlers (`onNodesChange`, `onEdgesChange`, `onConnect`, `onDrop`, `handleTrigger`) are wrapped in `useCallback` with appropriate dependency arrays to prevent unnecessary recreations.

### Execution Mode Canvas Lock

In execution mode, `onNodesChange`, `onEdgesChange`, `onConnect`, and `onDrop` are set to `undefined`, preventing ReactFlow from processing user graph-modification events during execution.

### Parallel Node Execution

Within a layer, independent nodes execute concurrently via `Promise.all`, reducing total execution time for wide (multi-branch) workflows.

---

## Best Practices

- Define `nodeTypes` outside the component — never inline in JSX
- Use `useRef` for values that must be stable across async closures
- Keep execution logic in `App.jsx` — node components are presentational only
- Clear resolver refs after calling them to prevent memory leaks and double-resolve bugs
- Dispatch events via `window.dispatchEvent` for node-to-App communication rather than prop callbacks (avoids deep prop drilling through ReactFlow's node rendering)
- Validate inputs at both the UI level and the execution engine level
- Always reset `isExecuting`, node statuses, and resolver refs on mode switch or workflow reset
