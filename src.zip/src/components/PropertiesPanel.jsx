import { memo, useState, useEffect, useMemo } from 'react';
import { v4 as uuidv4 } from 'uuid';

const MODE_OPTIONS = ['WebSocket', 'TypeScript', 'NodeJS', 'Email', 'Custom'];
const FORM_FIELD_TYPES = ['text', 'number', 'email', 'date', 'select', 'textarea', 'file'];

/* ── Helper: Build upstream workflow variable context ── */
function buildContextFromNodes(allNodes, allEdges, currentNodeId) {
  const context = {};
  if (!allNodes || !allEdges || !currentNodeId) return context;

  const incomingMap = {};
  allEdges.forEach(e => {
    if (!incomingMap[e.target]) incomingMap[e.target] = [];
    incomingMap[e.target].push(e.source);
  });

  const visited = new Set();
  const queue = [...(incomingMap[currentNodeId] || [])];

  while (queue.length > 0) {
    const nId = queue.shift();
    if (visited.has(nId)) continue;
    visited.add(nId);
    const node = allNodes.find(n => n.id === nId);
    if (!node) continue;
    const nodeName = (node.data.label || node.id).replace(/\s+/g, '');

    if ((node.type === 'formNode' || (node.type === 'formTask' && node.data.taskMode === 'form1')) && node.data.filledData) {
      const fd = node.data.filledData;
      let fieldKeys = [];
      if (node.data.formFields && node.data.formFields.length > 0) {
        fieldKeys = node.data.formFields.filter(f => f.passThrough !== false).map(f => f.variableName).filter(Boolean);
      } else {
        fieldKeys = Object.keys(fd).filter(k => k !== 'attachments' && k !== 'formSource');
      }
      
      fieldKeys.forEach((key, index) => {
        if (fd[key] !== undefined) {
          context[key] = { value: fd[key], source: nodeName };
          context[`${nodeName}.${key}`] = { value: fd[key], source: nodeName };
          context[`${nodeName}(${index + 1})`] = { value: fd[key], source: nodeName }; // 1-based index
          
          if (key === 'email_id' || key === 'email') {
            context['email'] = { value: fd[key], source: nodeName };
            context[`${nodeName}.email`] = { value: fd[key], source: nodeName };
          }
        }
      });
    }

    if (node.type === 'aiAgent' && node.data.nodeOutput) {
      context[`${nodeName}.output`] = { value: node.data.nodeOutput, source: nodeName };
      context['AIAgent.output'] = { value: node.data.nodeOutput, source: nodeName };
    }

    if (node.type === 'apiCall' && node.data.apiResponsePreview) {
      context[`${nodeName}.output`] = { value: node.data.apiResponsePreview, source: nodeName };
    }

    if (node.type === 'uploadCsvNode') {
      if (node.data.csvHeaders && node.data.csvHeaders.length > 0) {
        node.data.csvHeaders.forEach(col => {
          context[`${nodeName}.${col}`] = { value: `[Data from ${col}]`, source: nodeName };
        });
      } else {
        const mockColumns = ['filename', 'Name', 'Email'];
        mockColumns.forEach(col => {
          context[`${nodeName}.${col}`] = { value: `[Mock ${col}]`, source: nodeName };
        });
      }
    } else if (node.type === 'googleSheetsNode') {
      // Expose some generic mock columns so the user can easily select them
      const mockColumns = ['columnName', 'id', 'name', 'email'];
      mockColumns.forEach(col => {
        context[`${nodeName}.${col}`] = { value: `[Data from ${col}]`, source: nodeName };
      });
    }

    (incomingMap[nId] || []).forEach(src => { if (!visited.has(src)) queue.push(src); });
  }
  return context;
}

/* ── Variable Mapper Section Component ── */
function VariableMapperSection({ context, selectedVariables = [], onToggle, onInsert }) {
  const [open, setOpen] = useState(false);
  
  const entries = Object.entries(context);
  if (entries.length === 0) return null;

  // Group fields by upstream node source
  const nodesMap = {};
  entries.forEach(([varName, { value, source }]) => {
    const src = source || 'Global';
    if (!nodesMap[src]) nodesMap[src] = [];
    nodesMap[src].push({ varName, value });
  });

  const sourceNodes = Object.keys(nodesMap);
  const [selectedSource, setSelectedSource] = useState(sourceNodes[0] || '');

  // Keep dropdown in sync if context updates list of nodes
  useEffect(() => {
    if (sourceNodes.length > 0 && !sourceNodes.includes(selectedSource)) {
      setSelectedSource(sourceNodes[0]);
    }
  }, [context, sourceNodes, selectedSource]);

  const displayedFields = nodesMap[selectedSource] || [];

  return (
    <div style={{ marginTop: 12 }}>
      <button
        onClick={() => setOpen(o => !o)}
        style={{
          width: '100%', display: 'flex', alignItems: 'center', gap: 6,
          background: 'color-mix(in srgb, #8b5cf6 8%, var(--bg-surface))',
          border: '1px solid color-mix(in srgb, #8b5cf6 25%, var(--border))',
          borderRadius: 6, padding: '7px 10px', cursor: 'pointer',
          fontSize: 11, fontWeight: 600, color: '#c4b5fd', textAlign: 'left'
        }}
      >
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
          <circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="16" /><line x1="8" y1="12" x2="16" y2="12" />
        </svg>
        Available Workflow Variables ({entries.length})
        <span style={{ marginLeft: 'auto', fontSize: 9 }}>{open ? '▲' : '▼'}</span>
      </button>
      {open && (
        <div style={{
          background: 'var(--bg-card)', border: '1px solid var(--border)',
          borderTop: 'none', borderRadius: '0 0 6px 6px', padding: '10px 10px',
          display: 'flex', flexDirection: 'column', gap: 8, maxHeight: 320, overflowY: 'auto'
        }}>
          {/* Dropdown to select upstream node */}
          <div>
            <label style={{ fontSize: 9, color: 'var(--text-muted)', display: 'block', marginBottom: 4, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>
              Select Upstream Node
            </label>
            <select
              value={selectedSource}
              onChange={(e) => setSelectedSource(e.target.value)}
              style={{
                width: '100%',
                background: 'var(--bg-secondary)',
                border: '1px solid var(--border)',
                borderRadius: '6px',
                color: 'var(--text-primary)',
                padding: '6px 8px',
                fontSize: '12px',
                fontWeight: 600,
                outline: 'none',
                cursor: 'pointer',
                marginBottom: 6
              }}
            >
              {sourceNodes.map(src => (
                <option key={src} value={src}>{src}</option>
              ))}
            </select>
          </div>

          <div style={{ fontSize: 9, color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase', marginBottom: 2, letterSpacing: '0.4px', borderBottom: '1px solid var(--border)', paddingBottom: 4 }}>
            Click to insert • Check to include in email
          </div>

          {displayedFields.length === 0 ? (
            <div style={{ fontSize: 11, color: 'var(--text-muted)', padding: '6px 0', textAlign: 'center' }}>
              No fields available for this node.
            </div>
          ) : (
            displayedFields.map(({ varName, value }) => (
              <div key={varName} style={{ display: 'flex', alignItems: 'flex-start', gap: 8, padding: '5px 0', borderBottom: '1px solid color-mix(in srgb, var(--border) 40%, transparent)' }}>
                <input
                  type="checkbox"
                  checked={selectedVariables.includes(varName)}
                  onChange={() => onToggle && onToggle(varName)}
                  style={{ marginTop: 2, cursor: 'pointer', accentColor: '#8b5cf6' }}
                />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <button
                    onClick={() => onInsert && onInsert(`\$\{${varName}\}`)}
                    style={{
                      background: 'none', border: 'none', cursor: 'pointer', padding: 0,
                      fontSize: 11, color: '#a78bfa', fontFamily: 'monospace', fontWeight: 600,
                      textAlign: 'left'
                    }}
                    title="Click to insert variable"
                  >
                    ${'{'}
                    {varName}
                    {'}'}
                  </button>
                  {value !== undefined && (
                    <div style={{
                      fontSize: 10, color: 'var(--text-muted)', marginTop: 2,
                      whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
                      maxWidth: '100%'
                    }}>
                      = {String(value).slice(0, 60)}{String(value).length > 60 ? '…' : ''}
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}

function PropertiesPanel({ selectedNode, onUpdateNode, onClose, onDeleteNode, allNodes = [], allEdges = [], onOpenDbSettings }) {
  const [formData, setFormData] = useState({});
  const [apiTestLoading, setApiTestLoading] = useState(false);
  const [emailTestLoading, setEmailTestLoading] = useState(false);
  const [sampleJsonText, setSampleJsonText] = useState('');
  const [jsonExtractError, setJsonExtractError] = useState('');

  // Compute upstream context for variable mapper
  const wfContext = useMemo(
    () => buildContextFromNodes(allNodes, allEdges, selectedNode?.id),
    [allNodes, allEdges, selectedNode?.id]
  );

  useEffect(() => {
    if (selectedNode) {
      setFormData({ ...selectedNode.data });
    }
  }, [selectedNode]);

  if (!selectedNode) return null;

  const handleChange = (key, value) => {
    const updated = { ...formData, [key]: value };
    setFormData(updated);
    onUpdateNode(selectedNode.id, updated);
  };

  const toggleMode = (mode) => {
    const currentModes = formData.modes || [];
    const newModes = currentModes.includes(mode)
      ? currentModes.filter((m) => m !== mode)
      : [...currentModes, mode];
    handleChange('modes', newModes);
  };

  // Insert variable text into a field
  const insertVariable = (fieldKey, varText) => {
    const current = formData[fieldKey] || '';
    handleChange(fieldKey, current + varText);
  };

  // Toggle selected variable for email
  const toggleSelectedVar = (varName) => {
    const current = formData.selectedEmailVariables || [];
    const updated = current.includes(varName)
      ? current.filter(v => v !== varName)
      : [...current, varName];
    handleChange('selectedEmailVariables', updated);
  };

  /* ── API Test Call ── */
  const handleTestApi = async () => {
    if (!formData.apiUrl) return;
    setApiTestLoading(true);
    handleChange('apiStatus', 'loading');

    try {
      const headers = {};
      if (formData.apiHeaders) {
        try {
          const parsed = JSON.parse(formData.apiHeaders);
          Object.assign(headers, parsed);
        } catch { /* ignore bad JSON */ }
      }

      const fetchOptions = {
        method: formData.apiMethod || 'GET',
        headers,
      };

      if (['POST', 'PUT', 'PATCH'].includes(fetchOptions.method) && formData.apiBody) {
        fetchOptions.body = formData.apiBody;
        if (!headers['Content-Type']) {
          headers['Content-Type'] = 'application/json';
        }
      }

      const res = await fetch(formData.apiUrl, fetchOptions);
      const text = await res.text();

      if (res.ok) {
        handleChange('apiStatus', 'success');
        handleChange('apiResponseCode', res.status);
        handleChange('apiResponsePreview', text.slice(0, 200));
      } else {
        handleChange('apiStatus', 'error');
        handleChange('apiResponseCode', res.status);
        handleChange('apiResponsePreview', text.slice(0, 200));
      }
    } catch (err) {
      handleChange('apiStatus', 'error');
      handleChange('apiResponseCode', null);
      handleChange('apiResponsePreview', err.message);
    } finally {
      setApiTestLoading(false);
    }
  };

  /* ── Email Test Call ── */
  const handleTestEmail = async () => {
    setEmailTestLoading(true);
    handleChange('emailStatus', 'loading');

    try {
      const email = formData.recipient || '';
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      
      if (!email) {
        throw new Error('No recipient email configured.');
      }
      if (!emailRegex.test(email)) {
        throw new Error(`Invalid email format: ${email}`);
      }

      const res = await fetch('/api/send-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          to: email,
          subject: formData.subject || 'Test Email from Workflow',
          body: 'This is a test email sent from the Antigravity Workflow Orchestrator.',
          formData: [],
        }),
      });
      const result = await res.json();
      if (result.success) {
        handleChange('emailStatus', 'success');
        handleChange('emailResponsePreview', result.message || `Email sent to ${email}`);
      } else {
        throw new Error(result.error || 'The mail is not getting sent.');
      }
    } catch (err) {
      handleChange('emailStatus', 'error');
      handleChange('emailResponsePreview', err.message);
    } finally {
      setEmailTestLoading(false);
    }
  };

  /* ── Form Field Helpers ── */
  const addFormField = () => {
    const fields = formData.formFields || [];
    const newField = {
      id: uuidv4(),
      label: `Field ${fields.length + 1}`,
      variableName: `field_${fields.length + 1}`,
      type: 'text',
      value: '',
      required: false,
    };
    handleChange('formFields', [...fields, newField]);
  };

  const updateFormField = (fieldId, key, value) => {
    const fields = (formData.formFields || []).map(f =>
      f.id === fieldId ? { ...f, [key]: value } : f
    );
    handleChange('formFields', fields);
  };

  const removeFormField = (fieldId) => {
    const fields = (formData.formFields || []).filter(f => f.id !== fieldId);
    handleChange('formFields', fields);
  };

  const handleFormAttachment = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const attachments = formData.formAttachments || [];
      handleChange('formAttachments', [...attachments, {
        name: file.name,
        size: file.size,
        data: ev.target.result,
      }]);
    };
    reader.readAsDataURL(file);
  };

  const removeAttachment = (idx) => {
    const attachments = (formData.formAttachments || []).filter((_, i) => i !== idx);
    handleChange('formAttachments', attachments);
  };

  const handleExtractJson = () => {
    if (!sampleJsonText.trim()) {
      setJsonExtractError('Please enter some JSON first.');
      return;
    }
    try {
      const parsed = JSON.parse(sampleJsonText);
      const extractedFields = [];
      const currentFields = formData.formFields || [];
      
      const processObject = (obj, prefix = '') => {
        Object.keys(obj).forEach(key => {
          const val = obj[key];
          const varName = prefix ? `${prefix}.${key}` : key;
          if (val && typeof val === 'object' && !Array.isArray(val)) {
            processObject(val, varName);
          } else {
             if (!currentFields.find(f => f.variableName === varName)) {
               let type = 'text';
               if (typeof val === 'number') type = 'number';
               if (typeof val === 'string' && val.includes('@')) type = 'email';
               
               let label = key.replace(/_/g, ' ').replace(/\\b\\w/g, c => c.toUpperCase());
               
               extractedFields.push({
                 id: uuidv4(),
                 label: label,
                 variableName: varName,
                 type: type,
                 value: '',
                 required: false
               });
             }
          }
        });
      };
      
      processObject(parsed);
      
      if (extractedFields.length > 0) {
        handleChange('formFields', [...currentFields, ...extractedFields]);
        setSampleJsonText('');
        setJsonExtractError('');
      } else {
        setJsonExtractError('No new fields found (or all already exist).');
      }
    } catch (e) {
      setJsonExtractError('Invalid JSON format.');
    }
  };

  const handleTestFormAndExtract = () => {
    const reqId = formData.requestId || `REQ-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
    if (!formData.requestId) {
      handleChange('requestId', reqId);
    }
    const fillUrl = `${window.location.origin}${window.location.pathname}#/fill-form/${selectedNode.id}/${reqId}`;
    window.open(fillUrl, '_blank', 'width=500,height=600,status=no,menubar=no,resizable=yes');
    
    const onMessage = (event) => {
      if (event.data && event.data.type === 'FORM_SUBMITTED' && event.data.nodeId === selectedNode.id) {
        const submittedData = event.data.formData;
        // Don't include raw attachments in the sample payload to keep it clean
        const cleanedData = { ...submittedData };
        if (cleanedData.attachments) delete cleanedData.attachments;
        
        const submittedJson = JSON.stringify(cleanedData, null, 2);
        setSampleJsonText(submittedJson);
        setJsonExtractError('');
        window.removeEventListener('message', onMessage);
      }
    };
    window.addEventListener('message', onMessage);
  };

  const isStartNode = selectedNode.data?.nodeType === 'start' || (selectedNode.data?.label || '').toLowerCase() === 'start';

  const nodeTypeName = selectedNode.type === 'antigravity'
    ? 'Antigravity Data'
    : selectedNode.type === 'modeController'
    ? 'Mode Controller'
    : selectedNode.type === 'task'
    ? 'Task Node'
    : selectedNode.type === 'swimlane'
    ? 'Workflow Group'
    : selectedNode.type === 'apiCall'
    ? 'API Call Node'
    : selectedNode.type === 'formNode'
    ? 'Form Node'
    : selectedNode.type === 'managerNode'
    ? 'Manager Review'
    : selectedNode.type === 'formTask'
    ? 'Form Task'
    : selectedNode.type === 'emailNode'
    ? 'Email Node'
    : selectedNode.type === 'smsNode'
    ? 'SMS Node'
    : selectedNode.type === 'aiAgent'
    ? 'AI Agent'
    : selectedNode.type === 'screenScraperNode'
    ? 'Screen Scraper'
    : selectedNode.type === 'uploadCsvNode'
    ? 'Upload CSV'
    : selectedNode.type === 'googleSheetsNode'
    ? 'Google Sheets'
    : selectedNode.type === 'dbCallNode'
    ? 'DB Call Node'
    : 'Generic Node';

  const hasContext = Object.keys(wfContext).length > 0;

  return (
    <aside className="properties-panel" id="properties-panel">
      <div className="props-header">
        <h2 className="props-title">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M12 20h9" /><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" />
          </svg>
          Edit Node
        </h2>
        <button className="props-close" onClick={onClose} aria-label="Close properties">
          ✕
        </button>
      </div>

      <div className="props-type-badge">{nodeTypeName}</div>
      
      {formData.execStatus === 'error' && formData.execError && (
         <div style={{ margin: '12px 16px 0', padding: '10px', background: 'var(--bg-card)', border: '1px solid rgba(239, 68, 68, 0.4)', borderRadius: '6px', color: '#ef4444', fontSize: '13px', lineHeight: '1.4' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '4px', fontWeight: 'bold' }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="12" y1="8" x2="12" y2="12"></line>
                <line x1="12" y1="16" x2="12.01" y2="16"></line>
              </svg>
              Execution Error
            </div>
            {formData.execError}
         </div>
      )}

      <div className="props-body">
        {/* ── Common fields ── */}
        <div className="field-group">
          <label className="field-label">Label</label>
          <input
            className="field-input"
            type="text"
            value={formData.label || ''}
            onChange={(e) => handleChange('label', e.target.value)}
            placeholder="Enter node label…"
          />
        </div>

        <div className="field-group">
          <label className="field-label">Description</label>
          <textarea
            className="field-textarea"
            value={formData.description || ''}
            onChange={(e) => handleChange('description', e.target.value)}
            placeholder="Enter description…"
            rows={3}
          />
        </div>

        {/* ── Upstream Variable Mapper (all nodes except start and dbCall) ── */}
        {!isStartNode && hasContext && selectedNode.type !== 'dbCallNode' && (
          <VariableMapperSection
            context={wfContext}
            selectedVariables={formData.selectedEmailVariables || []}
            onToggle={toggleSelectedVar}
            onInsert={(varText) => {
              // Try to insert into relevant prompt/body field based on node type
              if (selectedNode.type === 'aiAgent') insertVariable('promptTemplate', varText);
              else if (selectedNode.type === 'emailNode') insertVariable('emailBodyTemplate', varText);
            }}
          />
        )}

        {/* ── AI Agent Node fields ── */}
        {selectedNode.type === 'aiAgent' && (
          <>
            <div className="field-divider" />
            <h3 className="field-section-title">AI Agent Configuration</h3>

            {/* Settings-inherited config badge */}
            {(() => {
              const cfg = (() => { try { return JSON.parse(localStorage.getItem('antigravity_ai_config') || '{}'); } catch { return {}; } })();
              return cfg.provider ? (
                <div style={{
                  display: 'flex', alignItems: 'center', gap: 6, padding: '6px 10px',
                  background: 'color-mix(in srgb, #8b5cf6 8%, var(--bg-card))',
                  border: '1px solid color-mix(in srgb, #8b5cf6 25%, var(--border))',
                  borderRadius: 6, fontSize: 11, color: '#c4b5fd', marginBottom: 4
                }}>
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10" /><polyline points="22 4 12 14.01 9 11.01" /></svg>
                  Using: <strong>{cfg.provider}</strong> from Settings
                </div>
              ) : (
                <div style={{ fontSize: 11, color: '#f87171', marginBottom: 4, padding: '6px 10px', background: 'rgba(239,68,68,0.08)', borderRadius: 6, border: '1px solid rgba(239,68,68,0.25)' }}>
                  ⚠ No AI key configured — go to Settings first
                </div>
              );
            })()}

            <div className="field-group">
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
                <label className="field-label">Prompt Template</label>
                {hasContext && (
                  <span style={{ fontSize: 10, color: '#a78bfa', cursor: 'pointer' }}>
                    ← use variable list above to insert
                  </span>
                )}
              </div>
              <textarea
                className="field-textarea"
                value={formData.promptTemplate || ''}
                onChange={(e) => handleChange('promptTemplate', e.target.value)}
                placeholder={'Prepare a company profile for {{company_name}}.\nWebsite: {{website_url}}\nEmail: {{email_id}}'}
                rows={7}
                style={{ fontFamily: 'monospace', fontSize: 12 }}
              />
              <div style={{ fontSize: 10, color: 'var(--text-muted)', marginTop: 3 }}>
                Use {'{{variableName}}'} syntax to insert workflow variables
              </div>
            </div>

            {/* AI Output preview */}
            {formData.nodeOutput && (
              <div style={{ marginTop: 8 }}>
                <label className="field-label">Last Output</label>
                <div style={{
                  background: 'var(--bg-secondary)', border: '1px solid color-mix(in srgb, #22c55e 25%, var(--border))',
                  borderRadius: 6, padding: '8px 10px', fontSize: 11, color: 'var(--text-secondary)',
                  lineHeight: 1.5, maxHeight: 120, overflowY: 'auto', whiteSpace: 'pre-wrap'
                }}>
                  {formData.nodeOutput}
                </div>
              </div>
            )}
          </>
        )}

        {/* ── API Call Node fields ── */}
        {selectedNode.type === 'apiCall' && (
          <>
            <div className="field-divider" />
            <h3 className="field-section-title">API Configuration</h3>

            <div className="field-group">
              <label className="field-label">Method</label>
              <select
                className="field-select"
                value={formData.apiMethod || 'GET'}
                onChange={(e) => handleChange('apiMethod', e.target.value)}
              >
                <option value="GET">GET</option>
                <option value="POST">POST</option>
                <option value="PUT">PUT</option>
                <option value="PATCH">PATCH</option>
                <option value="DELETE">DELETE</option>
              </select>
            </div>

            <div className="field-group">
              <label className="field-label">URL</label>
              <input
                className="field-input"
                type="url"
                value={formData.apiUrl || ''}
                onChange={(e) => handleChange('apiUrl', e.target.value)}
                placeholder="https://api.example.com/endpoint"
              />
            </div>

            <div className="field-group">
              <label className="field-label">Headers (JSON)</label>
              <textarea
                className="field-textarea api-json-input"
                value={formData.apiHeaders || ''}
                onChange={(e) => handleChange('apiHeaders', e.target.value)}
                placeholder='{"Authorization": "Bearer token"}'
                rows={2}
              />
            </div>

            {['POST', 'PUT', 'PATCH'].includes(formData.apiMethod || 'GET') && (
              <div className="field-group">
                <label className="field-label">Body (JSON)</label>
                <textarea
                  className="field-textarea api-json-input"
                  value={formData.apiBody || ''}
                  onChange={(e) => handleChange('apiBody', e.target.value)}
                  placeholder='{"key": "value"}'
                  rows={3}
                />
              </div>
            )}

            <button
              className={`api-test-btn ${apiTestLoading ? 'loading' : ''}`}
              onClick={handleTestApi}
              disabled={!formData.apiUrl || apiTestLoading}
            >
              {apiTestLoading ? (
                <>
                  <span className="api-test-spinner" />
                  Testing…
                </>
              ) : (
                <>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <polygon points="5 3 19 12 5 21 5 3" />
                  </svg>
                  Test API Call
                </>
              )}
            </button>

            {formData.apiStatus && formData.apiStatus !== 'idle' && formData.apiStatus !== 'loading' && (
              <div className={`api-result-card ${formData.apiStatus}`}>
                <div className="api-result-header">
                  <span className={`api-result-icon ${formData.apiStatus}`}>
                    {formData.apiStatus === 'success' ? '✓' : '✕'}
                  </span>
                  <span className="api-result-title">
                    {formData.apiStatus === 'success' ? 'Success' : 'Failed'}
                  </span>
                  {formData.apiResponseCode && (
                    <span className="api-result-code">{formData.apiResponseCode}</span>
                  )}
                </div>
                {formData.apiResponsePreview && (
                  <pre className="api-result-body">{formData.apiResponsePreview}</pre>
                )}
              </div>
            )}
          </>
        )}

        {/* ── Form Node or Form Task Node fields ── */}
        {(selectedNode.type === 'formTask' || selectedNode.type === 'formNode') && (
          <>
            <div className="field-divider" />
            <h3 className="field-section-title">Form Settings</h3>

            {selectedNode.type === 'formTask' && (
              <div className="field-group">
                <label className="field-label">Task Type</label>
                <select
                  className="field-select"
                  value={formData.taskMode || 'form1'}
                  onChange={(e) => handleChange('taskMode', e.target.value)}
                >
                  <option value="form1">Form 1 (Data Entry)</option>
                  <option value="form2">Form 2 (Review / Approve)</option>
                </select>
              </div>
            )}

            {(selectedNode.type === 'formNode' || formData.taskMode === 'form1') && (
              <>
                <div className="field-group">
                  <label className="field-label">Form Source</label>
                  <select
                    className="field-select"
                    value={formData.formSource || 'builtin'}
                    onChange={(e) => handleChange('formSource', e.target.value)}
                  >
                    <option value="builtin">Built-in Form (Manual)</option>
                    <option value="pdf">Built-in Form (PDF OCR Upload)</option>
                    <option value="custom">Custom URL (e.g. Google Form)</option>
                  </select>
                </div>

                {formData.formSource === 'custom' && (
                  <div className="field-group">
                    <label className="field-label">Custom Form URL</label>
                    <input
                      className="field-input"
                      type="url"
                      value={formData.customUrl || ''}
                      onChange={(e) => handleChange('customUrl', e.target.value)}
                      placeholder="https://docs.google.com/forms/..."
                    />
                  </div>
                )}

                {/* ── JSON Extractor ── */}
                <div className="field-divider" />
                <h3 className="field-section-title">Extract Variables from JSON</h3>
                <div className="field-group">
                  <label className="field-label" style={{ fontSize: '10px', color: 'var(--text-muted)' }}>Paste sample JSON payload below to auto-generate form fields.</label>
                  <textarea
                    className="field-textarea"
                    value={sampleJsonText}
                    onChange={(e) => setSampleJsonText(e.target.value)}
                    placeholder='{"email": "user@example.com", "name": "John Doe"}'
                    rows={4}
                    style={{ fontFamily: 'monospace', fontSize: 11 }}
                  />
                  {jsonExtractError && <div style={{ fontSize: '11px', color: '#ef4444', marginTop: '4px' }}>{jsonExtractError}</div>}
                  <div style={{ display: 'flex', gap: '8px', marginTop: '6px' }}>
                    <button 
                      onClick={handleExtractJson}
                      style={{
                        background: 'color-mix(in srgb, #8b5cf6 15%, transparent)',
                        color: '#a78bfa',
                        border: '1px solid color-mix(in srgb, #8b5cf6 30%, transparent)',
                        padding: '6px 12px',
                        borderRadius: '4px',
                        fontSize: '11px',
                        fontWeight: 600,
                        cursor: 'pointer',
                        flex: 1
                      }}
                    >
                      Auto-Extract Fields
                    </button>
                    <button 
                      onClick={handleTestFormAndExtract}
                      style={{
                        background: 'color-mix(in srgb, #10b981 15%, transparent)',
                        color: '#34d399',
                        border: '1px solid color-mix(in srgb, #10b981 30%, transparent)',
                        padding: '6px 12px',
                        borderRadius: '4px',
                        fontSize: '11px',
                        fontWeight: 600,
                        cursor: 'pointer',
                        flex: 1
                      }}
                    >
                      Test Form & Paste JSON
                    </button>
                  </div>
                </div>

                {/* ── Dynamic Form Field Builder ── */}
                <div className="field-divider" />
                <h3 className="field-section-title">Form Fields</h3>
                <div className="form-builder-list">
                  {(formData.formFields || []).map((field) => (
                    <div key={field.id} className="form-builder-item">
                      <div className="form-builder-row">
                        <input
                          className="field-input form-builder-label-input"
                          type="text"
                          placeholder="Field Label"
                          value={field.label}
                          onChange={(e) => updateFormField(field.id, 'label', e.target.value)}
                        />
                        <select
                          className="field-select form-builder-type-select"
                          value={field.type || 'text'}
                          onChange={(e) => updateFormField(field.id, 'type', e.target.value)}
                        >
                          {FORM_FIELD_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                        </select>
                        <button
                          className="form-builder-remove-btn"
                          onClick={() => removeFormField(field.id)}
                          disabled={field.id === 'email_id_default'}
                          title={field.id === 'email_id_default' ? 'Email ID is required' : 'Remove field'}
                        >✕</button>
                      </div>
                      <div className="form-builder-row" style={{ gap: 4 }}>
                        <input
                          className="field-input"
                          type="text"
                          placeholder="variable_name (e.g. company_name)"
                          value={field.variableName || ''}
                          onChange={(e) => updateFormField(field.id, 'variableName', e.target.value)}
                          style={{ fontSize: 11, fontFamily: 'monospace' }}
                        />
                      </div>
                      <div className="form-builder-options">
                        <label className="form-builder-checkbox">
                          <input
                            type="checkbox"
                            checked={field.passThrough !== false}
                            onChange={(e) => updateFormField(field.id, 'passThrough', e.target.checked)}
                          />
                          Pass to next node
                        </label>
                      </div>
                    </div>
                  ))}
                </div>
                <button className="form-add-field-btn" onClick={addFormField}>
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" />
                  </svg>
                  Add Field
                </button>
              </>
            )}

            <div className="field-group" style={{ marginTop: '12px' }}>
              <label className="form-builder-checkbox" style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontSize: '12px', color: 'var(--text-primary)' }}>
                <input
                  type="checkbox"
                  checked={formData.useExistingDetails || false}
                  onChange={(e) => handleChange('useExistingDetails', e.target.checked)}
                />
                Prepopulate from previous (JSON)
              </label>
            </div>

            {formData.taskMode === 'form1' && (
              <div style={{ marginTop: '16px' }}>
                <h4 style={{ fontSize: '11px', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: '8px' }}>Task Status</h4>
                <div style={{ padding: '10px', background: 'var(--bg-hover)', borderRadius: '6px', fontSize: '12px' }}>
                   Status: <strong>{formData.formStatus || 'draft'}</strong>
                   {formData.requestId && <div style={{ marginTop: '4px' }}>Req: {formData.requestId}</div>}
                </div>
              </div>
            )}

            {formData.taskMode === 'form2' && formData.managerStatus === 'submitted' && (
              <div style={{ marginTop: '16px', padding: '12px', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '6px' }}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', fontSize: '12px' }}>
                  <div>
                    <strong>Decision:</strong>{' '}
                    <span style={{
                      fontWeight: 'bold',
                      color: formData.managerDecision === 'approved' ? '#22c55e' : '#ef4444',
                      textTransform: 'uppercase'
                    }}>
                      {formData.managerDecision}
                    </span>
                  </div>
                  {formData.managerComments && (
                    <div>
                      <strong>Comments:</strong>
                      <p style={{ margin: '4px 0 0 0', color: 'var(--text-secondary)', fontStyle: 'italic' }}>
                        "{formData.managerComments}"
                      </p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </>
        )}

        {/* ── Email Node fields ── */}
        {selectedNode.type === 'emailNode' && (
          <>
            <div className="field-divider" />
            <h3 className="field-section-title">Email Configuration</h3>

            {/* Context-based recipient badge */}
            {(() => {
              const emailKey = Object.keys(wfContext).find(k => 
                k === 'email' || k === 'email_id' || 
                k.endsWith('.email') || k.endsWith('.email_id') || 
                k.endsWith('(3)')
              );
              
              if (emailKey && wfContext[emailKey]) {
                return (
                  <div style={{
                    display: 'flex', alignItems: 'center', gap: 6, padding: '7px 10px',
                    background: 'color-mix(in srgb, #22c55e 8%, var(--bg-card))',
                    border: '1px solid color-mix(in srgb, #22c55e 25%, var(--border))',
                    borderRadius: 6, fontSize: 11, color: '#4ade80', marginBottom: 4
                  }}>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="22 4 12 14.01 9 11.01" /></svg>
                    Auto-recipient: <strong style={{ fontFamily: 'monospace' }}>{String(wfContext[emailKey].value)}</strong>
                    <span style={{ color: 'var(--text-muted)', fontSize: 10 }}>(from {"{{" + emailKey + "}}"})</span>
                  </div>
                );
              }
              return (
                <div className="field-group">
                  <label className="field-label">Recipient (To)</label>
                  <input
                    className="field-input"
                    type="email"
                    value={formData.recipient || ''}
                    onChange={(e) => handleChange('recipient', e.target.value)}
                    placeholder="dummy@gmail.com"
                  />
                </div>
              );
            })()}

            <div className="field-group">
              <label className="field-label">Subject</label>
              <input
                className="field-input"
                type="text"
                value={formData.subject || ''}
                onChange={(e) => handleChange('subject', e.target.value)}
                placeholder="Email Subject"
              />
            </div>

            {/* Email Content Builder */}
            {hasContext && (
              <>
                <div className="field-divider" />
                <h3 className="field-section-title">Email Content Builder</h3>
                <div style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 6 }}>
                  Check variables to include in the auto-generated email body:
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 4, maxHeight: 160, overflowY: 'auto', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 6, padding: '6px 8px' }}>
                  {Object.entries(wfContext).map(([varName, { value }]) => (
                    <label key={varName} style={{ display: 'flex', alignItems: 'flex-start', gap: 6, cursor: 'pointer', fontSize: 11 }}>
                      <input
                        type="checkbox"
                        checked={(formData.selectedEmailVariables || []).includes(varName)}
                        onChange={() => toggleSelectedVar(varName)}
                        style={{ marginTop: 2, accentColor: '#ec4899' }}
                      />
                      <span style={{ fontFamily: 'monospace', color: '#f9a8d4' }}>{varName}</span>
                      <span style={{ color: 'var(--text-muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 120 }}>
                        = {String(value).slice(0, 40)}
                      </span>
                    </label>
                  ))}
                </div>
              </>
            )}

            {/* Optional: Custom body override */}
            <div className="field-group" style={{ marginTop: 8 }}>
              <label className="field-label">Custom Body Template (optional)</label>
              <textarea
                className="field-textarea"
                value={formData.emailBodyTemplate || ''}
                onChange={(e) => handleChange('emailBodyTemplate', e.target.value)}
                placeholder={'Override auto-body. Use {{variable}} syntax.\n\nExample:\nDear User,\n\n{{AIAgent.output}}\n\nRegards,\nWorkflow System'}
                rows={5}
                style={{ fontFamily: 'monospace', fontSize: 11 }}
              />
            </div>

            <div className="field-group">
              <label className="form-builder-checkbox" style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontSize: '12px', color: 'var(--text-primary)' }}>
                <input
                  type="checkbox"
                  checked={formData.attachForm || false}
                  onChange={(e) => handleChange('attachForm', e.target.checked)}
                />
                Attach User & Form Details
              </label>
            </div>

            <button
              className={`api-test-btn ${emailTestLoading ? 'loading' : ''}`}
              onClick={handleTestEmail}
              disabled={emailTestLoading}
              style={{ marginTop: '10px' }}
            >
              {emailTestLoading ? (
                <>
                  <span className="api-test-spinner" />
                  Authenticating...
                </>
              ) : (
                <>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <polygon points="5 3 19 12 5 21 5 3" />
                  </svg>
                  Test Send Email
                </>
              )}
            </button>

            {formData.emailStatus && formData.emailStatus !== 'idle' && formData.emailStatus !== 'loading' && (
              <div className={`api-result-card ${formData.emailStatus}`}>
                <div className="api-result-header">
                  <span className={`api-result-icon ${formData.emailStatus}`}>
                    {formData.emailStatus === 'success' ? '✓' : '✕'}
                  </span>
                  <span className="api-result-title">
                    {formData.emailStatus === 'success' ? 'Success' : 'Failed'}
                  </span>
                </div>
                {formData.emailResponsePreview && (
                  <div className="api-result-body" style={{ marginTop: '6px', whiteSpace: 'pre-wrap', fontFamily: 'inherit', fontSize: '11px' }}>
                    {formData.emailResponsePreview}
                  </div>
                )}
              </div>
            )}
          </>
        )}

        {/* ── SMS Node fields ── */}
        {selectedNode.type === 'smsNode' && (
          <>
            <div className="field-divider" />
            <h3 className="field-section-title">SMS Configuration</h3>

            <div className="field-group">
              <label className="field-label">Phone Number (To)</label>
              <input
                className="field-input"
                type="tel"
                value={formData.phoneNumber || ''}
                onChange={(e) => handleChange('phoneNumber', e.target.value)}
                placeholder="+1234567890"
              />
            </div>

            <div className="field-group">
              <label className="field-label">Message</label>
              <textarea
                className="field-textarea"
                value={formData.smsMessage || ''}
                onChange={(e) => handleChange('smsMessage', e.target.value)}
                placeholder="Enter SMS content..."
                rows={3}
              />
            </div>
          </>
        )}

        {/* ── Antigravity fields ── */}
        {selectedNode.type === 'antigravity' && (
          <>
            <div className="field-divider" />
            <h3 className="field-section-title">Antigravity Config</h3>

            <div className="field-group">
              <label className="field-label">Variant</label>
              <select
                className="field-select"
                value={formData.variant || 'son'}
                onChange={(e) => handleChange('variant', e.target.value)}
              >
                <option value="son">SON</option>
                <option value="log">LOG</option>
              </select>
            </div>

            <div className="field-group">
              <label className="field-label">Where</label>
              <input
                className="field-input"
                type="text"
                value={formData.where || ''}
                onChange={(e) => handleChange('where', e.target.value)}
                placeholder="e.g. CBS, Server…"
              />
            </div>

            <div className="field-group">
              <label className="field-label">CBS Target</label>
              <input
                className="field-input"
                type="text"
                value={formData.cbsTarget || ''}
                onChange={(e) => handleChange('cbsTarget', e.target.value)}
                placeholder="e.g. i8n"
              />
            </div>

            <div className="field-group">
              <label className="field-label">Log</label>
              <input
                className="field-input"
                type="text"
                value={formData.log || ''}
                onChange={(e) => handleChange('log', e.target.value)}
                placeholder="Log identifier…"
              />
            </div>

            <div className="field-group">
              <label className="field-label">Registers</label>
              <input
                className="field-input"
                type="text"
                value={formData.registers || ''}
                onChange={(e) => handleChange('registers', e.target.value)}
                placeholder="Register values…"
              />
            </div>

            <div className="field-group">
              <label className="field-label">Mode Controller</label>
              <input
                className="field-input"
                type="text"
                value={formData.modeController || ''}
                onChange={(e) => handleChange('modeController', e.target.value)}
                placeholder="Mode controller…"
              />
            </div>

            <div className="field-group">
              <label className="field-label">Elapsed Structure</label>
              <input
                className="field-input"
                type="text"
                value={formData.elapsedStructure || ''}
                onChange={(e) => handleChange('elapsedStructure', e.target.value)}
                placeholder="Elapsed structure…"
              />
            </div>
          </>
        )}

        {/* ── Task Node fields ── */}
        {selectedNode.type === 'task' && (
          <>
            <div className="field-divider" />
            <h3 className="field-section-title">Task Config</h3>

            <div className="field-group">
              <label className="field-label">Role</label>
              <input
                className="field-input"
                type="text"
                value={formData.role || ''}
                onChange={(e) => handleChange('role', e.target.value)}
                placeholder="Assignee role..."
              />
            </div>

            <div className="field-group">
              <label className="field-label">Document Upload</label>
              <input
                className="field-input"
                type="file"
                style={{ padding: '6px 0', fontSize: '11px' }}
                onChange={(e) => {
                  const file = e.target.files[0];
                  if (!file) return;
                  const reader = new FileReader();
                  reader.onload = (ev) => {
                    handleChange('document', { name: file.name, data: ev.target.result });
                  };
                  reader.readAsDataURL(file);
                }}
              />
              {formData.document && formData.document.name && (
                <div style={{ marginTop: '4px', fontSize: '11px', color: 'var(--accent-primary)' }}>
                  Current: {formData.document.name}
                </div>
              )}
            </div>

            <div className="field-group">
              <label className="field-label">Link</label>
              <input
                className="field-input"
                type="url"
                value={formData.link || ''}
                onChange={(e) => handleChange('link', e.target.value)}
                placeholder="URL structure..."
              />
            </div>
          </>
        )}

        {/* ── Mode Controller fields ── */}
        {selectedNode.type === 'modeController' && (
          <>
            <div className="field-divider" />
            <h3 className="field-section-title">Mode Selection</h3>

            <div className="mode-chips">
              {MODE_OPTIONS.map((mode) => (
                <button
                  key={mode}
                  className={`mode-chip-btn ${(formData.modes || []).includes(mode) ? 'active' : ''}`}
                  onClick={() => toggleMode(mode)}
                >
                  {mode}
                </button>
              ))}
            </div>
          </>
        )}
        {/* ── Screen Scraper Node fields ── */}
        {selectedNode.type === 'screenScraperNode' && (
          <>
            <div className="field-divider" />
            <h3 className="field-section-title">Screen Scraper Configuration</h3>
            <div className="field-group">
              <label className="field-label">Target Website URL</label>
              <input
                className="field-input"
                type="url"
                value={formData.websiteUrl || ''}
                onChange={(e) => handleChange('websiteUrl', e.target.value)}
                placeholder="https://example.com"
              />
            </div>
          </>
        )}

        {/* ── Upload CSV Node fields ── */}
        {selectedNode.type === 'uploadCsvNode' && (
          <>
            <div className="field-divider" />
            <h3 className="field-section-title">Upload CSV Configuration</h3>
            <div className="field-group">
              <label className="field-label">CSV File</label>
              <input
                className="field-input"
                type="file"
                accept=".csv"
                onChange={(e) => {
                  const file = e.target.files[0];
                  if (file) {
                    const reader = new FileReader();
                    reader.onload = (evt) => {
                      const text = evt.target.result;
                      const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
                      if (lines.length > 0) {
                        const headers = lines[0].split(',').map(h => h.trim());
                        let data = [];
                        for (let i = 1; i < lines.length; i++) {
                          const values = lines[i].split(',').map(v => v.trim());
                          const row = {};
                          headers.forEach((h, idx) => { row[h] = values[idx] || ''; });
                          data.push(row);
                        }
                        
                        // Apply all updates at once to avoid React stale closure issues
                        const updated = { 
                           ...formData, 
                           csvFileName: file.name,
                           csvHeaders: headers,
                           csvData: data 
                        };
                        setFormData(updated);
                        onUpdateNode(selectedNode.id, updated);
                      }
                    };
                    reader.readAsText(file);
                  }
                }}
              />
              {formData.csvFileName && (
                <div style={{ marginTop: '4px', fontSize: '11px', color: 'var(--text-secondary)' }}>
                  Selected: {formData.csvFileName}
                </div>
              )}
            </div>
          </>
        )}

        {/* ── Google Sheets Node fields ── */}
        {selectedNode.type === 'googleSheetsNode' && (
          <>
            <div className="field-divider" />
            <h3 className="field-section-title">Google Sheets Configuration</h3>
            <div className="field-group">
              <label className="field-label">Google Sheet URL</label>
              <input
                className="field-input"
                type="url"
                value={formData.googleSheetUrl || ''}
                onChange={(e) => handleChange('googleSheetUrl', e.target.value)}
                placeholder="https://docs.google.com/spreadsheets/d/..."
              />
            </div>
          </>
        )}

        {/* ── DB Call Node fields ── */}
        {selectedNode.type === 'dbCallNode' && (
          <>
            <div className="field-divider" />
            <h3 className="field-section-title">Database Action</h3>
            
            <div style={{ padding: '12px', background: 'color-mix(in srgb, var(--bg-surface) 50%, transparent)', border: '1px solid var(--border)', borderRadius: '6px', marginBottom: '16px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                <span style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)' }}>Connection</span>
                <button 
                  onClick={onOpenDbSettings}
                  style={{
                    background: 'var(--accent-primary)', color: 'white', border: 'none', borderRadius: '4px',
                    padding: '4px 8px', fontSize: '10px', fontWeight: 600, cursor: 'pointer'
                  }}
                >
                  {(() => {
                    const raw = localStorage.getItem('antigravity_db_config');
                    const parsed = raw ? JSON.parse(raw) : null;
                    return (parsed && parsed.host) ? 'Edit Config' : 'Add New';
                  })()}
                </button>
              </div>
              {(() => {
                const raw = localStorage.getItem('antigravity_db_config');
                const dbConfig = raw ? JSON.parse(raw) : null;
                const hasDbConfig = dbConfig && dbConfig.host && dbConfig.dbName;
                
                return hasDbConfig ? (
                  <div style={{ fontSize: '11px', color: 'var(--text-primary)' }}>
                    <div><strong>Host:</strong> {dbConfig.host}</div>
                    <div><strong>DB:</strong> {dbConfig.dbName}</div>
                  </div>
                ) : (
                  <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>
                    No database configured. Click Add New to configure.
                  </div>
                );
              })()}
            </div>

            <div className="field-group">
              <label className="field-label">Target Data Field</label>
              <VariableMapperSection 
                context={wfContext} 
                selectedVariables={formData.dbTargetField ? [formData.dbTargetField] : []}
                onToggle={(v) => handleChange('dbTargetField', formData.dbTargetField === v ? '' : v)}
              />
              <input
                className="field-input"
                type="text"
                value={formData.dbTargetField || ''}
                onChange={(e) => handleChange('dbTargetField', e.target.value)}
                placeholder="e.g. excelData.columnName or type custom"
                style={{ marginTop: '8px' }}
              />
              <div style={{ fontSize: '10px', color: 'var(--text-muted)', marginTop: '4px' }}>
                Select a field from previous nodes (like Excel/CSV) or type a manual field name.
              </div>
            </div>

            <div className="field-group">
              <label className="field-label">Database Command</label>
              <select
                className="field-input"
                value={formData.dbCommand || 'select'}
                onChange={(e) => handleChange('dbCommand', e.target.value)}
              >
                <option value="select">SELECT</option>
                <option value="insert">INSERT</option>
                <option value="update">UPDATE</option>
                <option value="delete">DELETE</option>
              </select>
            </div>
            
            <div className="field-group">
              <label className="field-label">Table Name</label>
              <input
                className="field-input"
                type="text"
                value={formData.dbTableName || ''}
                onChange={(e) => handleChange('dbTableName', e.target.value)}
                placeholder="e.g. users"
              />
            </div>
            
            <div className="field-group" style={{ marginTop: '16px' }}>
              <label className="field-label" style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>Custom/Raw Query (Optional)</span>
              </label>
              <textarea
                className="field-input"
                value={formData.dbCustomQuery || ''}
                onChange={(e) => handleChange('dbCustomQuery', e.target.value)}
                placeholder="e.g. INSERT INTO {{tableName}} (name) VALUES ('{{excelData.name}}')"
                rows={4}
                style={{ resize: 'vertical', fontFamily: 'monospace', fontSize: '11px' }}
              />
              <div style={{ fontSize: '10px', color: 'var(--text-muted)', marginTop: '4px' }}>
                If provided, this overrides the auto-generated query. You can use <code>{'{{variable}}'}</code> syntax to inject workflow data.
              </div>
            </div>
          </>
        )}

        {/* ── Color picker (generic nodes) ── */}
        {(selectedNode.type === 'generic' || selectedNode.type === 'swimlane') && (
          <>
            <div className="field-divider" />
            <div className="field-group">
              <label className="field-label">{selectedNode.type === 'swimlane' ? 'Theme Color' : 'Accent Color'}</label>
              <div className="color-picker-row">
                {['#22c55e','#3b82f6','#f59e0b','#8b5cf6','#ec4899','#06b6d4','#ef4444','#64748b'].map((c) => (
                  <button
                    key={c}
                    className={`color-swatch ${formData.color === c ? 'active' : ''}`}
                    style={{ background: c }}
                    onClick={() => handleChange('color', c)}
                    aria-label={`Color ${c}`}
                  />
                ))}
              </div>
            </div>
          </>
        )}
      </div>

      <div className="props-footer">
        <button className="btn-delete" onClick={() => onDeleteNode(selectedNode.id)}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M3 6h18" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
          </svg>
          Delete Node
        </button>
      </div>
    </aside>
  );
}

export default memo(PropertiesPanel);
