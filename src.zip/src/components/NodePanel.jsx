import { memo } from 'react';

const nodeTemplates = [
  { type: 'generic',         nodeType: 'start',    label: 'Start',             icon: '▶',  color: '#22c55e' },
  { type: 'formTask',        nodeType: 'formTask', label: 'Form Task',         icon: '📋', color: '#3b82f6', description: 'Generic form task (Data Entry or Review)', taskMode: 'form1', formSource: 'builtin' },
  { type: 'generic',         nodeType: 'process',  label: 'Process',           icon: '⚙️', color: '#f59e0b' },
  { type: 'smsNode',         nodeType: 'sms',      label: 'Send SMS',          icon: '💬', color: '#8b5cf6', phoneNumber: '', smsMessage: 'Your workflow request has been processed.' },
  { type: 'emailNode',       nodeType: 'email',    label: 'Email',             icon: '📧', color: '#ec4899', recipient: 'dummy@gmail.com', attachForm: true, subject: 'Form Submission Details' },
  { type: 'apiCall',         nodeType: 'api',      label: 'API Call',          icon: '🔗', color: '#06b6d4' },
  { type: 'dbCallNode',        nodeType: 'dbCall',   label: 'DB Call',           icon: '🗄️', color: '#10b981' },
  { type: 'aiAgent',         nodeType: 'aiAgent',  label: 'AI Agent',          icon: '🤖', color: '#8b5cf6' },
  { type: 'generic',         nodeType: 'end',      label: 'End',               icon: '⏹', color: '#ef4444' },
  { type: 'antigravity',     nodeType: null,       label: 'Antigravity (SON)', icon: '🌐', color: '#7c3aed', variant: 'son' },
  { type: 'antigravity',     nodeType: null,       label: 'Antigravity (LOG)', icon: '📊', color: '#2dd4bf', variant: 'log' },
  { type: 'modeController',  nodeType: null,       label: 'Mode Controller',   icon: '⚙️', color: '#f97316' },
  { type: 'task',            nodeType: null,       label: 'Task',              icon: '👤', color: '#2563eb' },
  { type: 'swimlane',        nodeType: null,       label: 'Workflow Group',    icon: '🔲', color: '#6366f1' },
  { type: 'screenScraperNode', nodeType: 'scraper',  label: 'Screen Scraper',    icon: '🕸️', color: '#f43f5e' },
  { type: 'uploadCsvNode',     nodeType: 'csv',      label: 'Upload CSV',        icon: '📁', color: '#14b8a6' },
  { type: 'googleSheetsNode',  nodeType: 'sheets',   label: 'Google Sheets',     icon: '📊', color: '#10b981' },
];

function NodePanel() {
  const onDragStart = (event, template) => {
    event.dataTransfer.setData('application/reactflow', JSON.stringify(template));
    event.dataTransfer.effectAllowed = 'move';
  };

  return (
    <aside className="node-panel" id="node-panel">
      <div className="panel-header">
        <h2 className="panel-title">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <rect x="3" y="3" width="7" height="7" rx="1" />
            <rect x="14" y="3" width="7" height="7" rx="1" />
            <rect x="3" y="14" width="7" height="7" rx="1" />
            <rect x="14" y="14" width="7" height="7" rx="1" />
          </svg>
          Node Library
        </h2>
        <p className="panel-subtitle">Drag nodes onto the canvas</p>
      </div>

      <div className="panel-section">
        <h3 className="section-label">Standard Nodes</h3>
        <div className="node-list">
          {nodeTemplates.filter(t => ['generic', 'apiCall', 'formTask', 'emailNode', 'smsNode', 'aiAgent', 'screenScraperNode', 'uploadCsvNode', 'googleSheetsNode', 'dbCallNode'].includes(t.type)).map((tmpl) => (
            <div
              key={tmpl.nodeType}
              className="draggable-node"
              draggable
              onDragStart={(e) => onDragStart(e, tmpl)}
              style={{ '--drag-color': tmpl.color }}
            >
              <span className="drag-icon">{tmpl.icon}</span>
              <span className="drag-label">{tmpl.label}</span>
              <svg className="drag-handle" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="9" cy="5" r="1" /><circle cx="15" cy="5" r="1" />
                <circle cx="9" cy="12" r="1" /><circle cx="15" cy="12" r="1" />
                <circle cx="9" cy="19" r="1" /><circle cx="15" cy="19" r="1" />
              </svg>
            </div>
          ))}
        </div>
      </div>

      <div className="panel-section">
        <h3 className="section-label">Special Nodes</h3>
        <div className="node-list">
          {nodeTemplates.filter(t => !['generic', 'apiCall', 'formTask', 'emailNode', 'smsNode', 'aiAgent', 'screenScraperNode', 'uploadCsvNode', 'googleSheetsNode', 'dbCallNode'].includes(t.type)).map((tmpl, i) => (
            <div
              key={`special-${i}`}
              className="draggable-node special"
              draggable
              onDragStart={(e) => onDragStart(e, tmpl)}
              style={{ '--drag-color': tmpl.color }}
            >
              <span className="drag-icon">{tmpl.icon}</span>
              <span className="drag-label">{tmpl.label}</span>
              <svg className="drag-handle" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="9" cy="5" r="1" /><circle cx="15" cy="5" r="1" />
                <circle cx="9" cy="12" r="1" /><circle cx="15" cy="12" r="1" />
                <circle cx="9" cy="19" r="1" /><circle cx="15" cy="19" r="1" />
              </svg>
            </div>
          ))}
        </div>
      </div>
    </aside>
  );
}

export default memo(NodePanel);
