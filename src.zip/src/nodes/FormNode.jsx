import { memo } from 'react';
import { Handle, Position, useReactFlow } from '@xyflow/react';

function FormNode({ id, data, selected }) {
  const {
    label = 'User Details Form',
    description = '',
    formStatus = 'draft',   // 'draft' | 'filled' | 'submitted'
    requestId = '',
    filledData = null,      // { name, state, phone, motherName, fatherName }
    execStatus,
    execTat,
    appMode = 'editor',
  } = data;

  const { setNodes } = useReactFlow();

  const statusClass = execStatus ? `exec-${execStatus}` : '';

  const statusConfig = {
    draft:     { label: 'Draft',     color: '#64748b', icon: '○' },
    filled:    { label: 'Filled',    color: '#f59e0b', icon: '◐' },
    submitted: { label: 'Submitted', color: '#22c55e', icon: '✓' },
  };
  const st = statusConfig[formStatus] || statusConfig.draft;

  const handleOpenForm = (e) => {
    e.stopPropagation();
    if (appMode === 'editor') return;
    
    // Generate a unique Request ID if not already present
    const reqId = requestId || `REQ-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
    
    // Update the node data in the graph
    setNodes((nds) =>
      nds.map((n) => {
        if (n.id === id) {
          return {
            ...n,
            data: {
              ...n.data,
              requestId: reqId,
            },
          };
        }
        return n;
      })
    );

    // Open standalone form window
    const fillUrl = `${window.location.origin}${window.location.pathname}#/fill-form/${id}/${reqId}`;
    window.open(fillUrl, '_blank', 'width=500,height=600,status=no,menubar=no,resizable=yes');
  };

  return (
    <div
      className={`form-node ${selected ? 'selected' : ''} ${statusClass}`}
    >
      <Handle type="target" position={Position.Left} className="node-handle" />

      <div className="form-node-header">
        <div className="form-node-icon">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
            <polyline points="14 2 14 8 20 8" />
            <line x1="16" y1="13" x2="8" y2="13" />
            <line x1="16" y1="17" x2="8" y2="17" />
          </svg>
        </div>
        <span className="form-node-label">{label}</span>
        <div className="form-status-pill" style={{ '--form-status-color': st.color }}>
          <span>{st.icon}</span>
          <span>{st.label}</span>
        </div>
        {execStatus && (
          <span className={`node-exec-status ${execStatus}`}>
            {execStatus === 'running' && '⟳'}
            {execStatus === 'completed' && '✓'}
            {execStatus === 'pending' && '○'}
          </span>
        )}
      </div>

      <div className="form-node-body">
        {requestId && (
          <div className="form-request-id-badge">
            <span className="request-id-label">Request ID:</span>
            <span className="request-id-value">{requestId}</span>
          </div>
        )}

        {filledData ? (
          <div className="form-filled-summary-preview">
            <div className="preview-row">
              <span className="preview-label">Name:</span>
              <span className="preview-value">{filledData.name}</span>
            </div>
            <div className="preview-row">
              <span className="preview-label">Phone:</span>
              <span className="preview-value">{filledData.phone}</span>
            </div>
            {filledData.email_id && (
              <div className="preview-row">
                <span className="preview-label">Email:</span>
                <span className="preview-value" title={filledData.email_id}>{filledData.email_id}</span>
              </div>
            )}
            <div className="preview-row">
              <span className="preview-label">State:</span>
              <span className="preview-value">{filledData.state}</span>
            </div>
          </div>
        ) : (
          <div className="form-empty-state">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="10" />
              <line x1="12" y1="8" x2="12" y2="12" />
              <line x1="12" y1="16" x2="12.01" y2="16" />
            </svg>
            <span>No form attached yet</span>
          </div>
        )}

        <button 
          className={`form-attach-action-btn ${formStatus === 'filled' ? 'attached' : ''}`}
          onClick={(e) => {
            e.stopPropagation();
            if (appMode === 'editor') return;
            handleOpenForm(e);
          }}
          disabled={appMode === 'editor'}
          style={{
            opacity: appMode === 'editor' ? 0.6 : 1,
            cursor: appMode === 'editor' ? 'default' : 'pointer',
            pointerEvents: appMode === 'editor' ? 'none' : 'auto'
          }}
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48" />
          </svg>
          {formStatus === 'filled' ? 'Edit Attached Form' : 'Attach Form'}
        </button>

        {description && <p className="form-description">{description}</p>}
      </div>

      {execTat && (
        <div className="node-tat-badge">
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <circle cx="12" cy="12" r="10" />
            <polyline points="12 6 12 12 16 14" />
          </svg>
          {execTat}s
        </div>
      )}

      <Handle type="source" position={Position.Right} className="node-handle" />

      {(execStatus === 'completed' || execStatus === 'error') && (
        <button 
          className="node-result-btn"
          onClick={(e) => { e.stopPropagation(); if (data.onViewResult) data.onViewResult(id); }}
          style={{
            position: 'absolute', bottom: -10, right: -10,
            width: 24, height: 24, borderRadius: '50%',
            background: execStatus === 'completed' ? '#22c55e' : '#ef4444',
            color: 'white', border: '2px solid var(--bg-surface, #1e293b)',
            cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 2px 4px rgba(0,0,0,0.2)', zIndex: 10, padding: 0,
            fontSize: '12px', fontWeight: 'bold'
          }}
          title="View Execution Details"
        >
          {execStatus === 'completed' ? '✓' : '✕'}
        </button>
      )}
    </div>
  );
}

export default memo(FormNode);
