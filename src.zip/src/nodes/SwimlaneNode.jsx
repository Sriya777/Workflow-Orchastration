import { memo } from 'react';
import { NodeResizer } from '@xyflow/react';

function SwimlaneNode({ data, selected }) {
  const { label = 'Workflow Group', color = '#3b82f6' } = data;

  return (
    <>
      <NodeResizer 
        color={color} 
        isVisible={selected} 
        minWidth={300} 
        minHeight={200} 
      />
      
      <div 
        className={`swimlane-node ${selected ? 'selected' : ''}`}
        style={{ borderColor: color }}
      >
        <div className="swimlane-header" style={{ background: `${color}20`, color }}>
          {label}
        </div>
      </div>
    </>
  );
}

export default memo(SwimlaneNode);
