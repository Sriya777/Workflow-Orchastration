import { memo } from 'react';
import { Handle, Position } from '@xyflow/react';

const iconMap = {
  start:    { icon: '▶', color: '#22c55e' },
  form:     { icon: '📋', color: '#3b82f6' },
  process:  { icon: '⚙️', color: '#f59e0b' },
  sms:      { icon: '💬', color: '#8b5cf6' },
  email:    { icon: '📧', color: '#ec4899' },
  api:      { icon: '🔗', color: '#06b6d4' },
  database: { icon: '🗄️', color: '#10b981' },
  end:      { icon: '⏹', color: '#ef4444' },
  default:  { icon: '📦', color: '#64748b' },
};

function GenericNode({ id, data, selected }) {
  const { label, description, nodeType, color, execStatus, execTat } = data;
  const meta = iconMap[nodeType] || iconMap.default;
  const accentColor = color || meta.color;
  const isStart = nodeType === 'start';

  const statusClass = execStatus ? `exec-${execStatus}` : '';

  return (
    <div
      className={`generic-node ${selected ? 'selected' : ''} ${isStart ? 'is-start-node' : ''} ${statusClass}`}
      style={{ '--node-accent': accentColor }}
    >
      <Handle type="target" position={Position.Left} className="node-handle" />

      <div className="node-header">
        <span className="node-icon">{meta.icon}</span>
        <span className="node-label">{label || 'Untitled'}</span>
        {execStatus && (
          <span 
            className={`node-exec-status ${execStatus}`}
            onClick={(e) => {
              if (execStatus === 'completed' || execStatus === 'error') {
                e.stopPropagation();
                if (data.onViewResult) data.onViewResult(id);
              }
            }}
            title={(execStatus === 'completed' || execStatus === 'error') ? "View Result" : ""}
          >
            {execStatus === 'running' && '⟳'}
            {execStatus === 'completed' && '✓'}
            {execStatus === 'pending' && '○'}
          </span>
        )}
      </div>

      {description && (
        <div className="node-body">
          <p className="node-description">{description}</p>
        </div>
      )}

      {execTat && (
        <div className="node-tat-badge">
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <circle cx="12" cy="12" r="10" />
            <polyline points="12 6 12 12 16 14" />
          </svg>
          {execTat}s
        </div>
      )}

      <Handle type="source" position={Position.Right} className="node-handle" />
    </div>
  );
}

export default memo(GenericNode);
