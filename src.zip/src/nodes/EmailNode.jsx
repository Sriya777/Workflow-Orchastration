import { memo, useState, useEffect } from 'react';
import { Handle, Position, useReactFlow } from '@xyflow/react';

function EmailNode({ id, data, selected }) {
  const {
    label = 'Email',
    description = '',
    recipient = '',
    subject = '',
    attachForm = false,
    color = '#ec4899',
    execStatus,
    execTat,
    appMode = 'editor',
    isExecuting = false,
    execError,
  } = data;

  const { setNodes } = useReactFlow();
  const [errorMsg, setErrorMsg] = useState('');
  const [isAutoSending, setIsAutoSending] = useState(false);
  const statusClass = execStatus ? `exec-${execStatus}` : '';

  useEffect(() => {
    if (appMode !== 'execution' || !isExecuting || execStatus !== 'running') {
      setIsAutoSending(false);
      return;
    }
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!recipient || !emailRegex.test(recipient)) {
      setIsAutoSending(false);
      return;
    }
    
    setErrorMsg('');
    setIsAutoSending(true);
    const timer = setTimeout(() => {
      window.dispatchEvent(new CustomEvent('email-confirm', { detail: { nodeId: id } }));
    }, 1200);
    
    return () => clearTimeout(timer);
  }, [recipient, appMode, isExecuting, execStatus, id]);

  return (
    <div
      className={`generic-node email-node ${selected ? 'selected' : ''} ${statusClass}`}
      style={{ '--node-accent': color }}
    >
      <Handle type="target" position={Position.Left} className="node-handle" />

      <div className="node-header">
        <span className="node-icon">📧</span>
        <span className="node-label">{label}</span>
        {execStatus && (
          <span className={`node-exec-status ${execStatus}`}>
            {execStatus === 'running' && '⟳'}
            {execStatus === 'completed' && '✓'}
            {execStatus === 'pending' && '○'}
          </span>
        )}
      </div>

      <div className="node-body">
        {appMode === 'execution' && isExecuting ? (
          <div style={{ marginBottom: '8px' }} className="nodrag">
            <label style={{ fontSize: '9px', color: 'var(--text-muted)', textTransform: 'uppercase', display: 'block', marginBottom: '3px', fontWeight: 600 }}>Recipient Gmail</label>
            <input
              type="email"
              value={recipient}
              placeholder="e.g. user@gmail.com"
              disabled={execStatus === 'completed'}
              onChange={(e) => {
                e.stopPropagation();
                setErrorMsg('');
                setNodes(nds => nds.map(n => {
                  if (n.id === id) {
                    return {
                      ...n,
                      data: {
                        ...n.data,
                        recipient: e.target.value
                      }
                    };
                  }
                  return n;
                }));
              }}
              style={{
                width: '100%',
                background: 'var(--bg-secondary)',
                border: '1px solid var(--border)',
                borderRadius: '6px',
                color: 'var(--text-primary)',
                padding: '4px 6px',
                fontSize: '11px',
                fontWeight: 500,
                outline: 'none',
              }}
            />
            {execStatus === 'running' && (
              <div
                className="nodrag"
                style={{
                  marginTop: '8px',
                  width: '100%',
                  borderColor: isAutoSending ? '#34d399' : 'var(--border)',
                  color: isAutoSending ? '#34d399' : 'var(--text-muted)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '6px',
                  fontWeight: 600,
                  fontSize: '11px',
                  background: isAutoSending ? 'rgba(52,211,153,0.08)' : 'none',
                  border: '1px solid',
                  borderRadius: '6px',
                  padding: '6px',
                  textAlign: 'center',
                  animation: isAutoSending ? 'pulse 1.5s infinite' : 'none'
                }}
              >
                {isAutoSending ? (
                  <>
                    <span className="animate-spin" style={{ display: 'inline-block' }}>⟳</span>
                    Auto-sending...
                  </>
                ) : (
                  <>
                    <span>✉</span>
                    Waiting for valid email...
                  </>
                )}
              </div>
            )}
            {errorMsg && (
              <div style={{ color: 'var(--error)', fontSize: '9px', marginTop: '4px', fontWeight: 500 }}>
                ⚠️ {errorMsg}
              </div>
            )}
          </div>
        ) : (
          <div style={{ fontSize: '11px', marginBottom: '4px', color: 'var(--text-secondary)' }}>
            <strong>To:</strong> {recipient}
          </div>
        )}

        {subject && (
          <div style={{ fontSize: '11px', marginBottom: '4px', color: 'var(--text-secondary)' }}>
            <strong>Subject:</strong> {subject}
          </div>
        )}
        {attachForm && (
          <div style={{ fontSize: '11px', color: color, display: 'flex', alignItems: 'center', gap: '4px' }}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48" />
            </svg>
            Includes Form Details
          </div>
        )}
        {description && <p className="node-description" style={{ marginTop: '8px' }}>{description}</p>}

        {execStatus === 'error' && execError && (
          <div 
            style={{ 
              marginTop: '8px', 
              padding: '6px 8px', 
              background: 'rgba(239, 68, 68, 0.1)', 
              border: '1px solid rgba(239, 68, 68, 0.3)', 
              borderRadius: '6px', 
              color: '#f87171', 
              fontSize: '10px', 
              lineHeight: '1.4',
              wordBreak: 'break-word'
            }}
            className="nodrag"
          >
            ❌ {execError}
          </div>
        )}
      </div>

      {execTat && (
        <div className="node-tat-badge">
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <circle cx="12" cy="12" r="10" />
            <polyline points="12 6 12 12 16 14" />
          </svg>
          {execTat}s
        </div>
      )}

      <Handle type="source" position={Position.Right} className="node-handle" />

      {(execStatus === 'completed' || execStatus === 'error') && (
        <button 
          className="node-result-btn"
          onClick={(e) => { e.stopPropagation(); if (data.onViewResult) data.onViewResult(id); }}
          style={{
            position: 'absolute', bottom: -10, right: -10,
            width: 24, height: 24, borderRadius: '50%',
            background: execStatus === 'completed' ? '#22c55e' : '#ef4444',
            color: 'white', border: '2px solid var(--bg-surface, #1e293b)',
            cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 2px 4px rgba(0,0,0,0.2)', zIndex: 10, padding: 0,
            fontSize: '12px', fontWeight: 'bold'
          }}
          title="View Execution Details"
        >
          {execStatus === 'completed' ? '✓' : '✕'}
        </button>
      )}
    </div>
  );
}

export default memo(EmailNode);
