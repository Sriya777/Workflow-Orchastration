import { memo } from 'react';
import { Handle, Position } from '@xyflow/react';

function AntigravityNode({ data, selected }) {
  const {
    label = 'Antigravity Data',
    variant = 'son',
    where = '',
    log = '',
    registers = '',
    modeController = '',
    elapsedStructure = '',
    cbsTarget = '',
    execStatus,
    execTat,
  } = data;

  const isLog = variant === 'log';
  const statusClass = execStatus ? `exec-${execStatus}` : '';

  return (
    <div className={`antigravity-node ${selected ? 'selected' : ''} ${isLog ? 'log-variant' : 'son-variant'} ${statusClass}`}>
      <Handle type="target" position={Position.Left} className="node-handle" />

      <div className="ag-header">
        <div className="ag-icon-wrap">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="12" cy="12" r="10" />
            <path d="M12 2a15 15 0 0 1 4 10 15 15 0 0 1-4 10 15 15 0 0 1-4-10A15 15 0 0 1 12 2z" />
            <path d="M2 12h20" />
          </svg>
        </div>
        <div className="ag-title">
          <span className="ag-name">{label}</span>
          <span className="ag-badge">{isLog ? 'LOG' : 'SON'}</span>
          {execStatus && (
            <span className={`node-exec-status ${execStatus}`}>
              {execStatus === 'running' && '⟳'}
              {execStatus === 'completed' && '✓'}
              {execStatus === 'pending' && '○'}
            </span>
          )}
        </div>
      </div>

      <div className="ag-body">
        {where && (
          <div className="ag-field">
            <span className="ag-field-label">Where</span>
            <span className="ag-field-arrow">→</span>
            <span className="ag-field-value">{where}</span>
          </div>
        )}
        {cbsTarget && (
          <div className="ag-field highlight">
            <span className="ag-field-label">CBS</span>
            <span className="ag-field-arrow">→</span>
            <span className="ag-field-value">{cbsTarget}</span>
          </div>
        )}
        {log && (
          <div className="ag-field">
            <span className="ag-field-label">Log</span>
            <span className="ag-field-value">{log}</span>
          </div>
        )}
        {registers && (
          <div className="ag-field">
            <span className="ag-field-label">Registers</span>
            <span className="ag-field-value">{registers}</span>
          </div>
        )}
        {modeController && (
          <div className="ag-field">
            <span className="ag-field-label">Mode Ctrl</span>
            <span className="ag-field-value">{modeController}</span>
          </div>
        )}
        {elapsedStructure && (
          <div className="ag-field">
            <span className="ag-field-label">Elapsed</span>
            <span className="ag-field-value">{elapsedStructure}</span>
          </div>
        )}
        {!where && !cbsTarget && !log && !registers && !modeController && !elapsedStructure && (
          <div className="ag-empty">Click to configure fields</div>
        )}
      </div>

      {execTat && (
        <div className="node-tat-badge">
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <circle cx="12" cy="12" r="10" />
            <polyline points="12 6 12 12 16 14" />
          </svg>
          {execTat}s
        </div>
      )}

      <Handle type="source" position={Position.Right} className="node-handle" />
    </div>
  );
}

export default memo(AntigravityNode);
