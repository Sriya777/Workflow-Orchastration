import { memo } from 'react';
import { Handle, Position } from '@xyflow/react';

function DBCallNode({ id, data, selected }) {
  const {
    label = 'DB Call',
    description = '',
    execStatus,
    execTat,
  } = data;

  const statusClass = execStatus ? `exec-${execStatus}` : '';

  return (
    <div
      className={`api-call-node ${selected ? 'selected' : ''} ${statusClass}`}
      style={{ '--api-method-color': '#10b981' }} // Use a green/DB theme color
    >
      <Handle type="target" position={Position.Left} className="node-handle" />

      <div className="api-node-header">
        <div className="api-method-badge" style={{ background: '#10b981' }}>DB</div>
        <span className="api-node-label">{label}</span>
        {execStatus && (
          <span 
            className={`node-exec-status ${execStatus}`}
            onClick={(e) => {
              if (execStatus === 'completed' || execStatus === 'error') {
                e.stopPropagation();
                if (data.onViewResult) data.onViewResult(id);
              }
            }}
            title={(execStatus === 'completed' || execStatus === 'error') ? "View Result" : ""}
          >
            {execStatus === 'running' && '⟳'}
            {execStatus === 'completed' && '✓'}
            {execStatus === 'pending' && '○'}
          </span>
        )}
      </div>

      <div className="api-node-body">
        <div className="api-url-row">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
             <ellipse cx="12" cy="5" rx="9" ry="3"></ellipse>
             <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"></path>
             <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"></path>
          </svg>
          <span className="api-url-text">Execute DB Query</span>
        </div>

        {description && <p className="api-description">{description}</p>}
      </div>

      {execTat && (
        <div className="node-tat-badge">
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <circle cx="12" cy="12" r="10" />
            <polyline points="12 6 12 12 16 14" />
          </svg>
          {execTat}s
        </div>
      )}

      <Handle type="source" position={Position.Right} className="node-handle" />

      {(execStatus === 'completed' || execStatus === 'error') && (
        <button 
          className="node-result-btn"
          onClick={(e) => { e.stopPropagation(); if (data.onViewResult) data.onViewResult(id); }}
          style={{
            position: 'absolute', bottom: -10, right: -10,
            width: 24, height: 24, borderRadius: '50%',
            background: execStatus === 'completed' ? '#22c55e' : '#ef4444',
            color: 'white', border: '2px solid var(--bg-surface, #1e293b)',
            cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 2px 4px rgba(0,0,0,0.2)', zIndex: 10, padding: 0,
            fontSize: '12px', fontWeight: 'bold'
          }}
          title="View Execution Details"
        >
          {execStatus === 'completed' ? '✓' : '✕'}
        </button>
      )}
    </div>
  );
}

export default memo(DBCallNode);
