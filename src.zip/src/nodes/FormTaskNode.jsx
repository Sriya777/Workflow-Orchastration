import { memo, useState, useEffect } from 'react';
import { Handle, Position, useReactFlow } from '@xyflow/react';
import { createPortal } from 'react-dom';

function FormTaskNode({ id, data, selected }) {
  const {
    label = 'Form Task',
    taskMode = 'form1',
    formSource = 'builtin',
    customUrl = '',
    useExistingDetails = false,
    formStatus = 'draft',
    requestId = '',
    filledData = null,
    managerDecision = '',
    managerComments = '',
    managerStatus = 'pending',
    execStatus,
    execTat,
    appMode = 'editor',
    isExecuting = false,
  } = data;

  const { getNodes, getEdges, setNodes } = useReactFlow();
  const [predecessorData, setPredecessorData] = useState(null);
  const [predecessorReqId, setPredecessorReqId] = useState('');
  const [decision, setDecision] = useState(managerDecision || '');
  const [comments, setComments] = useState(managerComments || '');
  const [showReviewModal, setShowReviewModal] = useState(false);

  const handleModeChange = (newMode) => {
    setNodes(nds => nds.map(n => {
      if (n.id === id) {
        return {
          ...n,
          data: {
            ...n.data,
            taskMode: newMode,
            formStatus: newMode === 'form1' ? 'draft' : 'pending',
            filledData: null,
            managerStatus: newMode === 'form2' ? 'pending' : undefined,
            managerDecision: '',
            managerComments: ''
          }
        };
      }
      return n;
    }));
  };

  useEffect(() => {
    if (taskMode === 'form2' || useExistingDetails) {
      const nodes = getNodes();
      const edges = getEdges();
      const incoming = edges.filter(e => e.target === id);
      const predecessorForm = incoming
        .map(e => nodes.find(n => n.id === e.source))
        .find(n => n && (n.type === 'formTask' || n.type === 'formNode'));
      if (predecessorForm?.data) {
        setPredecessorData(predecessorForm.data.filledData || null);
        setPredecessorReqId(predecessorForm.data.requestId || '');
      } else {
        setPredecessorData(null);
        setPredecessorReqId('');
      }
    }
  }, [getNodes, getEdges, id, execStatus, taskMode, useExistingDetails]);

  useEffect(() => {
    // We intentionally removed the auto-open behavior here based on user request.
    // Users will manually open the popup using the button.
  }, [execStatus, taskMode]);

  useEffect(() => {
    if (managerDecision) setDecision(managerDecision);
    if (managerComments) setComments(managerComments);
  }, [managerDecision, managerComments]);

  const handleOpenForm1 = (e) => {
    e?.stopPropagation();
    if (appMode === 'editor') return;

    // Write node config to localStorage for the FormFillView popup
    localStorage.setItem(`node_data_${id}`, JSON.stringify({ formSource, customUrl }));

    const reqId = requestId || `REQ-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
    setNodes(nds => nds.map(n => n.id === id ? { ...n, data: { ...n.data, requestId: reqId } } : n));
    const fillUrl = `${window.location.origin}${window.location.pathname}#/fill-form/${id}/${reqId}`;
    window.open(fillUrl, '_blank', 'width=500,height=600,status=no,menubar=no,resizable=yes');
  };

  const handleReviewSubmit = (e) => {
    e?.stopPropagation();
    if (!decision) return;
    window.dispatchEvent(new CustomEvent('manager-submit', {
      detail: { nodeId: id, decision: (decision || '').toLowerCase(), comments }
    }));
    setShowReviewModal(false);
  };

  // ── Derived UI helpers ──
  const isForm1 = taskMode === 'form1';
  const isCustom = formSource === 'custom';
  const hasData = filledData || predecessorData;
  const activeData = filledData || predecessorData;

  const execColors = {
    running:   'border-yellow-400 shadow-[0_0_12px_rgba(250,204,21,0.25)]',
    completed: 'border-green-400  shadow-[0_0_12px_rgba(34,197,94,0.25)]',
    error:     'border-red-400    shadow-[0_0_12px_rgba(239,68,68,0.25)]',
    pending:   isForm1 ? 'border-blue-500/60' : 'border-emerald-500/60',
  };
  const borderClass = execStatus
    ? (execColors[execStatus] || 'border-slate-600')
    : selected
      ? 'border-violet-400 shadow-[0_0_0_2px_rgba(167,139,250,0.3)]'
      : isForm1 ? 'border-blue-500/60' : 'border-emerald-500/60';

  const statusConfig = {
    draft:     { label: 'Draft',     dot: 'bg-slate-400',  text: 'text-slate-400'  },
    filled:    { label: 'Filled',    dot: 'bg-amber-400',  text: 'text-amber-400'  },
    submitted: { label: 'Submitted', dot: 'bg-green-400',  text: 'text-green-400'  },
  };
  const st = statusConfig[formStatus] || statusConfig.draft;

  return (
    <>
      <Handle type="target" position={Position.Left} className="node-handle" />

      {/* ── Main Card (Matching Native Design) ── */}
      <div
        className={`form-node ${selected ? 'selected' : ''} ${execStatus ? `exec-${execStatus}` : ''}`}
        style={{ borderLeftColor: isForm1 ? '#3b82f6' : '#10b981' }}
      >
        {/* Node Header */}
        <div 
          className="form-node-header"
          style={{ 
            background: isForm1 
              ? 'color-mix(in srgb, #3b82f6 6%, var(--bg-surface))' 
              : 'color-mix(in srgb, #10b981 6%, var(--bg-surface))' 
          }}
        >
          <div 
            className="form-node-icon"
            style={{ 
              background: isForm1 
                ? 'color-mix(in srgb, #3b82f6 15%, transparent)' 
                : 'color-mix(in srgb, #10b981 15%, transparent)',
              color: isForm1 ? '#60a5fa' : '#34d399'
            }}
          >
            {isForm1 ? (
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                <polyline points="14 2 14 8 20 8" />
                <line x1="16" y1="13" x2="8" y2="13" />
                <line x1="16" y1="17" x2="8" y2="17" />
              </svg>
            ) : (
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                <circle cx="12" cy="7" r="4" />
              </svg>
            )}
          </div>
          <span className="form-node-label">{label}</span>
          {execStatus && (
            <span className={`node-exec-status ${execStatus}`}>
              {execStatus === 'running' && '⟳'}
              {execStatus === 'completed' && '✓'}
              {execStatus === 'pending' && '○'}
            </span>
          )}
        </div>

        {/* Node Body */}
        <div className="form-node-body">
          {appMode === 'execution' && isExecuting && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '8px', borderBottom: '1px solid var(--border)', paddingBottom: '8px' }} className="nodrag">
              <div>
                <label style={{ fontSize: '9px', color: 'var(--text-muted)', textTransform: 'uppercase', display: 'block', marginBottom: '3px', fontWeight: 600 }}>Form Select</label>
                <select
                  value={taskMode}
                  onChange={(e) => {
                    e.stopPropagation();
                    handleModeChange(e.target.value);
                  }}
                  style={{
                    width: '100%',
                    background: 'var(--bg-secondary)',
                    border: '1px solid var(--border)',
                    borderRadius: '6px',
                    color: 'var(--text-primary)',
                    padding: '4px 6px',
                    fontSize: '11px',
                    fontWeight: 600,
                    outline: 'none',
                    cursor: 'pointer'
                  }}
                >
                  <option value="form1">Form 1</option>
                  <option value="form2">Form 2</option>
                </select>
              </div>

              {taskMode === 'form1' && (
                <div>
                  <label style={{ fontSize: '9px', color: 'var(--text-muted)', textTransform: 'uppercase', display: 'block', marginBottom: '3px', fontWeight: 600 }}>Form Source</label>
                  <select
                    value={formSource}
                    onChange={(e) => {
                      e.stopPropagation();
                      const newSource = e.target.value;
                      setNodes(nds => nds.map(n => {
                        if (n.id === id) {
                          return {
                            ...n,
                            data: {
                              ...n.data,
                              formSource: newSource
                            }
                          };
                        }
                        return n;
                      }));
                    }}
                    style={{
                      width: '100%',
                      background: 'var(--bg-secondary)',
                      border: '1px solid var(--border)',
                      borderRadius: '6px',
                      color: 'var(--text-primary)',
                      padding: '4px 6px',
                      fontSize: '11px',
                      fontWeight: 500,
                      outline: 'none',
                      cursor: 'pointer'
                    }}
                  >
                    <option value="builtin">Built-in Form</option>
                    <option value="pdf">Upload PDF Form</option>
                    <option value="custom">Custom URL</option>
                  </select>

                  {formSource === 'custom' && (
                    <div style={{ marginTop: '6px' }}>
                      <label style={{ fontSize: '9px', color: 'var(--text-muted)', textTransform: 'uppercase', display: 'block', marginBottom: '3px', fontWeight: 600 }}>Custom URL</label>
                      <input
                        type="text"
                        value={customUrl}
                        onChange={(e) => {
                          e.stopPropagation();
                          const val = e.target.value;
                          setNodes(nds => nds.map(n => {
                            if (n.id === id) {
                              return {
                                ...n,
                                data: {
                                  ...n.data,
                                  customUrl: val
                                }
                              };
                            }
                            return n;
                          }));
                        }}
                        placeholder="https://example.com/form"
                        style={{
                          width: '100%',
                          background: 'var(--bg-secondary)',
                          border: '1px solid var(--border)',
                          borderRadius: '6px',
                          color: 'var(--text-primary)',
                          padding: '4px 6px',
                          fontSize: '11px',
                          outline: 'none',
                          boxSizing: 'border-box'
                        }}
                      />
                    </div>
                  )}
                </div>
              )}

              {taskMode === 'form2' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', fontSize: '11px', color: 'var(--text-primary)', fontWeight: 500 }}>
                    <input
                      type="checkbox"
                      checked={useExistingDetails}
                      onChange={(e) => {
                        e.stopPropagation();
                        const isChecked = e.target.checked;
                        setNodes(nds => nds.map(n => {
                          if (n.id === id) {
                            return {
                              ...n,
                              data: {
                                ...n.data,
                                useExistingDetails: isChecked
                              }
                            };
                          }
                          return n;
                        }));
                        if (!isChecked) {
                          setPredecessorData(null);
                          setPredecessorReqId('');
                        }
                      }}
                      style={{ cursor: 'pointer' }}
                    />
                    Prepopulate from previous (JSON)
                  </label>

                  {useExistingDetails && (
                    <div style={{ marginTop: '4px' }}>
                      <label style={{ fontSize: '9px', color: 'var(--text-muted)', textTransform: 'uppercase', display: 'block', marginBottom: '3px', fontWeight: 600 }}>Previous Node Data</label>
                      <select
                        value={predecessorReqId || ''}
                        onChange={(e) => {
                          e.stopPropagation();
                          const targetReqId = e.target.value;
                          if (!targetReqId) {
                            setPredecessorData(null);
                            setPredecessorReqId('');
                            return;
                          }
                          const allNds = getNodes();
                          const selectedSource = allNds.find(n => n.data?.requestId === targetReqId);
                          if (selectedSource?.data) {
                            setPredecessorData(selectedSource.data.filledData || null);
                            setPredecessorReqId(selectedSource.data.requestId || '');
                          }
                        }}
                        style={{
                          width: '100%',
                          background: 'var(--bg-secondary)',
                          border: '1px solid var(--border)',
                          borderRadius: '6px',
                          color: 'var(--text-primary)',
                          padding: '4px 6px',
                          fontSize: '11px',
                          fontWeight: 500,
                          outline: 'none',
                          cursor: 'pointer',
                          marginBottom: '6px'
                        }}
                      >
                        <option value="">-- Select Source --</option>
                        {getNodes()
                          .filter(n => (n.type === 'formNode' || (n.type === 'formTask' && n.data.taskMode === 'form1')) && n.data.filledData)
                          .map(fNode => (
                            <option key={fNode.id} value={fNode.data.requestId}>
                              👤 {fNode.data.label || 'Form Node'} ({fNode.data.filledData?.name || 'Filled'})
                            </option>
                          ))
                        }
                      </select>
                      
                      {predecessorData && (
                        <div className="json-preview nodrag" style={{
                          background: '#1e293b',
                          border: '1px solid #334155',
                          borderRadius: '6px',
                          padding: '6px 8px',
                          marginTop: '4px',
                          fontSize: '10px',
                          color: '#a5b4fc',
                          fontFamily: 'monospace',
                          whiteSpace: 'pre-wrap',
                          maxHeight: '120px',
                          overflowY: 'auto'
                        }}>
                          {JSON.stringify(predecessorData, null, 2)}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
          
          {/* ── FORM 1 BODY (Data Entry) ── */}
          {isForm1 && (
            <>
              {requestId && (
                <div className="form-request-id-badge" style={{ display: 'flex', justifyContent: 'space-between', fontSize: '10px', background: 'var(--bg-secondary)', padding: '4px 8px', borderRadius: '4px', marginBottom: '6px' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Req ID:</span>
                  <span style={{ color: 'var(--text-primary)', fontFamily: 'monospace' }}>{requestId}</span>
                </div>
              )}

              {hasData ? (
                <div className="form-filled-summary-preview" style={{ background: 'var(--bg-secondary)', padding: '6px 8px', borderRadius: '6px', fontSize: '11px', display: 'flex', flexDirection: 'column', gap: '3px', marginBottom: '6px', border: '1px solid var(--border)' }}>
                  {Object.entries(activeData || {}).map(([key, value]) => {
                    if (key === 'attachments' || key === 'formSource') return null;
                    let label = key.charAt(0).toUpperCase() + key.slice(1);
                    if (key === 'motherName') label = 'Mother Name';
                    if (key === 'fatherName') label = "Father's Name";
                    if (key === 'name') label = 'Full Name';
                    if (key === 'email_id') label = 'Email ID';
                    return (
                      <div key={key} style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span style={{ color: 'var(--text-muted)' }}>{label}:</span>
                        <span style={{ color: 'var(--text-primary)', fontWeight: 500 }}>{value?.toString() || '—'}</span>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="form-empty-state" style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--text-muted)', fontSize: '11px', padding: '4px 0 8px' }}>
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <circle cx="12" cy="12" r="10" />
                    <line x1="12" y1="8" x2="12" y2="12" />
                    <line x1="12" y1="16" x2="12.01" y2="16" />
                  </svg>
                  <span>No details attached</span>
                </div>
              )}

              <button
                className={`form-attach-action-btn nodrag ${hasData ? 'attached' : ''}`}
                onClick={(e) => {
                  e.stopPropagation();
                  handleOpenForm1(e);
                }}
                disabled={appMode === 'editor'}
                style={{
                  background: execStatus === 'running' ? 'var(--warning)' : '',
                  color: execStatus === 'running' ? 'var(--bg-primary)' : '',
                  borderColor: execStatus === 'running' ? 'var(--warning)' : '',
                  opacity: appMode === 'editor' ? 0.6 : 1,
                  cursor: appMode === 'editor' ? 'default' : 'pointer',
                  pointerEvents: appMode === 'editor' ? 'none' : 'auto'
                }}
              >
                {isCustom ? (
                  <>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                      <polyline points="15 3 21 3 21 9" /><line x1="10" y1="14" x2="21" y2="3" />
                    </svg>
                    {execStatus === 'running' ? 'Click to Complete' : 'Open External Form'}
                  </>
                ) : (
                  <>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                    </svg>
                    {execStatus === 'running' 
                      ? 'Click to Fill Form' 
                      : (hasData ? 'Edit Details' : 'Attach Details')}
                  </>
                )}
              </button>

              {isCustom && execStatus === 'running' && (
                <button
                  className="form-attach-action-btn nodrag attached"
                  style={{ 
                    marginTop: '6px', 
                    borderColor: '#10b981', 
                    color: '#10b981',
                    opacity: appMode === 'editor' ? 0.6 : 1,
                    cursor: appMode === 'editor' ? 'default' : 'pointer',
                    pointerEvents: appMode === 'editor' ? 'none' : 'auto'
                  }}
                  disabled={appMode === 'editor'}
                  onClick={(e) => {
                    e.stopPropagation();
                    if (appMode === 'editor') return;
                    window.dispatchEvent(new CustomEvent('custom-form-complete', { detail: { nodeId: id } }));
                  }}
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <polyline points="20 6 9 17 4 12" />
                  </svg>
                  Mark as Completed
                </button>
              )}
            </>
          )}

          {/* ── FORM 2 BODY (Review / Approve) ── */}
          {!isForm1 && (
            <>
              {managerStatus === 'submitted' ? (
                <div
                  className="form-filled-summary-preview nodrag"
                  style={{
                    padding: '8px 10px',
                    textAlign: 'center',
                    border: '1px solid ' + ((managerDecision || '').toLowerCase() === 'approved' ? 'rgba(34,197,94,0.3)' : 'rgba(239,68,68,0.3)'),
                    background: (managerDecision || '').toLowerCase() === 'approved' ? 'rgba(34,197,94,0.06)' : 'rgba(239,68,68,0.06)',
                    borderRadius: '6px'
                  }}
                >
                  <div className={`text-xs font-bold uppercase ${(managerDecision || '').toLowerCase() === 'approved' ? 'text-green-400' : 'text-red-400'}`} style={{ marginBottom: '4px' }}>
                    {managerDecision}
                  </div>
                  <button 
                    onClick={(e) => { 
                      e.stopPropagation(); 
                      if (appMode === 'editor') return;
                      setShowReviewModal(true); 
                    }}
                    disabled={appMode === 'editor'}
                    className="text-[10px] text-slate-400 hover:text-white underline cursor-pointer nodrag"
                    style={{ 
                      background: 'none', 
                      border: 'none', 
                      padding: 0,
                      opacity: appMode === 'editor' ? 0.6 : 1,
                      cursor: appMode === 'editor' ? 'default' : 'pointer',
                      pointerEvents: appMode === 'editor' ? 'none' : 'auto'
                    }}
                  >
                    View details
                  </button>
                </div>
              ) : (
                <button
                  className="form-attach-action-btn nodrag"
                  style={{
                    borderColor: '#10b981',
                    color: execStatus === 'running' ? 'var(--bg-primary)' : '#34d399',
                    background: execStatus === 'running' ? 'var(--warning)' : '',
                    opacity: appMode === 'editor' ? 0.6 : 1,
                    cursor: appMode === 'editor' ? 'default' : 'pointer',
                    pointerEvents: appMode === 'editor' ? 'none' : 'auto',
                    marginTop: '4px'
                  }}
                  disabled={appMode === 'editor'}
                  onClick={(e) => { 
                    e.stopPropagation(); 
                    if (appMode === 'editor') return;
                    setShowReviewModal(true); 
                  }}
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                    <circle cx="12" cy="12" r="3" />
                  </svg>
                  {execStatus === 'running' ? 'Review & Approve' : 'Open Review'}
                </button>
              )}
            </>
          )}
        </div>

        {/* TAT Badge */}
        {execTat && (
          <div className="node-tat-badge">
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <circle cx="12" cy="12" r="10" />
              <polyline points="12 6 12 12 16 14" />
            </svg>
            {execTat}s
          </div>
        )}

        {(execStatus === 'completed' || execStatus === 'error') && (
          <button 
            className="node-result-btn nodrag"
            onClick={(e) => { e.stopPropagation(); if (data.onViewResult) data.onViewResult(id); }}
            style={{
              position: 'absolute', bottom: -10, right: -10,
              width: 24, height: 24, borderRadius: '50%',
              background: execStatus === 'completed' ? '#22c55e' : '#ef4444',
              color: 'white', border: '2px solid var(--bg-surface, #1e293b)',
              cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: '0 2px 4px rgba(0,0,0,0.2)', zIndex: 10, padding: 0,
              fontSize: '12px', fontWeight: 'bold'
            }}
            title="View Execution Details"
          >
            {execStatus === 'completed' ? '✓' : '✕'}
          </button>
        )}
      </div>

      <Handle type="source" position={Position.Right} className="node-handle" />

      {/* ── Form 2 Review Modal ── */}
      {showReviewModal && !isForm1 && createPortal(
        <div className="modal-overlay" style={{ zIndex: 99999 }}>
          <div className="modal-content" style={{ width: '420px', maxWidth: '90vw', border: '1px solid #10b981' }} onClick={(e) => e.stopPropagation()}>
            {/* Modal Header */}
            <div className="modal-header" style={{ borderBottom: '1px solid var(--border)', background: 'color-mix(in srgb, #10b981 6%, var(--bg-surface))' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span style={{ fontSize: '16px' }}>👤</span>
                <div>
                  <h3 style={{ fontSize: '14px', fontWeight: 600, color: 'var(--text-primary)', margin: 0 }}>Manager Review</h3>
                  {predecessorReqId && (
                    <span style={{ fontSize: '9px', color: '#10b981', fontFamily: 'monospace' }}>REQ: {predecessorReqId}</span>
                  )}
                </div>
              </div>
              <button
                className="btn-close"
                onClick={() => setShowReviewModal(false)}
                style={{ background: 'none', border: 'none', cursor: 'pointer' }}
                aria-label="Close modal"
              >✕</button>
            </div>

            {/* Modal Body */}
            <div className="modal-body" style={{ padding: '16px 20px', display: 'flex', flexDirection: 'column', gap: '14px', overflowY: 'auto' }}>
              
              {/* Submitted Details */}
              <div className="field-group" style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <label className="field-label" style={{ fontSize: '10px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px', fontWeight: 600 }}>Submitted Details</label>
                <div style={{ background: 'var(--bg-secondary)', border: '1px solid var(--border)', borderRadius: '8px', padding: '10px 14px', fontSize: '12px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {Object.entries(predecessorData || {}).map(([key, value]) => {
                    if (key === 'attachments' || key === 'formSource') return null;
                    let label = key.charAt(0).toUpperCase() + key.slice(1);
                    if (key === 'motherName') label = 'Mother Name';
                    if (key === 'fatherName') label = "Father's Name";
                    if (key === 'name') label = 'Full Name';
                    return (
                      <div key={key} style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span style={{ color: 'var(--text-muted)' }}>{label}:</span>
                        <span style={{ color: 'var(--text-primary)', fontWeight: 500 }}>{value?.toString() || '—'}</span>
                      </div>
                    );
                  })}
                  {predecessorData?.attachments && predecessorData.attachments.map((att, idx) => (
                    <div key={idx} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '6px', padding: '6px 10px', background: 'var(--bg-card)', border: '1px dashed #10b981', borderRadius: '6px' }}>
                      <span style={{ color: 'var(--text-muted)', fontSize: '11px' }}>📄 Attached PDF:</span>
                      <a href={att.data} download={att.name} style={{ color: '#10b981', textDecoration: 'underline', fontSize: '11px', fontWeight: 600 }} className="nodrag">
                        Download ({att.name})
                      </a>
                    </div>
                  ))}
                </div>
              </div>

              {/* Decision Actions (Approve, Reject, Cancel) */}
              <div className="field-group" style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <label className="field-label" style={{ fontSize: '10px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px', fontWeight: 600 }}>Decision</label>
                <div style={{ display: 'flex', gap: '10px', marginTop: '4px' }}>
                  <button
                    onClick={(e) => {
                      e?.stopPropagation();
                      window.dispatchEvent(new CustomEvent('manager-submit', {
                        detail: { nodeId: id, decision: 'approved', comments }
                      }));
                      setShowReviewModal(false);
                    }}
                    className="nodrag"
                    style={{
                      flex: 1,
                      padding: '10px',
                      borderRadius: '8px',
                      fontWeight: 600,
                      fontSize: '13px',
                      border: '1px solid rgba(34, 197, 94, 0.4)',
                      background: 'rgba(34, 197, 94, 0.15)',
                      color: '#4ade80',
                      cursor: 'pointer',
                      transition: 'all 0.15s'
                    }}
                  >
                    ✓ Approve
                  </button>
                  <button
                    onClick={(e) => {
                      e?.stopPropagation();
                      window.dispatchEvent(new CustomEvent('manager-submit', {
                        detail: { nodeId: id, decision: 'rejected', comments }
                      }));
                      setShowReviewModal(false);
                    }}
                    className="nodrag"
                    style={{
                      flex: 1,
                      padding: '10px',
                      borderRadius: '8px',
                      fontWeight: 600,
                      fontSize: '13px',
                      border: '1px solid rgba(239, 68, 68, 0.4)',
                      background: 'rgba(239, 68, 68, 0.15)',
                      color: '#fca5a5',
                      cursor: 'pointer',
                      transition: 'all 0.15s'
                    }}
                  >
                    ✕ Reject
                  </button>
                  <button
                    onClick={(e) => {
                      e?.stopPropagation();
                      setShowReviewModal(false);
                    }}
                    className="nodrag"
                    style={{
                      flex: 1,
                      padding: '10px',
                      borderRadius: '8px',
                      fontWeight: 600,
                      fontSize: '13px',
                      border: '1px solid var(--border)',
                      background: 'var(--bg-card)',
                      color: 'var(--text-secondary)',
                      cursor: 'pointer',
                      transition: 'all 0.15s'
                    }}
                  >
                    Cancel
                  </button>
                </div>
              </div>

              {/* Comments Section */}
              <div className="field-group" style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
                <label className="field-label" style={{ fontSize: '10px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px', fontWeight: 600 }}>Comments (Optional)</label>
                <textarea
                  className="field-textarea nodrag"
                  value={comments}
                  onChange={(e) => setComments(e.target.value)}
                  placeholder="Reason or notes..."
                  style={{ width: '100%', minHeight: '60px', marginTop: '4px' }}
                />
              </div>

            </div>
          </div>
        </div>,
        document.body
      )}
    </>
  );
}

export default memo(FormTaskNode);
