import { memo } from 'react';
import { Handle, Position } from '@xyflow/react';

function ScreenScraperNode({ id, data, selected }) {
  const {
    label = 'Screen Scraper',
    websiteUrl = '',
    execStatus,
    execTat,
  } = data;

  const statusClass = execStatus ? `exec-${execStatus}` : '';

  return (
    <div className={`generic-node ${selected ? 'selected' : ''} ${statusClass}`}>
      <Handle type="target" position={Position.Left} className="node-handle" />

      <div className="node-header">
        <span className="node-icon">🕸️</span>
        <span className="node-label">{label}</span>
        {execStatus && (
          <span className={`node-exec-status ${execStatus}`}>
            {execStatus === 'running' && '⟳'}
            {execStatus === 'completed' && '✓'}
            {execStatus === 'pending' && '○'}
          </span>
        )}
      </div>

      <div className="node-body">
        {websiteUrl ? (
          <div style={{ fontSize: '10px', color: 'var(--text-secondary)', wordBreak: 'break-all' }}>
            {websiteUrl}
          </div>
        ) : (
          <div style={{ fontSize: '10px', color: 'var(--text-muted)', fontStyle: 'italic' }}>
            No URL configured
          </div>
        )}
      </div>

      {execTat && (
        <div className="node-tat-badge">
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <circle cx="12" cy="12" r="10" />
            <polyline points="12 6 12 12 16 14" />
          </svg>
          {execTat}s
        </div>
      )}

      <Handle type="source" position={Position.Right} className="node-handle" />

      {(execStatus === 'completed' || execStatus === 'error') && (
        <button 
          className="node-result-btn"
          onClick={(e) => { e.stopPropagation(); if (data.onViewResult) data.onViewResult(id); }}
          style={{
            position: 'absolute', bottom: -10, right: -10,
            width: 24, height: 24, borderRadius: '50%',
            background: execStatus === 'completed' ? '#22c55e' : '#ef4444',
            color: 'white', border: '2px solid var(--bg-surface, #1e293b)',
            cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 2px 4px rgba(0,0,0,0.2)', zIndex: 10, padding: 0,
            fontSize: '12px', fontWeight: 'bold'
          }}
          title="View Execution Details"
        >
          {execStatus === 'completed' ? '✓' : '✕'}
        </button>
      )}
    </div>
  );
}

export default memo(ScreenScraperNode);
