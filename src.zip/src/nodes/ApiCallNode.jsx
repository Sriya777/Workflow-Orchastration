import { memo } from 'react';
import { Handle, Position } from '@xyflow/react';

const METHOD_COLORS = {
  GET:    '#22c55e',
  POST:   '#3b82f6',
  PUT:    '#f59e0b',
  PATCH:  '#8b5cf6',
  DELETE: '#ef4444',
};

function ApiCallNode({ data, selected }) {
  const {
    label = 'API Call',
    description = '',
    apiUrl = '',
    apiMethod = 'GET',
    apiHeaders = '',
    apiBody = '',
    apiStatus = null,       // null | 'idle' | 'loading' | 'success' | 'error'
    apiResponseCode = null,
    apiResponsePreview = '',
    execStatus,
    execTat,
  } = data;

  const methodColor = METHOD_COLORS[apiMethod] || '#06b6d4';
  const statusClass = execStatus ? `exec-${execStatus}` : '';

  // Status badge in top-right
  const renderStatusBadge = () => {
    if (!apiStatus || apiStatus === 'idle') return null;

    const config = {
      loading: { icon: '⏳', bg: '#f59e0b', color: '#fff', shadow: '0 0 12px rgba(245,158,11,0.5)' },
      success: { icon: '✓',  bg: '#22c55e', color: '#fff', shadow: '0 0 12px rgba(34,197,94,0.5)' },
      error:   { icon: '✕',  bg: '#ef4444', color: '#fff', shadow: '0 0 12px rgba(239,68,68,0.5)' },
    };
    const c = config[apiStatus];
    if (!c) return null;

    return (
      <div
        className={`api-status-badge api-status-${apiStatus}`}
        title={
          apiStatus === 'loading' ? 'Request in progress…' :
          apiStatus === 'success' ? `Success (${apiResponseCode || 200})` :
          `Failed (${apiResponseCode || 'Error'})`
        }
      >
        <span>{c.icon}</span>
      </div>
    );
  };

  return (
    <div
      className={`api-call-node ${selected ? 'selected' : ''} ${statusClass}`}
      style={{ '--api-method-color': methodColor }}
    >
      {renderStatusBadge()}

      <Handle type="target" position={Position.Left} className="node-handle" />

      <div className="api-node-header">
        <div className="api-method-badge">{apiMethod}</div>
        <span className="api-node-label">{label}</span>
        {execStatus && (
          <span className={`node-exec-status ${execStatus}`}>
            {execStatus === 'running' && '⟳'}
            {execStatus === 'completed' && '✓'}
            {execStatus === 'pending' && '○'}
          </span>
        )}
      </div>

      <div className="api-node-body">
        {apiUrl ? (
          <div className="api-url-row">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
              <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
            </svg>
            <span className="api-url-text">{apiUrl.length > 35 ? apiUrl.slice(0, 35) + '…' : apiUrl}</span>
          </div>
        ) : (
          <div className="api-empty-url">No URL configured</div>
        )}

        {description && <p className="api-description">{description}</p>}

        {apiStatus === 'success' && apiResponsePreview && (
          <div className="api-response-preview success">
            <span className="api-response-label">Response</span>
            <span className="api-response-text">
              {apiResponsePreview.length > 60 ? apiResponsePreview.slice(0, 60) + '…' : apiResponsePreview}
            </span>
          </div>
        )}
        {apiStatus === 'error' && apiResponsePreview && (
          <div className="api-response-preview error">
            <span className="api-response-label">Error</span>
            <span className="api-response-text">
              {apiResponsePreview.length > 60 ? apiResponsePreview.slice(0, 60) + '…' : apiResponsePreview}
            </span>
          </div>
        )}
      </div>

      {execTat && (
        <div className="node-tat-badge">
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <circle cx="12" cy="12" r="10" />
            <polyline points="12 6 12 12 16 14" />
          </svg>
          {execTat}s
        </div>
      )}

      <Handle type="source" position={Position.Right} className="node-handle" />

      {(execStatus === 'completed' || execStatus === 'error') && (
        <button 
          className="node-result-btn"
          onClick={(e) => { e.stopPropagation(); if (data.onViewResult) data.onViewResult(id); }}
          style={{
            position: 'absolute', bottom: -10, right: -10,
            width: 24, height: 24, borderRadius: '50%',
            background: execStatus === 'completed' ? '#22c55e' : '#ef4444',
            color: 'white', border: '2px solid var(--bg-surface, #1e293b)',
            cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 2px 4px rgba(0,0,0,0.2)', zIndex: 10, padding: 0,
            fontSize: '12px', fontWeight: 'bold'
          }}
          title="View Execution Details"
        >
          {execStatus === 'completed' ? '✓' : '✕'}
        </button>
      )}
    </div>
  );
}

export default memo(ApiCallNode);
