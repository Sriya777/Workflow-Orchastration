import GenericNode from './GenericNode';
import AntigravityNode from './AntigravityNode';
import ModeControllerNode from './ModeControllerNode';
import TaskNode from './TaskNode';
import SwimlaneNode from './SwimlaneNode';
import ApiCallNode from './ApiCallNode';
import FormNode from './FormNode';
import EmailNode from './EmailNode';
import SmsNode from './SmsNode';
import ManagerNode from './ManagerNode';
import AIAgentNode from './AIAgentNode';

import FormTaskNode from './FormTaskNode';
import ScreenScraperNode from './ScreenScraperNode';
import UploadCsvNode from './UploadCsvNode';
import GoogleSheetsNode from './GoogleSheetsNode';
import DBCallNode from './DBCallNode';

export const nodeTypes = {
  generic: GenericNode,
  antigravity: AntigravityNode,
  modeController: ModeControllerNode,
  task: TaskNode,
  swimlane: SwimlaneNode,
  apiCall: ApiCallNode,
  formNode: FormNode,
  emailNode: EmailNode,
  smsNode: SmsNode,
  managerNode: ManagerNode,
  formTask: FormTaskNode,
  aiAgent: AIAgentNode,
  screenScraperNode: ScreenScraperNode,
  uploadCsvNode: UploadCsvNode,
  googleSheetsNode: GoogleSheetsNode,
  dbCallNode: DBCallNode,
};

