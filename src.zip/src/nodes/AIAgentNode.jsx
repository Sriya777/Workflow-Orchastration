import { memo } from 'react';
import { Handle, Position } from '@xyflow/react';

function AIAgentNode({ id, data, selected }) {
  const {
    label = 'AI Agent',
    description = '',
    promptTemplate = '',
    nodeOutput = '',
    execStatus,
    execTat,
    execError,
  } = data;

  const statusClass = execStatus ? `exec-${execStatus}` : '';
  const hasOutput = !!nodeOutput;

  return (
    <div
      className={`generic-node ai-agent-node ${selected ? 'selected' : ''} ${statusClass}`}
      style={{ '--node-accent': '#8b5cf6', minWidth: 200, maxWidth: 280 }}
    >
      <Handle type="target" position={Position.Left} className="node-handle" />

      {/* Header */}
      <div className="node-header" style={{ background: 'color-mix(in srgb, #8b5cf6 8%, var(--bg-surface))', borderBottom: '1px solid color-mix(in srgb, #8b5cf6 30%, var(--border))' }}>
        <span className="node-icon">🤖</span>
        <span className="node-label">{label}</span>
        {execStatus && (
          <span className={`node-exec-status ${execStatus}`}>
            {execStatus === 'running' && '⟳'}
            {execStatus === 'completed' && '✓'}
            {execStatus === 'pending' && '○'}
            {execStatus === 'error' && '✕'}
          </span>
        )}
      </div>

      {/* Body */}
      <div className="node-body" style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        {/* Model badge */}
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 4, alignSelf: 'flex-start',
          padding: '2px 8px', borderRadius: 10, fontSize: 9, fontWeight: 700,
          background: 'color-mix(in srgb, #8b5cf6 15%, transparent)',
          color: '#c4b5fd', border: '1px solid color-mix(in srgb, #8b5cf6 25%, transparent)',
          letterSpacing: '0.4px', textTransform: 'uppercase'
        }}>
          ✦ AI Agent
        </div>

        {/* Prompt preview */}
        {promptTemplate ? (
          <div style={{
            fontSize: 10, color: 'var(--text-secondary)', background: 'var(--bg-card)',
            border: '1px solid var(--border)', borderRadius: 4,
            padding: '4px 6px', lineHeight: 1.4,
            display: '-webkit-box', WebkitLineClamp: 3,
            WebkitBoxOrient: 'vertical', overflow: 'hidden'
          }}>
            {promptTemplate.slice(0, 120)}{promptTemplate.length > 120 ? '…' : ''}
          </div>
        ) : (
          <div style={{ fontSize: 10, color: 'var(--text-muted)', fontStyle: 'italic' }}>
            No prompt configured
          </div>
        )}

        {/* Output preview */}
        {hasOutput && execStatus === 'completed' && (
          <div style={{
            padding: '5px 7px', borderRadius: 4,
            background: 'color-mix(in srgb, #22c55e 8%, var(--bg-card))',
            border: '1px solid color-mix(in srgb, #22c55e 25%, transparent)',
            fontSize: 10, color: '#4ade80'
          }}>
            <div style={{ fontWeight: 700, marginBottom: 2, fontSize: 9, textTransform: 'uppercase', letterSpacing: '0.3px' }}>Output</div>
            <div style={{ color: 'var(--text-secondary)', lineHeight: 1.4, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
              {nodeOutput.slice(0, 100)}{nodeOutput.length > 100 ? '…' : ''}
            </div>
          </div>
        )}

        {/* Running state */}
        {execStatus === 'running' && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 10, color: '#a78bfa' }}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ animation: 'spinStatus 1s linear infinite' }}>
              <path d="M21 12a9 9 0 1 1-6.219-8.56" />
            </svg>
            Generating with AI…
          </div>
        )}

        {/* Error */}
        {execStatus === 'error' && execError && (
          <div style={{ padding: '5px 7px', borderRadius: 4, background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)', color: '#f87171', fontSize: 10 }}>
            ❌ {execError}
          </div>
        )}

        {description && <p className="node-description">{description}</p>}
      </div>

      {execTat && (
        <div className="node-tat-badge">
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" />
          </svg>
          {execTat}s
        </div>
      )}

      <Handle type="source" position={Position.Right} className="node-handle" />

      {(execStatus === 'completed' || execStatus === 'error') && (
        <button 
          className="node-result-btn"
          onClick={(e) => { e.stopPropagation(); if (data.onViewResult) data.onViewResult(id); }}
          style={{
            position: 'absolute', bottom: -10, right: -10,
            width: 24, height: 24, borderRadius: '50%',
            background: execStatus === 'completed' ? '#22c55e' : '#ef4444',
            color: 'white', border: '2px solid var(--bg-surface, #1e293b)',
            cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 2px 4px rgba(0,0,0,0.2)', zIndex: 10, padding: 0,
            fontSize: '12px', fontWeight: 'bold'
          }}
          title="View Execution Details"
        >
          {execStatus === 'completed' ? '✓' : '✕'}
        </button>
      )}
    </div>
  );
}

export default memo(AIAgentNode);
