import { memo } from 'react';
import { Handle, Position } from '@xyflow/react';

function TaskNode({ data, selected }) {
  const { label = 'Task', role = '', link = '', document = '', description = '', execStatus, execTat, execError, appMode = 'editor' } = data;
  const isStart = label.toLowerCase() === 'start';
  const statusClass = execStatus ? `exec-${execStatus}` : '';

  return (
    <div className={`task-node ${selected ? 'selected' : ''} ${isStart ? 'is-start-node' : ''} ${statusClass}`}>
      <Handle type="target" position={Position.Left} className="node-handle" />

      <div className="task-header">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" />
          <rect x="8" y="2" width="8" height="4" rx="1" ry="1" />
          <path d="M9 14h6" /><path d="M9 18h6" /><path d="M9 10h.01" />
        </svg>
        <span className="task-label">{label}</span>
        {execStatus && (
          <span className={`node-exec-status ${execStatus}`} title={execStatus === 'error' ? execError : undefined}>
            {execStatus === 'running' && '⟳'}
            {execStatus === 'completed' && '✓'}
            {execStatus === 'pending' && '○'}
            {execStatus === 'error' && '✕'}
          </span>
        )}
      </div>

      <div className="task-body">
        {role && (
          <div className="task-field">
            <span className="task-field-label">Role:</span>
            <span className="task-field-value">{role}</span>
          </div>
        )}

        {document && (
          <div className="task-field">
            <span className="task-field-label">Doc:</span>
            {typeof document === 'string' ? (
              <span className="task-field-value doc-value">📄 {document}</span>
            ) : (
              <a 
                href={appMode === 'editor' ? undefined : document.data} 
                download={document.name} 
                className="task-field-value doc-value" 
                style={{ 
                  textDecoration: 'none',
                  opacity: appMode === 'editor' ? 0.6 : 1,
                  cursor: appMode === 'editor' ? 'default' : 'pointer',
                  pointerEvents: appMode === 'editor' ? 'none' : 'auto'
                }}
              >
                📄 {document.name}
              </a>
            )}
          </div>
        )}

        {link && (
          <div className="task-field">
            <a 
              href={appMode === 'editor' ? undefined : link} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="task-link"
              style={{
                opacity: appMode === 'editor' ? 0.6 : 1,
                cursor: appMode === 'editor' ? 'default' : 'pointer',
                pointerEvents: appMode === 'editor' ? 'none' : 'auto'
              }}
            >
              🔗 Open Link
            </a>
          </div>
        )}

        {description && <p className="task-description">{description}</p>}

        {!role && !link && !document && !description && (
          <div className="task-empty"></div>
        )}
      </div>

      {execTat && (
        <div className="node-tat-badge">
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <circle cx="12" cy="12" r="10" />
            <polyline points="12 6 12 12 16 14" />
          </svg>
          {execTat}s
        </div>
      )}

      <Handle type="source" position={Position.Right} className="node-handle" />

      {(execStatus === 'completed' || execStatus === 'error') && (
        <button 
          className="node-result-btn"
          onClick={(e) => { e.stopPropagation(); if (data.onViewResult) data.onViewResult(data.id || id); }}
          style={{
            position: 'absolute', bottom: -10, right: -10,
            width: 24, height: 24, borderRadius: '50%',
            background: execStatus === 'completed' ? '#22c55e' : '#ef4444',
            color: 'white', border: '2px solid var(--bg-surface, #1e293b)',
            cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 2px 4px rgba(0,0,0,0.2)', zIndex: 10, padding: 0,
            fontSize: '12px', fontWeight: 'bold'
          }}
          title="View Execution Details"
        >
          {execStatus === 'completed' ? '✓' : '✕'}
        </button>
      )}
    </div>
  );
}

export default memo(TaskNode);
