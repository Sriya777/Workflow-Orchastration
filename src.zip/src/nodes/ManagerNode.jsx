import { memo, useState, useEffect } from 'react';
import { Handle, Position, useReactFlow } from '@xyflow/react';
import { createPortal } from 'react-dom';

function ManagerNode({ id, data, selected }) {
  const {
    label = 'Manager Review',
    description = '',
    managerDecision = '',   // 'approved' | 'rejected'
    managerComments = '',
    managerStatus = 'pending', // 'pending' | 'submitted'
    execStatus,
    execTat,
    appMode = 'editor',
  } = data;

  const { getNodes, getEdges } = useReactFlow();
  const [formData, setFormData] = useState(null);
  const [formReqId, setFormReqId] = useState('');

  const statusClass = execStatus ? `exec-${execStatus}` : '';

  // Retrieve details of the predecessor Form Node dynamically
  useEffect(() => {
    const nodes = getNodes();
    const edges = getEdges();
    
    const incoming = edges.filter(e => e.target === id);
    const predecessorForm = incoming
      .map(e => nodes.find(n => n.id === e.source))
      .find(n => n && (n.type === 'formTask' || n.type === 'formNode'));

    if (predecessorForm && predecessorForm.data) {
      setFormData(predecessorForm.data.filledData || null);
      setFormReqId(predecessorForm.data.requestId || '');
    } else {
      setFormData(null);
      setFormReqId('');
    }
  }, [getNodes, getEdges, id, execStatus]); // Update when graph state or execution changes

  const [decision, setDecision] = useState(managerDecision || '');
  const [comments, setComments] = useState(managerComments || '');
  const [showModal, setShowModal] = useState(false);

  // Open modal when execution reaches this node and data is ready
  useEffect(() => {
    if (execStatus === 'running') {
      setShowModal(true);
    }
  }, [execStatus]);

  // Keep state in sync with updated node data (e.g. if loaded from save)
  useEffect(() => {
    if (managerDecision) setDecision(managerDecision);
    if (managerComments) setComments(managerComments);
  }, [managerDecision, managerComments]);

  const handleSubmit = (e) => {
    e?.stopPropagation();
    if (!decision) return;
    
    // Dispatch custom event to resolve the execution promise in App.jsx
    const event = new CustomEvent('manager-submit', {
      detail: {
        nodeId: id,
        decision: decision.toLowerCase(),
        comments,
      }
    });
    window.dispatchEvent(event);
    setShowModal(false);
  };

  const closeModal = () => setShowModal(false);

  return (
    <>
      <Handle type="target" position={Position.Left} className="node-handle" />

      {/* Node */}
      <div
        className={`w-52 bg-[#1c2238] border ${selected ? 'border-green-400 shadow-[0_0_0_2px_rgba(16,185,129,0.25)]' : 'border-cyan-400'} rounded-xl p-4 shadow-lg transition relative ${statusClass} ${appMode === 'editor' ? 'cursor-grab' : 'cursor-pointer hover:scale-105'}`}
        onClick={() => {
          if (appMode === 'editor') return;
          setShowModal(true);
        }}
      >
        <div className="flex items-center gap-2 mb-2">
           <h3 className="text-white font-semibold text-sm m-0">{label}</h3>
           {execStatus && (
              <span className={`text-xs ${execStatus === 'completed' ? 'text-green-400' : 'text-yellow-400'}`}>
                {execStatus === 'running' && '⟳'}
                {execStatus === 'completed' && '✓'}
                {execStatus === 'pending' && '○'}
              </span>
           )}
        </div>
        
        {managerStatus === 'submitted' ? (
          <div className="mt-2 text-xs">
            <span
              className={`px-2 py-1 rounded text-white font-semibold ${
                (managerDecision || '').toLowerCase() === "approved" ? "bg-green-600" : "bg-red-600"
              }`}
            >
              {(managerDecision || '').toUpperCase()}
            </span>
          </div>
        ) : (
          <p className="text-gray-400 text-xs mt-2 m-0">
            Click to open review window
          </p>
        )}

        {execTat && (
          <div className="absolute -bottom-3 right-2 bg-gray-800 border border-gray-600 text-gray-300 text-[9px] px-1.5 py-0.5 rounded flex items-center gap-1">
            <svg width="8" height="8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" /></svg>
            {execTat}s
          </div>
        )}

        {(execStatus === 'completed' || execStatus === 'error') && (
          <button 
            className="node-result-btn"
            onClick={(e) => { e.stopPropagation(); if (data.onViewResult) data.onViewResult(id); }}
            style={{
              position: 'absolute', bottom: -10, right: -10,
              width: 24, height: 24, borderRadius: '50%',
              background: execStatus === 'completed' ? '#22c55e' : '#ef4444',
              color: 'white', border: '2px solid var(--bg-surface, #1e293b)',
              cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: '0 2px 4px rgba(0,0,0,0.2)', zIndex: 10, padding: 0,
              fontSize: '12px', fontWeight: 'bold'
            }}
            title="View Execution Details"
          >
            {execStatus === 'completed' ? '✓' : '✕'}
          </button>
        )}
      </div>

      <Handle type="source" position={Position.Right} className="node-handle" />

      {/* Separate Popup Window */}
      {showModal && createPortal(
        <div className="fixed inset-0 bg-black/60 flex justify-center items-center" style={{ zIndex: 99999 }}>
          <div className="w-[420px] bg-[#111827] rounded-2xl shadow-2xl border border-cyan-400 p-6 relative">
            {/* Close Button */}
            <button
              className="absolute top-3 right-4 text-gray-400 hover:text-white"
              onClick={closeModal}
            >
              ✕
            </button>

            <h2 className="text-white text-lg font-semibold mb-5">
              Manager Review
            </h2>

            {/* Details */}
            <div className="space-y-2 text-sm mb-6">
              <p className="text-gray-300">
                Request ID: <span className="text-white">{formReqId || '—'}</span>
              </p>
              {formData && Object.keys(formData).map(key => {
                if (key === 'attachments' || key === 'formSource') return null;
                let label = key.charAt(0).toUpperCase() + key.slice(1);
                if (key === 'motherName') label = 'Mother Name';
                if (key === 'fatherName') label = 'Father Name';
                return (
                  <p key={key} className="text-gray-300">
                    {label}: <span className="text-white">{formData[key] || '-'}</span>
                  </p>
                );
              })}
              {formData?.attachments && formData.attachments.map((att, idx) => (
                <div key={idx} className="flex justify-between items-center bg-gray-800/50 p-2 rounded border border-cyan-900/50 mt-3 nodrag">
                  <span className="text-xs text-gray-400">📄 Attachment:</span>
                  <a href={att.data} download={att.name} className="text-xs text-cyan-400 hover:text-cyan-300 underline font-medium cursor-pointer nodrag">
                    Download ({att.name})
                  </a>
                </div>
              ))}
            </div>

            {/* Decision Buttons */}
            <div className="flex gap-4 mb-4">
              <button
                onClick={() => setDecision("Approved")}
                className={`flex-1 hover:bg-green-700 text-white py-2 rounded-lg font-medium transition ${decision.toLowerCase() === 'approved' ? 'bg-green-700 ring-2 ring-green-300' : 'bg-green-600'}`}
              >
                Approve
              </button>

              <button
                onClick={() => setDecision("Rejected")}
                className={`flex-1 hover:bg-red-700 text-white py-2 rounded-lg font-medium transition ${decision.toLowerCase() === 'rejected' ? 'bg-red-700 ring-2 ring-red-300' : 'bg-red-600'}`}
              >
                Reject
              </button>
            </div>

            {/* Status */}
            {decision && (
              <div className="mt-5 text-center mb-5">
                <span
                  className={`px-4 py-2 rounded-lg text-white font-semibold ${
                    decision.toLowerCase() === "approved" ? "bg-green-600" : "bg-red-600"
                  }`}
                >
                  {decision.charAt(0).toUpperCase() + decision.slice(1).toLowerCase()}
                </span>
              </div>
            )}

            <div className="mt-4 text-right">
              <button 
                onClick={handleSubmit} 
                disabled={!decision}
                className={`text-white py-2 px-4 rounded-lg font-medium transition ${decision ? 'bg-violet-600 hover:bg-violet-700' : 'bg-gray-600 cursor-not-allowed'}`}
              >
                Submit Decision
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}
    </>
  );
}

export default memo(ManagerNode);
