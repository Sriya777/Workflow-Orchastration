import { memo } from 'react';
import { Handle, Position } from '@xyflow/react';

const MODE_OPTIONS = ['WebSocket', 'TypeScript', 'NodeJS', 'Email', 'Custom'];

function ModeControllerNode({ data, selected }) {
  const { label = 'Mode Controller', modes = [], description = '', execStatus, execTat } = data;
  const statusClass = execStatus ? `exec-${execStatus}` : '';

  return (
    <div className={`mode-controller-node ${selected ? 'selected' : ''} ${statusClass}`}>
      <Handle type="target" position={Position.Left} className="node-handle" />

      <div className="mc-header">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
          <circle cx="12" cy="12" r="3" />
        </svg>
        <span className="mc-label">{label}</span>
        {execStatus && (
          <span className={`node-exec-status ${execStatus}`}>
            {execStatus === 'running' && '⟳'}
            {execStatus === 'completed' && '✓'}
            {execStatus === 'pending' && '○'}
          </span>
        )}
      </div>

      <div className="mc-modes">
        {MODE_OPTIONS.map((mode) => (
          <span
            key={mode}
            className={`mc-chip ${(modes || []).includes(mode) ? 'active' : ''}`}
          >
            {mode}
          </span>
        ))}
      </div>

      {description && <p className="mc-desc">{description}</p>}

      {execTat && (
        <div className="node-tat-badge">
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <circle cx="12" cy="12" r="10" />
            <polyline points="12 6 12 12 16 14" />
          </svg>
          {execTat}s
        </div>
      )}

      <Handle type="source" position={Position.Right} className="node-handle" />
    </div>
  );
}

export default memo(ModeControllerNode);
