import { useState, useCallback, useRef, useEffect } from 'react';
import {
  ReactFlow,
  addEdge,
  applyNodeChanges,
  applyEdgeChanges,
  Background,
  Controls,
  MiniMap,
  Panel,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';

import { nodeTypes } from './nodes/index';
import NodePanel from './components/NodePanel';
import PropertiesPanel from './components/PropertiesPanel';
import { v4 as uuidv4 } from 'uuid';
import './App.css';

/* ── Default starter workflow ── */
const initialNodes = [];
const initialEdges = [];

export default function App() {
  const reactFlowWrapper = useRef(null);
  const [nodes, setNodes] = useState(initialNodes);
  const [edges, setEdges] = useState(initialEdges);
  const [selectedNode, setSelectedNode] = useState(null);
  const [reactFlowInstance, setReactFlowInstance] = useState(null);
  const [showToast, setShowToast] = useState(null);
  const [workflowTitle, setWorkflowTitle] = useState('Antigravity Workflow');
  const [appMode, setAppMode] = useState('editor'); // 'editor' | 'execution'
  const [workflowVersion, setWorkflowVersion] = useState(0.0);
  const [currentWorkflowId, setCurrentWorkflowId] = useState(() => uuidv4());
  const [globalExecutionError, setGlobalExecutionError] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [sortOrder, setSortOrder] = useState('recent'); // 'recent' | 'alphabetical'
  const [isExecuting, setIsExecuting] = useState(false);
  const [allExecutionRuns, setAllExecutionRuns] = useState({}); // { [workflowId]: [...runs] }
  const [selectedRunIndex, setSelectedRunIndex] = useState(null);
  const [showRunDetails, setShowRunDetails] = useState(false);
  const [selectedResultNode, setSelectedResultNode] = useState(null);

  const handleViewResult = useCallback((nodeId) => {
    setSelectedResultNode(nodeId);
  }, []);

  // Settings Modal State
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [settingsProvider, setSettingsProvider] = useState(() => {
    const saved = localStorage.getItem('antigravity_settings');
    return saved ? JSON.parse(saved).provider : 'OpenAI';
  });
  const [settingsModel, setSettingsModel] = useState(() => {
    const saved = localStorage.getItem('antigravity_settings');
    return saved ? (JSON.parse(saved).model || '') : '';
  });
  const [settingsBaseUrl, setSettingsBaseUrl] = useState(() => {
    const saved = localStorage.getItem('antigravity_ai_config');
    return saved ? JSON.parse(saved).baseUrl : '';
  });
  const [settingsApiKey, setSettingsApiKey] = useState(() => {
    const saved = localStorage.getItem('antigravity_ai_config');
    return saved ? JSON.parse(saved).apiKey : '';
  });
  const [settingsError, setSettingsError] = useState('');
  const [settingsSuccessMessage, setSettingsSuccessMessage] = useState('');
  const [isTestingKey, setIsTestingKey] = useState(false);

  // DB Configuration State
  const [dbSettingsHost, setDbSettingsHost] = useState(() => {
    const saved = localStorage.getItem('antigravity_db_config');
    return saved ? JSON.parse(saved).host || '' : '';
  });
  const [dbSettingsPort, setDbSettingsPort] = useState(() => {
    const saved = localStorage.getItem('antigravity_db_config');
    return saved ? JSON.parse(saved).port || '' : '';
  });
  const [dbSettingsUser, setDbSettingsUser] = useState(() => {
    const saved = localStorage.getItem('antigravity_db_config');
    return saved ? JSON.parse(saved).user || '' : '';
  });
  const [dbSettingsPwd, setDbSettingsPwd] = useState(() => {
    const saved = localStorage.getItem('antigravity_db_config');
    return saved ? JSON.parse(saved).pwd || '' : '';
  });
  const [dbSettingsName, setDbSettingsName] = useState(() => {
    const saved = localStorage.getItem('antigravity_db_config');
    return saved ? JSON.parse(saved).dbName || '' : '';
  });
  const [dbConnectionStatus, setDbConnectionStatus] = useState('');
  // Execute dropdown state
  const [showExecuteDropdown, setShowExecuteDropdown] = useState(false);
  const [showDataSourcePicker, setShowDataSourcePicker] = useState(false);
  const [selectedDataSource, setSelectedDataSource] = useState(null);
  
  const [currentHash, setCurrentHash] = useState(window.location.hash);
  const managerResolvers = useRef({});
  // Resolver map for awaiting form submissions
  const formResolvers = useRef({});
  const emailResolvers = useRef({});
  const smsResolvers = useRef({});
  const stopExecutionRef = useRef(false);
  const latestNodesRef = useRef(nodes);

  // Keep latestNodesRef up to date to avoid stale closures in handleTrigger
  useEffect(() => {
    latestNodesRef.current = nodes;
  }, [nodes]);

  useEffect(() => {
    const handleHashChange = () => {
      setCurrentHash(window.location.hash);
    };

    const handleManagerSubmit = (e) => {
      const { nodeId, decision, comments } = e.detail;
      setNodes(nds => {
        const nextNds = nds.map(n => n.id === nodeId ? {
          ...n,
          data: {
            ...n.data,
            managerDecision: decision,
            managerComments: comments,
            managerStatus: 'submitted',
            execStatus: 'completed'
          }
        } : n);
        latestNodesRef.current = nextNds;
        return nextNds;
      });

      if (managerResolvers.current[nodeId]) {
        managerResolvers.current[nodeId]();
        delete managerResolvers.current[nodeId];
      }
      flashToast(`Decision (${decision}) recorded by Manager!`);
    };

    const handleFormMessage = (event) => {
      if (event.data && event.data.type === 'FORM_SUBMITTED') {
        const { nodeId, requestId, formData } = event.data;
        setNodes(nds => {
          const nextNds = nds.map(n => {
            if (n.id === nodeId) {
              return {
                ...n,
                data: {
                  ...n.data,
                  formStatus: 'filled',
                  requestId: requestId,
                  filledData: formData
                }
              };
            }
            return n;
          });
          latestNodesRef.current = nextNds;
          return nextNds;
        });
        // Resolve any awaiting triggerForm promise for this node
        if (formResolvers.current[nodeId]) {
          formResolvers.current[nodeId]();
          delete formResolvers.current[nodeId];
        }
        flashToast(`Form details attached successfully!`);
      }
    };

    const handleCustomFormComplete = (event) => {
      const { nodeId } = event.detail;
      setNodes(nds => {
        const nextNds = nds.map(n => {
          if (n.id === nodeId) {
            return {
              ...n,
              data: {
                ...n.data,
                formStatus: 'submitted',
                execStatus: 'completed'
              }
            };
          }
          return n;
        });
        latestNodesRef.current = nextNds;
        return nextNds;
      });
      if (formResolvers.current[nodeId]) {
        formResolvers.current[nodeId]();
        delete formResolvers.current[nodeId];
      }
      flashToast(`Custom Form Task marked as completed!`);
    };

    const handleWindowFocus = () => {
      setNodes(nds => nds.map(n => {
        // Handle both old formNode and new formTask (Form 1) nodes
        const isFormNode = n.type === 'formNode';
        const isFormTask1 = n.type === 'formTask' && n.data.taskMode === 'form1';
        if ((isFormNode || isFormTask1) && n.data.formStatus !== 'filled') {
          const localData = localStorage.getItem(`form_fill_${n.id}`);
          if (localData) {
            try {
              const parsed = JSON.parse(localData);
              localStorage.removeItem(`form_fill_${n.id}`);
              // Also fire resolver if execution is waiting
              if (formResolvers.current[n.id]) {
                formResolvers.current[n.id]();
                delete formResolvers.current[n.id];
              }
              return {
                ...n,
                data: {
                  ...n.data,
                  formStatus: 'filled',
                  requestId: parsed.requestId,
                  filledData: parsed.formData
                }
              };
            } catch { /* ignore parse errors */ }
          }
        }
        return n;
      }));
    };

    const handleEmailConfirm = (event) => {
      const { nodeId } = event.detail;
      if (emailResolvers.current[nodeId]) {
        emailResolvers.current[nodeId]();
        delete emailResolvers.current[nodeId];
      }
    };

    const handleSmsConfirm = (event) => {
      const { nodeId } = event.detail;
      if (smsResolvers.current[nodeId]) {
        smsResolvers.current[nodeId]();
        delete smsResolvers.current[nodeId];
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    window.addEventListener('manager-submit', handleManagerSubmit);
    window.addEventListener('message', handleFormMessage);
    window.addEventListener('custom-form-complete', handleCustomFormComplete);
    window.addEventListener('focus', handleWindowFocus);
    window.addEventListener('email-confirm', handleEmailConfirm);
    window.addEventListener('sms-confirm', handleSmsConfirm);
    return () => {
      window.removeEventListener('hashchange', handleHashChange);
      window.removeEventListener('manager-submit', handleManagerSubmit);
      window.removeEventListener('message', handleFormMessage);
      window.removeEventListener('custom-form-complete', handleCustomFormComplete);
      window.removeEventListener('focus', handleWindowFocus);
      window.removeEventListener('email-confirm', handleEmailConfirm);
      window.removeEventListener('sms-confirm', handleSmsConfirm);
    };
  }, []);

  // Derive runs for the current workflow
  const executionRuns = allExecutionRuns[currentWorkflowId] || [];

  useEffect(() => {
    // Clear storage to start from version 0 and remove existing nodes
    localStorage.removeItem('antigravity_workflows_array');
    localStorage.removeItem('antigravity_save');
    try {
      let workflows = [];
      const legacySave = localStorage.getItem('antigravity_save');
      
      if (legacySave && workflows.length === 0) {
         const legacyFlow = JSON.parse(legacySave);
         legacyFlow.id = uuidv4();
         workflows.push(legacyFlow);
         localStorage.setItem('antigravity_workflows_array', JSON.stringify(workflows));
         localStorage.removeItem('antigravity_save'); // Clean up old format
      }

      // Load most recent by default
      if (workflows.length > 0) {
        workflows.sort((a, b) => new Date(b.savedAt) - new Date(a.savedAt));
        const flow = workflows[0];
        setCurrentWorkflowId(flow.id);
        setNodes(flow.nodes.map(n => ({
        ...n,
        data: { ...n.data, onViewResult: handleViewResult }
      })));
      setEdges(flow.edges || []);
        setWorkflowTitle(flow.name || 'Antigravity Workflow');
        setWorkflowVersion(flow.version || 1.0);
      }
    } catch {}
  }, []);

  const bumpVersion = useCallback(() => {
    setWorkflowVersion((v) => +(v + 0.1).toFixed(1));
  }, []);

  /* ── React Flow callbacks ── */
  const onNodesChange = useCallback(
    (changes) => setNodes((nds) => applyNodeChanges(changes, nds)),
    [],
  );
  const onEdgesChange = useCallback(
    (changes) => setEdges((eds) => applyEdgeChanges(changes, eds)),
    [],
  );
  const onConnect = useCallback(
    (connection) => {
      setEdges((eds) =>
        addEdge({ ...connection, animated: false, style: { strokeWidth: 2, stroke: '#7c3aed' } }, eds),
      );
      bumpVersion();
    },
    [bumpVersion],
  );

  /* ── Node selection ── */
  const onNodeClick = useCallback((_event, node) => {
    setSelectedNode(node);
  }, []);

  const onPaneClick = useCallback(() => {
    setSelectedNode(null);
  }, []);

  /* ── Drag‑and‑drop from sidebar ── */
  const onDragOver = useCallback((event) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }, []);

  const onDrop = useCallback(
    (event) => {
      event.preventDefault();
      const raw = event.dataTransfer.getData('application/reactflow');
      if (!raw) return;

      const template = JSON.parse(raw);
      const position = reactFlowInstance.screenToFlowPosition({
        x: event.clientX,
        y: event.clientY,
      });

      let parentId = undefined;
      let relativePos = position;

      if (template.type !== 'swimlane') {
        const groups = reactFlowInstance.getNodes().filter((n) => n.type === 'swimlane');
        for (let i = groups.length - 1; i >= 0; i--) {
          const g = groups[i];
          const gWidth = g.measured?.width || 300;
          const gHeight = g.measured?.height || 200;
          if (
            position.x >= g.position.x && position.x <= g.position.x + gWidth &&
            position.y >= g.position.y && position.y <= g.position.y + gHeight
          ) {
            parentId = g.id;
            relativePos = { x: position.x - g.position.x, y: position.y - g.position.y };
            break;
          }
        }
      }

      const extraData = {};
      if (template.type === 'apiCall') {
        extraData.apiMethod = 'GET';
        extraData.apiUrl = '';
        extraData.apiHeaders = '';
        extraData.apiBody = '';
        extraData.apiStatus = 'idle';
      }
      if (template.type === 'formTask') {
        extraData.taskMode = template.taskMode || 'form1';
        extraData.formSource = template.formSource || 'builtin';
        extraData.customUrl = template.customUrl || '';
        extraData.useExistingDetails = false;
        if (extraData.taskMode === 'form1') {
          extraData.formStatus = 'draft';
        } else {
          extraData.managerStatus = 'pending';
        }
      }
      if (template.type === 'formNode') {
        extraData.formFields = [
          { id: 'email_id_default', label: 'Email ID', variableName: 'email_id', type: 'email', value: '', required: true }
        ];
        extraData.formAttachments = [];
        extraData.formStatus = 'draft';
      }

      if (template.type === 'aiAgent') {
        extraData.promptTemplate = '';
        extraData.nodeOutput = '';
        extraData.selectedVariables = [];
      }
      if (template.type === 'screenScraperNode') {
        extraData.websiteUrl = '';
      }
      if (template.type === 'uploadCsvNode') {
        extraData.csvFileName = '';
      }
      if (template.type === 'googleSheetsNode') {
        extraData.googleSheetUrl = '';
      }

      const newNode = {
        id: uuidv4(),
        type: template.type,
        position: relativePos,
        parentId,
        zIndex: template.type === 'swimlane' ? -1 : 0,
        data: {
          label: template.label,
          nodeType: template.nodeType || undefined,
          color: template.color || undefined,
          variant: template.variant || undefined,
          description: '',
          appMode: appMode,
          onViewResult: handleViewResult,
          ...extraData,
        },
      };

      setNodes((nds) => [...nds, newNode]);
      bumpVersion();
    },
    [reactFlowInstance, bumpVersion, appMode, handleViewResult],
  );

  /* ── Drag Nodes into/out of Groups ── */
  const onNodeDragStop = useCallback((e, node) => {
    if (node.type === 'swimlane') {
      bumpVersion();
      return; 
    }

    const intersections = reactFlowInstance.getIntersectingNodes(node).filter(n => n.type === 'swimlane');
    
    setNodes((nds) => {
      const currNode = nds.find(n => n.id === node.id);
      if (!currNode) return nds;

      if (intersections.length > 0) {
        const group = intersections[0];
        if (currNode.parentId !== group.id) {
           const absX = node.positionAbsolute?.x ?? node.position.x;
           const absY = node.positionAbsolute?.y ?? node.position.y;
           return nds.map((n) => {
             if (n.id === node.id) {
               return {
                 ...n,
                 parentId: group.id,
                 position: { x: absX - group.position.x, y: absY - group.position.y }
               };
             }
             return n;
           });
        }
      } else if (currNode.parentId) {
        const absX = node.positionAbsolute?.x ?? node.position.x;
        const absY = node.positionAbsolute?.y ?? node.position.y;
        return nds.map((n) => {
           if (n.id === node.id) {
             return { ...n, parentId: undefined, position: { x: absX, y: absY } };
           }
           return n;
        });
      }
      return nds;
    });
    
    bumpVersion();
  }, [reactFlowInstance, bumpVersion]);

  /* ── Update node data from properties panel ── */
  const handleUpdateNode = useCallback((nodeId, newData) => {
    setNodes((nds) =>
      nds.map((n) => (n.id === nodeId ? { ...n, data: { ...n.data, ...newData } } : n)),
    );
    setSelectedNode((prev) =>
      prev && prev.id === nodeId ? { ...prev, data: { ...prev.data, ...newData } } : prev,
    );
    bumpVersion();
  }, [bumpVersion]);

  /* ── Delete node ── */
  const handleDeleteNode = useCallback(
    (nodeId) => {
      setNodes((nds) => nds.filter((n) => n.id !== nodeId));
      setEdges((eds) => eds.filter((e) => e.source !== nodeId && e.target !== nodeId));
      setSelectedNode(null);
      bumpVersion();
    },
    [bumpVersion],
  );

  /* ── Save / New workflow ── */
  const handleSave = useCallback(() => {
    const workflow = {
      id: currentWorkflowId,
      name: workflowTitle,
      version: workflowVersion,
      savedAt: new Date().toISOString(),
      nodes: nodes.map(({ id, type, position, data, className, parentId }) => ({ id, type, position, data, className, parentId })),
      edges: edges.map(({ id, source, target }) => ({ id, source, target })),
    };
    try {
      let workflows = JSON.parse(localStorage.getItem('antigravity_workflows_array') || '[]');
      const existingIndex = workflows.findIndex(w => w.id === currentWorkflowId);
      
      if (existingIndex >= 0) {
        workflows[existingIndex] = workflow;
      } else {
        workflows.push(workflow);
      }
      
      localStorage.setItem('antigravity_workflows_array', JSON.stringify(workflows));
      flashToast('Workflow saved locally!');
    } catch (e) {
      flashToast('Failed to save to local storage', 'error');
    }
  }, [nodes, edges, workflowTitle, workflowVersion, currentWorkflowId]);

  const handleNew = useCallback(() => {
    if (window.confirm("Start a new workflow? Unsaved changes will be lost.")) {
      setNodes([]);
      setEdges([]);
      setWorkflowTitle('Untitled Workflow');
      setWorkflowVersion(1.0);
      setCurrentWorkflowId(uuidv4());
      setSelectedNode(null);
      setSelectedRunIndex(null);
      setShowRunDetails(false);
      flashToast('New empty workflow created');
    }
  }, []);
  
  const handleLoad = useCallback((flow) => {
    setCurrentWorkflowId(flow.id);
    const flowNodes = (flow.nodes || []).map(n => ({
      ...n,
      data: {
        ...n.data,
        appMode: 'editor',
        execStatus: undefined,
        execTat: undefined,
        execError: undefined,
        onViewResult: handleViewResult
      }
    }));
    setNodes(flowNodes);
    setEdges(flow.edges || []);
    setWorkflowTitle(flow.name || 'Antigravity Workflow');
    setWorkflowVersion(flow.version || 1.0);
    setSelectedNode(null);
    setSelectedRunIndex(null);
    setShowRunDetails(false);
    setIsModalOpen(false);
    setAppMode('editor');
    flashToast('Workflow loaded!');
  }, [handleViewResult]);

  const handleDeleteFlow = useCallback((flowId) => {
    if (window.confirm("Are you sure you want to permanently delete this workflow?")) {
      const workflows = JSON.parse(localStorage.getItem('antigravity_workflows_array') || '[]');
      const updated = workflows.filter(w => w.id !== flowId);
      localStorage.setItem('antigravity_workflows_array', JSON.stringify(updated));
      flashToast('Workflow deleted');
      // Force UI re-render by toggling a piece of local state
      setSortOrder(prev => prev);
    }
  }, []);

  /* ── Export / Upload workflow ── */
  const handleExport = useCallback(() => {
    const workflow = {
      name: workflowTitle,
      version: workflowVersion,
      exportedAt: new Date().toISOString(),
      nodes: nodes.map(({ id, type, position, data }) => ({ id, type, position, data })),
      edges: edges.map(({ id, source, target }) => ({ id, source, target })),
    };
    const blob = new Blob([JSON.stringify(workflow, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'antigravity-workflow.json';
    a.click();
    URL.revokeObjectURL(url);
    flashToast('Workflow exported successfully!');
  }, [nodes, edges]);

  /* ── Import / Upload workflow ── */
  const handleImport = useCallback(() => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        try {
          const workflow = JSON.parse(ev.target.result);
          if (workflow.nodes && workflow.edges) {
            const importedNodes = workflow.nodes.map(n => ({
              ...n,
              data: {
                ...n.data,
                appMode: 'editor',
                execStatus: undefined,
                execTat: undefined,
                execError: undefined,
                onViewResult: handleViewResult
              }
            }));
            setNodes(importedNodes);
            setEdges(
              workflow.edges.map((edge) => ({
                ...edge,
                animated: false,
                style: { strokeWidth: 2, stroke: '#7c3aed' },
              })),
            );
            setWorkflowTitle(workflow.name || 'Imported Workflow');
            setWorkflowVersion(workflow.version || 1.0);
            setSelectedNode(null);
            setAppMode('editor');
            flashToast('Workflow imported successfully!');
          } else {
            flashToast('Invalid workflow file', 'error');
          }
        } catch {
          flashToast('Failed to parse workflow file', 'error');
        }
      };
      reader.readAsText(file);
    };
    input.click();
  }, [handleViewResult]);

  /* ── Toast helper ── */
  const flashToast = (message, type = 'success') => {
    setShowToast({ message, type });
    setTimeout(() => setShowToast(null), 3000);
  };

  /* ── Minimap colour ── */
  const minimapNodeColor = (node) => {
    return node.data?.color || '#555555';
  };

  /* ── Workflow Context Builder ── */
  // Walks upstream from currentNodeId and collects all variable values from
  // form nodes (filledData fields) and AI agent nodes (nodeOutput).
  const buildWorkflowContext = (allNodes, allEdges, currentNodeId) => {
    const context = {};

    // Build adjacency: target -> [sources]
    const incomingMap = {};
    allEdges.forEach(e => {
      if (!incomingMap[e.target]) incomingMap[e.target] = [];
      incomingMap[e.target].push(e.source);
    });

    // BFS upstream
    const visited = new Set();
    const queue = [...(incomingMap[currentNodeId] || [])];
    while (queue.length > 0) {
      const nId = queue.shift();
      if (visited.has(nId)) continue;
      visited.add(nId);
      const node = allNodes.find(n => n.id === nId);
      if (!node) continue;

      const nodeName = (node.data.label || node.id).replace(/\s+/g, '');

      // Form nodes — expose each filled field as NodeLabel.field and bare field
      if ((node.type === 'formNode' || (node.type === 'formTask' && node.data.taskMode === 'form1')) && node.data.filledData) {
        const fd = node.data.filledData;
        let keys = [];
        if (node.data.formFields && node.data.formFields.length > 0) {
          keys = node.data.formFields.filter(f => f.passThrough !== false).map(f => f.variableName).filter(Boolean);
        } else {
          keys = Object.keys(fd).filter(k => k !== 'attachments' && k !== 'formSource');
        }
        
        keys.forEach((key, index) => {
          if (fd[key] !== undefined) {
            context[key] = fd[key]; // bare variable e.g. email_id
            context[`${nodeName}.${key}`] = fd[key]; // namespaced e.g. Form1.email_id
            context[`${nodeName}(${index + 1})`] = fd[key]; // 1-based index e.g. Form1(1)
            
            if (key === 'email_id' || key === 'email') {
              context['email'] = fd[key];
              context[`${nodeName}.email`] = fd[key];
            }
          }
        });
      }

      // AI Agent nodes — expose nodeOutput
      if (node.type === 'aiAgent' && node.data.nodeOutput) {
        context[`${nodeName}.output`] = node.data.nodeOutput;
        context['AIAgent.output'] = node.data.nodeOutput; // shortcut
      }

      // API Call nodes — expose response
      if (node.type === 'apiCall' && node.data.apiResponsePreview) {
        context[`${nodeName}.output`] = node.data.apiResponsePreview;
      }

      // Data Extraction from Spreadsheet nodes
      if (node.type === 'uploadCsvNode') {
        if (node.data.csvHeaders && node.data.csvData && node.data.csvData.length > 0) {
          node.data.csvHeaders.forEach(col => {
            const val = node.data.csvData[0][col];
            context[`${nodeName}.${col}`] = val;
            context[col] = val;
          });
        } else {
          // Fallback if no file is uploaded
          const mockColumns = ['filename', 'Name', 'Email'];
          mockColumns.forEach(col => {
            context[`${nodeName}.${col}`] = `[Mock ${col}]`;
            context[col] = `[Mock ${col}]`;
          });
        }
      } else if (node.type === 'googleSheetsNode') {
        const mockColumns = ['columnName', 'id', 'name', 'email'];
        mockColumns.forEach(col => {
          context[`${nodeName}.${col}`] = `[Data from ${col}]`;
          context[col] = `[Data from ${col}]`;
        });
      }

      // Walk further upstream
      (incomingMap[nId] || []).forEach(src => {
        if (!visited.has(src)) queue.push(src);
      });
    }
    return context;
  };

  // Resolves {{variable}} and ${variable} placeholders in a template string using context
  const resolveTemplate = (template, context) => {
    if (!template) return '';
    // 1. Resolve {{variable}}
    let resolved = template.replace(/\{\{([^}]+)\}\}/g, (_, key) => {
      return context[key.trim()] !== undefined ? context[key.trim()] : `{{${key}}}`;
    });
    // 2. Resolve ${variable}
    resolved = resolved.replace(/\\$\\{([^}]+)\\}/g, (_, key) => {
      return context[key.trim()] !== undefined ? context[key.trim()] : `\\$\\{${key}\\}`;
    });
    // 3. Resolve bare NodeName(index) like N2(1)
    resolved = resolved.replace(/\\b([a-zA-Z0-9_]+)\\((\\d+)\\)/g, (match, nodeName, index) => {
      const key = `${nodeName}(${index})`;
      return context[key] !== undefined ? context[key] : match;
    });
    // 4. Resolve bare NodeName.output or NodeName output like N3.output or N3 output
    resolved = resolved.replace(/\\b([a-zA-Z0-9_]+)[ .]output\\b/gi, (match, nodeName) => {
      const key = `${nodeName}.output`;
      return context[key] !== undefined ? context[key] : match;
    });
    return resolved;
  };

  // Helper to automatically open a form for a given node and wait for submission
  const triggerForm = async (node) => {
    // Ensure a requestId exists for the form
    const reqId = node.data.requestId || `REQ-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
    // Update node with the requestId (so downstream logic can reference it)
    setNodes((nds) => nds.map((n) => (n.id === node.id ? { ...n, data: { ...n.data, requestId: reqId } } : n)));
    const fillUrl = `${window.location.origin}${window.location.pathname}#/fill-form/${node.id}/${reqId}`;
    const win = window.open(fillUrl, '_blank', 'width=500,height=600,status=no,menubar=no,resizable=yes');
    if (!win) {
      flashToast('Popup blocked! Please click the pulsing button on the form node to enter details.', 'error');
    }
    // Return a promise that resolves when the form submit event is received
    return new Promise((resolve) => {
      formResolvers.current[node.id] = resolve;
    });
  };
  const handleTrigger = useCallback(async (nodeId) => {
    if (isExecuting) return;
    setIsExecuting(true);
    stopExecutionRef.current = false;
    const startNode = latestNodesRef.current.find((n) => n.id === nodeId);
    const executionStartTime = Date.now();
    flashToast(`Execution started from: ${startNode?.data.label || 'Node'}`);
    // Auto‑trigger if the start node is a Form node and it is not already filled
    if (
      (startNode?.type === 'formNode' || (startNode?.type === 'formTask' && startNode.data.taskMode === 'form1' && startNode.data.formSource !== 'custom')) &&
      startNode.data.formStatus !== 'filled'
    ) {
      await triggerForm(startNode);
    }

    // Reset all nodes to pending first and set isExecuting to true in node data
    setNodes(nds => {
      const nextNds = nds.map(n => {
        const extra = {};
        if (n.type === 'managerNode' || (n.type === 'formTask' && n.data.taskMode === 'form2')) {
          extra.managerStatus = 'pending';
          extra.managerDecision = '';
          extra.managerComments = '';
        }
        return {
          ...n,
          data: { ...n.data, execStatus: 'pending', execTat: undefined, isExecuting: true, ...extra }
        };
      });
      latestNodesRef.current = nextNds;
      return nextNds;
    });

    const adjacency = {};
    edges.forEach((e) => {
      if (!adjacency[e.source]) adjacency[e.source] = [];
      adjacency[e.source].push(e);
    });

    let currentLayer = [nodeId];
    const visitedNodes = new Set([nodeId]);
    const activeEdges = new Set();
    const stepsExecuted = [];
    const apiCallQueue = []; // track API nodes for execution
    const aiAgentQueue = []; // track AI Agent nodes
    const taskLinksQueue = []; // track task nodes for validation/running
    const emailNodeQueue = []; // track Email nodes for validation
    const smsNodeQueue = []; // track SMS nodes for simulated sending
    const dbCallNodeQueue = []; // track DB Call nodes
    let globalRunStatus = 'Completed';
    let localGlobalError = '';
    setGlobalExecutionError('');
    stepsExecuted.push({ nodeId, label: startNode?.data.label || 'Start', time: Date.now() });

    // Mark start node as running
    setNodes(nds => nds.map(n => {
      if (n.id === nodeId) {
        return { ...n, data: { ...n.data, execStatus: 'running', execTat: undefined, execError: undefined } };
      }
      return n;
    }));

    await new Promise((r) => setTimeout(r, 600));

    // Validate start node
    let startNodeError = null;
    if (startNode?.type === 'uploadCsvNode' && !startNode.data.csvFileName) {
      startNodeError = 'No CSV file attached.';
    }

    // Mark start node as completed or error
    const startTat = ((Date.now() - executionStartTime) / 1000).toFixed(2);
    setNodes(nds => nds.map(n => {
      if (n.id === nodeId) {
        if (startNodeError) {
          globalRunStatus = 'Failed';
          localGlobalError = `Error: ${startNodeError}`;
          return { ...n, data: { ...n.data, execStatus: 'error', execTat: startTat, execError: startNodeError, nodeOutput: startNodeError } };
        }
        return { ...n, data: { ...n.data, execStatus: 'completed', execTat: startTat } };
      }
      return n;
    }));

    if (startNodeError) {
      setGlobalExecutionError(localGlobalError);
      setIsExecuting(false);
      return;
    }

    while (currentLayer.length > 0) {
      if (stopExecutionRef.current) {
        globalRunStatus = 'Aborted';
        break;
      }
      const nextLayer = [];
      const edgesToAnimate = [];

      currentLayer.forEach((nId) => {
        const outEdges = adjacency[nId] || [];
        outEdges.forEach((e) => {
          edgesToAnimate.push(e.id);
          if (!visitedNodes.has(e.target)) {
            visitedNodes.add(e.target);
            nextLayer.push(e.target);

            const targetNode = latestNodesRef.current.find((n) => n.id === e.target);
            stepsExecuted.push({ nodeId: e.target, label: targetNode?.data.label || 'Node', time: Date.now() });

            if (targetNode?.type === 'task') {
               taskLinksQueue.push(e.target);
            }

            if (targetNode?.type === 'apiCall' && targetNode.data.apiUrl) {
              apiCallQueue.push(e.target);
            }

            if (targetNode?.type === 'aiAgent') {
              aiAgentQueue.push(e.target);
            }

            if (targetNode?.type === 'dbCallNode') {
              dbCallNodeQueue.push(e.target);
            }

            if (targetNode?.type === 'emailNode') {
              emailNodeQueue.push(e.target);
            }

            if (targetNode?.type === 'smsNode') {
              smsNodeQueue.push(e.target);
            }
          }
        });
      });

      if (edgesToAnimate.length === 0) break;
      edgesToAnimate.forEach((eid) => activeEdges.add(eid));

      setEdges((eds) => eds.map((e) => ({
        ...e,
        animated: activeEdges.has(e.id),
        style: activeEdges.has(e.id) ? { strokeWidth: 3, stroke: '#10b981' } : e.style
      })));

      setNodes(nds => nds.map(n => {
        if (nextLayer.includes(n.id)) {
          const extra = {};
          if (n.type === 'apiCall' && n.data.apiUrl) {
            extra.apiStatus = 'loading';
          }
          return { ...n, data: { ...n.data, execStatus: 'running', execTat: undefined, execError: undefined, ...extra } };
        }
        return n;
      }));

      // Interactive execution wait block for all Form Nodes, Form Tasks, Manager Nodes, Email Nodes, and SMS Nodes in this layer
      const interactiveNodesInLayer = nextLayer.filter(id => {
        const node = latestNodesRef.current.find(n => n.id === id);
        return node && (node.type === 'formNode' || node.type === 'formTask' || node.type === 'managerNode' || node.type === 'emailNode' || node.type === 'smsNode');
      });

      if (interactiveNodesInLayer.length > 0) {
        const promises = interactiveNodesInLayer.map(nId => {
          const node = latestNodesRef.current.find(n => n.id === nId);
          if (node && node.type === 'formNode' && node.data.formStatus !== 'filled') {
            triggerForm(node);
          }
          return new Promise((resolve) => {
            formResolvers.current[nId] = resolve;
            managerResolvers.current[nId] = resolve;
            emailResolvers.current[nId] = resolve;
            smsResolvers.current[nId] = resolve;
          });
        });
        await Promise.all(promises);
      }

      if (stopExecutionRef.current) {
        globalRunStatus = 'Aborted';
        break;
      }

      // Validation and execution phase
      let layerHasError = false;
      const apiResults = {};
      const taskResults = {};
      const emailResults = {};
      const genericResults = {};

      // Generic node validation (e.g. CSV missing file)
      nextLayer.forEach(nId => {
        const node = latestNodesRef.current.find(n => n.id === nId);
        if (node?.type === 'uploadCsvNode' && !node.data.csvFileName) {
          genericResults[nId] = { status: 'error', preview: 'No CSV file attached.' };
          layerHasError = true;
          localGlobalError = 'Error: CSV file missing in Upload CSV node.';
        }
      });

      if (taskLinksQueue.length > 0) {
        taskLinksQueue.forEach(nId => {
          const tNode = latestNodesRef.current.find(n => n.id === nId);
          if (!tNode) return;
          if (tNode.data.link) {
            const link = tNode.data.link;
            try {
              const url = new URL(link);
              if (!url.protocol.startsWith('http')) throw new Error('Invalid protocol');
              // Simulate checking if the message was sent / valid URL format
              setTimeout(() => window.open(link, '_blank'), 400); // Only open if no errors above
            } catch (err) {
              taskResults[nId] = { status: 'error', error: 'Invalid or unreachable link URL format' };
              layerHasError = true;
            }
          } else if (tNode.data.document && typeof tNode.data.document !== 'string') {
             setTimeout(() => {
               const a = document.createElement('a');
               a.href = tNode.data.document.data;
               a.download = tNode.data.document.name;
               a.click();
             }, 400);
          }
        });
      }
      taskLinksQueue.length = 0;

      if (apiCallQueue.length > 0) {
        const promises = apiCallQueue.map(async (nId) => {
          const apiNode = latestNodesRef.current.find(n => n.id === nId);
          if (!apiNode) return;
          try {
            const headers = {};
            if (apiNode.data.apiHeaders) {
              try { Object.assign(headers, JSON.parse(apiNode.data.apiHeaders)); } catch {}
            }
            const fetchOpts = { method: apiNode.data.apiMethod || 'GET', headers };
            if (['POST','PUT','PATCH'].includes(fetchOpts.method) && apiNode.data.apiBody) {
              fetchOpts.body = apiNode.data.apiBody;
              if (!headers['Content-Type']) headers['Content-Type'] = 'application/json';
            }
            const res = await fetch(apiNode.data.apiUrl, fetchOpts);
            const text = await res.text();
            apiResults[nId] = {
              status: res.ok ? 'success' : 'error',
              code: res.status,
              preview: text.slice(0, 200),
            };
            if (!res.ok) layerHasError = true;
          } catch (err) {
            apiResults[nId] = {
              status: 'error',
              code: null,
              preview: err.message,
            };
            layerHasError = true;
          }
        });
        await Promise.allSettled(promises);
      }
      apiCallQueue.length = 0;

      // ── DB Call Node Execution ──
      if (dbCallNodeQueue.length > 0) {
        const dbPromises = dbCallNodeQueue.map(async (nId) => {
          const dNode = latestNodesRef.current.find(n => n.id === nId);
          if (!dNode) return;
          
          const wfContext = buildWorkflowContext(latestNodesRef.current, edges, nId);
          const cmd = (dNode.data.dbCommand || 'select').toUpperCase();
          const table = dNode.data.dbTableName || 'my_table';
          const targetFieldRaw = dNode.data.dbTargetField || '';
          
          const customQueryRaw = dNode.data.dbCustomQuery || '';
          
          if (!customQueryRaw && !targetFieldRaw) {
            apiResults[nId] = { status: 'error', code: null, preview: 'No query or target field specified.' };
            layerHasError = true;
            localGlobalError = 'Error: DB Call node missing query configuration.';
            return;
          }

          let query = '';
          
          if (!customQueryRaw && (table === 'my_table' || table.trim() === '')) {
            let isCsvExtraction = false;
            if (targetFieldRaw && targetFieldRaw.includes('.')) {
              const parts = targetFieldRaw.split('.');
              const colName = parts.pop();
              const nodeRefName = parts.join('.'); // e.g. "Upload CSV"
              
              const srcNode = latestNodesRef.current.find(n => 
                n.type === 'uploadCsvNode' && 
                (n.data.nodeName === nodeRefName || (n.data.label || 'Upload CSV') === nodeRefName)
              );
              
              if (srcNode && srcNode.data.csvData) {
                 isCsvExtraction = true;
                 const vals = srcNode.data.csvData.map(row => row[colName]).filter(v => v !== undefined);
                 const outputText = `Extracted CSV Column: [${colName}]\nTotal Rows: ${vals.length}\n\nData:\n${JSON.stringify(vals, null, 2)}`;
                 
                 apiResults[nId] = { status: 'success', code: 200, preview: outputText.slice(0, 1000) };
                 setNodes(nds => nds.map(n => n.id === nId ? { ...n, data: { ...n.data, nodeOutput: outputText } } : n));
                 latestNodesRef.current = latestNodesRef.current.map(n => n.id === nId ? { ...n, data: { ...n.data, nodeOutput: outputText } } : n);
              }
            }
            if (isCsvExtraction) {
              return; // Skip Postgres execution
            }
          }

          if (customQueryRaw) {
             query = resolveTemplate(customQueryRaw, wfContext);
          } else {
            let targetValue = targetFieldRaw;
            if (targetFieldRaw.includes('{{') || targetFieldRaw.includes('${')) {
              targetValue = resolveTemplate(targetFieldRaw, wfContext);
            } else if (targetFieldRaw && wfContext[targetFieldRaw] !== undefined) {
              targetValue = wfContext[targetFieldRaw];
            } else if (targetFieldRaw) {
               // Treat it as literal if not found in context, but fallback to direct template resolution just in case
               targetValue = resolveTemplate(`{{${targetFieldRaw}}}`, wfContext);
               if (targetValue === `{{${targetFieldRaw}}}`) targetValue = targetFieldRaw; // Fallback to literal
            }

            let columnName = 'target_field';
            if (targetFieldRaw && targetFieldRaw.includes('.')) {
               // Extract "name" from "UploadCSV.name"
               columnName = targetFieldRaw.split('.')[1];
            }

            let bulkInsertValues = null;
            let bulkInList = null;
            if (targetFieldRaw && targetFieldRaw.includes('.')) {
              const parts = targetFieldRaw.split('.');
              const cName = parts.pop();
              const nodeRefName = parts.join('.');
              const srcNode = latestNodesRef.current.find(n => 
                n.type === 'uploadCsvNode' && 
                (n.data.nodeName === nodeRefName || (n.data.label || 'Upload CSV') === nodeRefName)
              );
              if (srcNode && srcNode.data.csvData) {
                const vals = srcNode.data.csvData.map(row => row[cName]).filter(v => v !== undefined);
                if (vals.length > 0) {
                   bulkInsertValues = vals.map(v => `('${String(v).replace(/'/g, "''")}')`).join(', ');
                   bulkInList = vals.map(v => `'${String(v).replace(/'/g, "''")}'`).join(', ');
                }
              }
            }

            if (cmd === 'SELECT') {
              if (bulkInList) {
                query = `SELECT * FROM ${table} WHERE ${columnName} IN (${bulkInList});`;
              } else {
                query = `SELECT * FROM ${table} WHERE ${columnName} = '${targetValue}';`;
              }
            } else if (cmd === 'INSERT') {
              if (bulkInsertValues) {
                 query = `INSERT INTO ${table} (${columnName}) VALUES ${bulkInsertValues};`;
              } else {
                 query = `INSERT INTO ${table} (${columnName}) VALUES ('${targetValue}');`;
              }
            } else if (cmd === 'UPDATE') {
              // UPDATE usually requires a WHERE clause differently, keeping default behavior for now
              query = `UPDATE ${table} SET ${columnName} = '${targetValue}';`;
            } else if (cmd === 'DELETE') {
              if (bulkInList) {
                query = `DELETE FROM ${table} WHERE ${columnName} IN (${bulkInList});`;
              } else {
                query = `DELETE FROM ${table} WHERE ${columnName} = '${targetValue}';`;
              }
            }
          }

          // Execute query via backend API
          try {
            const res = await fetch('http://localhost:3001/api/db/execute', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ query })
            });
            const data = await res.json();
            
            let outputText = `Executed DB Query:\n${query}\n\n`;
            if (data.success) {
              outputText += `Rows Returned/Affected: ${data.rowCount || 0}\n\nResult Data:\n${JSON.stringify(data.rows || [], null, 2)}`;
              apiResults[nId] = { status: 'success', code: 200, preview: outputText.slice(0, 1000) };
            } else {
              outputText += `Execution Error:\n${data.error}`;
              apiResults[nId] = { status: 'error', code: 500, preview: outputText.slice(0, 1000) };
              layerHasError = true;
              localGlobalError = `Error executing DB Query: ${data.error}`;
            }

            // Store DB output in node data so the result button can show it
            setNodes(nds => nds.map(n => n.id === nId ? { ...n, data: { ...n.data, nodeOutput: outputText } } : n));
            latestNodesRef.current = latestNodesRef.current.map(n => n.id === nId ? { ...n, data: { ...n.data, nodeOutput: outputText } } : n);
          } catch (err) {
            apiResults[nId] = { status: 'error', code: null, preview: err.message };
            layerHasError = true;
            localGlobalError = `Failed to connect to backend: ${err.message}`;
          }
        });
        await Promise.allSettled(dbPromises);
      }
      dbCallNodeQueue.length = 0;

      // ── AI Agent Node Execution ──
      if (aiAgentQueue.length > 0) {
        const aiConfig = (() => {
          try { return JSON.parse(localStorage.getItem('antigravity_settings') || '{}'); } catch { return {}; }
        })();
        const aiPromises = aiAgentQueue.map(async (nId) => {
          const aiNode = latestNodesRef.current.find(n => n.id === nId);
          if (!aiNode) return;
          const context = buildWorkflowContext(latestNodesRef.current, edges, nId);
          const resolvedPrompt = resolveTemplate(aiNode.data.promptTemplate || '', context);
          if (!resolvedPrompt.trim()) {
            apiResults[nId] = { status: 'error', code: null, preview: 'No prompt configured.' };
            layerHasError = true;
            return;
          }
          try {
            let output = '';
            const provider = aiConfig.provider || 'OpenAI';
            const model = aiConfig.model || '';
            const apiKey = aiConfig.apiKey || '';
            if (!apiKey) throw new Error('No AI API key configured. Please go to Settings and add your key.');

            const res = await fetch('/api/ai/execute', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                provider,
                model,
                apiKey,
                baseUrl: aiConfig.baseUrl,
                prompt: resolvedPrompt
              })
            });
            const data = await res.json().catch(() => ({}));
            if (!res.ok || !data.success) {
              throw new Error(data.error || `HTTP ${res.status}`);
            }
            output = data.output || '';

            // Store AI output in node data
            setNodes(nds => nds.map(n => n.id === nId ? { ...n, data: { ...n.data, nodeOutput: output } } : n));
            latestNodesRef.current = latestNodesRef.current.map(n => n.id === nId ? { ...n, data: { ...n.data, nodeOutput: output } } : n);
            apiResults[nId] = { status: 'success', code: 200, preview: output.slice(0, 200) };
          } catch (err) {
            apiResults[nId] = { status: 'error', code: null, preview: err.message };
            layerHasError = true;
          }
        });
        await Promise.allSettled(aiPromises);
      }
      aiAgentQueue.length = 0;

      if (emailNodeQueue.length > 0) {
        const currentNodes = reactFlowInstance ? reactFlowInstance.getNodes() : latestNodesRef.current;
        const emailPromises = emailNodeQueue.map(async (nId) => {
          const eNode = currentNodes.find(n => n.id === nId);
          if (!eNode) return;
          // Resolve recipient: automatically grab email or fallback to raw config
          const wfContext = buildWorkflowContext(latestNodesRef.current, edges, nId);
          let rawRecipient = eNode.data.recipient || '';
          
          if (!rawRecipient) {
            // Priority: explicit email, then any key ending in .email, then any key ending in (3) representing the 3rd param
            const emailKey = Object.keys(wfContext).find(k => 
              k === 'email' || k === 'email_id' || 
              k.endsWith('.email') || k.endsWith('.email_id') || 
              k.endsWith('(3)')
            );
            if (emailKey) {
              rawRecipient = `{{${emailKey}}}`;
            }
          }
          const email = resolveTemplate(rawRecipient, wfContext).trim();
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

          if (!email) {
             emailResults[nId] = { status: 'error', error: 'The mail is not getting sent: No email_id in workflow context and no recipient configured.' };
             layerHasError = true;
             localGlobalError = 'Error: The mail is not getting sent and status is Failed.';
             return;
          }
          if (!emailRegex.test(email)) {
             emailResults[nId] = { status: 'error', error: `The mail is not getting sent: Invalid email format "${email}"` };
             layerHasError = true;
             localGlobalError = 'Error: The mail is not getting sent and status is Failed.';
             return;
          }

          // Collect Form details & Request ID
          let collectedFormData = [];
          let collectedRequestId = '';
          let collectedAttachments = [];
          const formNodes = currentNodes.filter(n => n.type === 'formNode' || (n.type === 'formTask' && n.data.taskMode === 'form1'));
          formNodes.forEach(fn => {
            if (fn.data.requestId) {
              collectedRequestId = fn.data.requestId;
            }
            if (fn.data.filledData) {
              const fd = fn.data.filledData;
              if (fd.attachments && Array.isArray(fd.attachments)) {
                collectedAttachments = [...collectedAttachments, ...fd.attachments];
              }
            }
          });

          // Collect Manager decision and comments
          let managerDecision = '';
          let managerComments = '';
          const managerNodes = currentNodes.filter(n => n.type === 'managerNode' || (n.type === 'formTask' && n.data.taskMode === 'form2'));
          managerNodes.forEach(mn => {
            if (mn.data.managerStatus === 'submitted') {
              managerDecision = mn.data.managerDecision;
              managerComments = mn.data.managerComments;
            }
          });

          // Build auto-generated plain-text email body from workflow context
          let bodyTpl = eNode.data.emailBodyTemplate || '';
          
          // Fully automatic magic fallback if no template is provided
          if (!bodyTpl) {
             const aiOutputKeys = Object.keys(wfContext).filter(k => k.endsWith('.output'));
             const nameKey = Object.keys(wfContext).find(k => k.endsWith('(1)')); // N2(1) usually the name
             
             if (aiOutputKeys.length > 0) {
               const greeting = nameKey ? `Dear {{${nameKey}}},\n\n` : '';
               bodyTpl = `${greeting}{{${aiOutputKeys[0]}}}`;
             }
          }
          
          let emailBody = resolveTemplate(bodyTpl, wfContext);
          if (!emailBody) {
            const selectedVars = eNode.data.selectedEmailVariables || [];
            const lines = [];
            if (selectedVars.length > 0) {
              selectedVars.forEach(varName => {
                const val = wfContext[varName];
                if (val !== undefined) {
                  lines.push(`${varName}:\n${val}\n`);
                }
              });
            } else {
              // Auto-include all context variables
              Object.entries(wfContext).forEach(([k, v]) => {
                if (!k.includes('.') || k.includes('output')) {
                  lines.push(`${k}:\n${v}\n`);
                }
              });
            }
            emailBody = lines.join('\n---\n\n') || 'Workflow notification.';
          }

          try {
            const res = await fetch('/api/send-email', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                to: email,
                subject: eNode.data.subject || 'Workflow Email',
                body: emailBody,
                formData: collectedFormData,
                attachments: collectedAttachments,
                requestId: collectedRequestId,
                managerDecision,
                managerComments
              }),
            });
            const result = await res.json();
            if (result.success) {
              emailResults[nId] = { status: 'success', message: result.message };
            } else {
              emailResults[nId] = { status: 'error', error: result.error || 'The mail is not getting sent.' };
              layerHasError = true;
              localGlobalError = `Error: The mail is not getting sent to ${email} and status is Failed.`;
            }
          } catch (err) {
            emailResults[nId] = { status: 'error', error: `The mail is not getting sent to ${email}: ${err.message}` };
            layerHasError = true;
            localGlobalError = `Error: The mail is not getting sent to ${email} and status is Failed.`;
          }
        });
        await Promise.allSettled(emailPromises);
      }
      emailNodeQueue.length = 0;

      if (smsNodeQueue.length > 0) {
        const currentNodes = reactFlowInstance ? reactFlowInstance.getNodes() : latestNodesRef.current;
        const smsPromises = smsNodeQueue.map(async (nId) => {
          const sNode = currentNodes.find(n => n.id === nId);
          if (!sNode) return;
          const phone = sNode.data.phoneNumber || '';
          const phoneRegex = /^\+?[\d\s-]{7,20}$/;

          if (!phone) {
             emailResults[nId] = { status: 'error', error: 'The SMS is not getting sent: No phone number configured.' };
             layerHasError = true;
             localGlobalError = 'Error: The SMS is not getting sent and status is Failed.';
             return;
          }
          if (!phoneRegex.test(phone)) {
             emailResults[nId] = { status: 'error', error: `The SMS is not getting sent: Invalid phone number format "${phone}"` };
             layerHasError = true;
             localGlobalError = 'Error: The SMS is not getting sent and status is Failed.';
             return;
          }

          try {
            const res = await fetch('/api/send-sms', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                to: phone,
                message: sNode.data.smsMessage || 'Your workflow request has been processed.'
              }),
            });
            const result = await res.json();
            if (result.success) {
              emailResults[nId] = { status: 'success', message: result.message };
            } else {
              emailResults[nId] = { status: 'error', error: result.error || 'The SMS is not getting sent.' };
              layerHasError = true;
              localGlobalError = `Error: The SMS is not getting sent to ${phone} and status is Failed.`;
            }
          } catch (err) {
            emailResults[nId] = { status: 'error', error: `The SMS is not getting sent to ${phone}: ${err.message}` };
            layerHasError = true;
            localGlobalError = `Error: The SMS is not getting sent to ${phone} and status is Failed.`;
          }
        });
        await Promise.allSettled(smsPromises);
      }
      smsNodeQueue.length = 0;

      await new Promise((r) => setTimeout(r, 1200));

      const now = Date.now();
      const currentNodesState = reactFlowInstance ? reactFlowInstance.getNodes() : latestNodesRef.current;

      setNodes(nds => nds.map(n => {
        if (nextLayer.includes(n.id)) {
          const nodeTat = ((now - executionStartTime) / 1000).toFixed(2);
          const extra = {};
          
          // Build input context for display
          const inputCtx = buildWorkflowContext(currentNodesState, edges, n.id);
          extra.execInputContext = inputCtx;
          extra.execOutputData = 'No output';

          if (n.type === 'formNode' || n.type === 'formTask') {
             if (taskResults[n.id] && taskResults[n.id].status === 'success') {
                extra.execOutputData = taskResults[n.id].data || n.data.filledData || 'Form completed';
             }
          } else if (n.type === 'managerNode') {
             if (taskResults[n.id] && taskResults[n.id].status === 'success') {
                extra.execOutputData = taskResults[n.id].data || { decision: n.data.managerDecision, comments: n.data.managerComments };
             }
          }
          
          if (n.type === 'aiAgent' && apiResults[n.id]) {
             extra.execOutputData = apiResults[n.id].preview || 'No output';
          }

          if (apiResults[n.id]) {
            extra.apiStatus = apiResults[n.id].status;
            extra.apiResponseCode = apiResults[n.id].code;
            extra.apiResponsePreview = apiResults[n.id].preview;
            if (apiResults[n.id].status === 'error') {
               extra.execStatus = 'error';
               extra.execError = apiResults[n.id].preview;
               extra.execOutputData = apiResults[n.id].preview || 'No output as execution failed';
            } else if (n.type === 'apiCall' || n.type === 'dbCallNode') {
               extra.execOutputData = apiResults[n.id].preview;
            }
          } else if (genericResults[n.id]) {
            extra.execStatus = genericResults[n.id].status;
            extra.execError = genericResults[n.id].preview;
            extra.execOutputData = genericResults[n.id].preview;
          }
          
          if (n.type === 'uploadCsvNode') {
             const sampleData = n.data.csvData?.[0] ? JSON.stringify(n.data.csvData[0], null, 2) : 'No data row found';
             extra.execOutputData = `CSV File: ${n.data.csvFileName || 'unknown'}\n\nHeaders Extracted:\n${(n.data.csvHeaders || []).join(', ') || 'None'}\n\nSample Data (Row 1):\n${sampleData}`;
          } else if (n.type === 'googleSheetsNode') {
             extra.execOutputData = `Data linked from Google Sheet URL`;
          }
          
          if (taskResults[n.id] && taskResults[n.id].status === 'error') {
             extra.execStatus = 'error';
             extra.execError = taskResults[n.id].error;
             extra.execOutputData = 'No output as execution failed';
          }

          if (emailResults[n.id]) {
            if (emailResults[n.id].status === 'error') {
               extra.execStatus = 'error';
               extra.execError = emailResults[n.id].error;
               extra.execOutputData = 'No output as execution failed';
            } else {
               extra.execOutputData = emailResults[n.id].message || 'Sent successfully';
            }
          }

          return { ...n, data: { ...n.data, execStatus: extra.execStatus || 'completed', execTat: nodeTat, ...extra } };
        }
        return n;
      }));

      // if layer has an error, halt the execution loop
      if (layerHasError) {
         currentLayer = [];
         globalRunStatus = 'Failed';
      } else {
         currentLayer = nextLayer;
      }
    }

    const executionEndTime = Date.now();
    const tat = ((executionEndTime - executionStartTime) / 1000).toFixed(2);
    
    if (localGlobalError) {
       setGlobalExecutionError(localGlobalError);
    }

    await new Promise((r) => setTimeout(r, 2500));
    setEdges((eds) => eds.map((e) => ({
      ...e,
      animated: false,
      style: { strokeWidth: 2, stroke: '#7c3aed' }
    })));

    const runRecord = {
      id: uuidv4(),
      runNumber: executionRuns.length + 1,
      startedAt: new Date(executionStartTime).toISOString(),
      completedAt: new Date(executionEndTime).toISOString(),
      tat: tat,
      status: globalRunStatus,
      nodesVisited: visitedNodes.size,
      steps: stepsExecuted,
      version: workflowVersion,
    };
    setAllExecutionRuns(prev => ({
      ...prev,
      [currentWorkflowId]: [runRecord, ...(prev[currentWorkflowId] || [])]
    }));
    setIsExecuting(false);
    setNodes(nds => nds.map(n => ({
      ...n,
      data: {
        ...n.data,
        isExecuting: false
      }
    })));
    setSelectedRunIndex(null);
    setShowRunDetails(false);
    flashToast(`Execution ${globalRunStatus.toLowerCase()} in ${tat}s`);
  }, [edges, isExecuting, currentWorkflowId, executionRuns.length, workflowVersion]);

  const handleTestConnection = async () => {
    setSettingsError('');
    setSettingsSuccessMessage('');
    setIsTestingKey(true);

    try {
      const res = await fetch('/api/ai/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          provider: settingsProvider,
          model: settingsModel,
          apiKey: settingsApiKey,
          baseUrl: settingsBaseUrl
        })
      });
      
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.success) {
        setSettingsSuccessMessage('Successfully connected!');
      } else {
        throw new Error(data.error || `Status: ${res.status}`);
      }
    } catch (err) {
      setSettingsError(`Failed to connect: ${err.message}`);
    } finally {
      setIsTestingKey(false);
    }
  };

  const handleSaveAISettings = () => {
    localStorage.setItem('antigravity_settings', JSON.stringify({
      provider: settingsProvider,
      apiKey: settingsApiKey,
      baseUrl: settingsBaseUrl,
      model: settingsModel
    }));
    localStorage.setItem('antigravity_ai_config', JSON.stringify({
      provider: settingsProvider,
      baseUrl: settingsBaseUrl,
      apiKey: settingsApiKey
    }));
    flashToast('AI Configuration Saved!');
  };

  const handleSaveDbSettings = () => {
    localStorage.setItem('antigravity_db_config', JSON.stringify({
      host: dbSettingsHost,
      port: dbSettingsPort,
      user: dbSettingsUser,
      pwd: dbSettingsPwd,
      dbName: dbSettingsName
    }));
    flashToast('Database Configuration Saved!');
  };

  const fillFormMatch = currentHash.match(/^#\/fill-form\/([^/]+)\/([^/]+)/);
  if (fillFormMatch) {
    const nodeId = fillFormMatch[1];
    const requestId = fillFormMatch[2];
    return <FormFillView nodeId={nodeId} requestId={requestId} />;
  }

  return (
    <div className="app-container">
      {/* ── Top Navbar ── */}
      <header className="navbar">
        <div className="nav-left">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="url(#grad)" strokeWidth="2">
            <defs>
              <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#7c3aed" />
                <stop offset="100%" stopColor="#2dd4bf" />
              </linearGradient>
            </defs>
            <circle cx="12" cy="12" r="10" />
            <path d="M12 2a15 15 0 0 1 4 10 15 15 0 0 1-4 10 15 15 0 0 1-4-10A15 15 0 0 1 12 2z" />
            <path d="M2 12h20" />
          </svg>
          <input 
            type="text" 
            className="workflow-title-input" 
            value={workflowTitle} 
            onChange={(e) => setWorkflowTitle(e.target.value)} 
          />
          {appMode !== 'execution' && <span className="version-badge">v{workflowVersion.toFixed(1)}</span>}
        </div>
        <div className="nav-center">
          <div className="mode-toggle">
            <button 
              className={`mode-btn ${appMode === 'editor' ? 'active' : ''}`} 
              onClick={() => {
                setAppMode('editor');
                stopExecutionRef.current = true;
                setIsExecuting(false);

                // Resolve all active waiting execution promises to unblock the loop immediately
                Object.keys(formResolvers.current).forEach(nId => {
                  if (formResolvers.current[nId]) formResolvers.current[nId]();
                });
                Object.keys(managerResolvers.current).forEach(nId => {
                  if (managerResolvers.current[nId]) managerResolvers.current[nId]();
                });
                Object.keys(emailResolvers.current).forEach(nId => {
                  if (emailResolvers.current[nId]) emailResolvers.current[nId]();
                });
                formResolvers.current = {};
                managerResolvers.current = {};
                emailResolvers.current = {};

                // Clear execution status and previous runtime data from nodes
                setNodes(nds => nds.map(n => {
                  const cleanedData = {
                    ...n.data,
                    appMode: 'editor',
                    execStatus: undefined,
                    execTat: undefined,
                    execError: undefined
                  };
                  if (n.type === 'formNode' || (n.type === 'formTask' && n.data.taskMode === 'form1')) {
                    cleanedData.formStatus = 'draft';
                    cleanedData.filledData = null;
                    cleanedData.requestId = '';
                  }
                  if (n.type === 'managerNode' || (n.type === 'formTask' && n.data.taskMode === 'form2')) {
                    cleanedData.managerStatus = 'pending';
                    cleanedData.managerDecision = '';
                    cleanedData.managerComments = '';
                  }
                  if (n.type === 'apiCall') {
                    cleanedData.apiStatus = 'idle';
                    cleanedData.apiResponseCode = null;
                    cleanedData.apiResponsePreview = '';
                  }
                  return { ...n, data: cleanedData };
                }));
              }}
            >
              Editor
            </button>
            <button 
              className={`mode-btn ${appMode === 'execution' ? 'active' : ''}`} 
              onClick={() => {
                setAppMode('execution');
                setSelectedNode(null);
                // Set appMode to execution inside all nodes
                setNodes(nds => nds.map(n => ({
                  ...n,
                  data: {
                    ...n.data,
                    appMode: 'execution'
                  }
                })));
              }}
            >
              Execution
            </button>
          </div>
        </div>
        <div className="nav-right">
          <div className="toolbar-actions">
            <button className="toolbar-btn" onClick={() => setIsModalOpen(true)} id="btn-open">
              Open
            </button>
            <button className="toolbar-btn" onClick={handleNew} id="btn-new">
              New
            </button>
            <button className="toolbar-btn" onClick={handleSave} id="btn-save">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" />
                <polyline points="17 21 17 13 7 13 7 21" />
                <polyline points="7 3 7 8 15 8" />
              </svg>
              Save
            </button>
            <span style={{width: '1px', height: '24px', background: 'var(--border)', margin: '0 8px'}}></span>
            <button className="toolbar-btn" onClick={handleImport} id="btn-import">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                <polyline points="7 10 12 15 17 10" />
                <line x1="12" y1="15" x2="12" y2="3" />
              </svg>
              Upload
            </button>
            <button className="toolbar-btn primary" onClick={handleExport} id="btn-export">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                <polyline points="17 8 12 3 7 8" />
                <line x1="12" y1="3" x2="12" y2="15" />
              </svg>
              Export
            </button>
            <button className="toolbar-btn" onClick={() => setIsSettingsOpen(true)} id="btn-settings">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="3"></circle>
                <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
              </svg>
              Settings
            </button>
          </div>
        </div>
      </header>

      <div className={`app-shell ${appMode === 'execution' ? 'execution-mode' : ''}`} id="app-shell">
        {/* ── Left sidebar ── */}
        {appMode === 'editor' && <NodePanel />}

        {/* ── Execution Sidebar ── */}
        {appMode === 'execution' && (
          <div className="execution-panel">
            <div className="exec-panel-header">
              <h3 className="exec-panel-title">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <polygon points="5 3 19 12 5 21 5 3" />
                </svg>
                Execution
              </h3>
            </div>

            {/* Version / Iteration Info */}
            <div className="exec-section">
              <div className="exec-section-label">Workflow Info</div>
              <div className="exec-info-card">
                <div className="exec-info-row">
                  <span className="exec-info-key">Version</span>
                  <span className="exec-info-value version-pill">v{workflowVersion.toFixed(1)}</span>
                </div>
                <div className="exec-info-row">
                  <span className="exec-info-key">Iteration</span>
                  <span className="exec-info-value">{executionRuns.length}</span>
                </div>
                <div className="exec-info-row">
                  <span className="exec-info-key">Status</span>
                  <span className={`exec-status-chip ${isExecuting ? 'running' : 'idle'}`}>
                    {isExecuting ? '● Running' : '● Idle'}
                  </span>
                </div>
              </div>
            </div>

            {/* Run History */}
            <div className="exec-section">
              <div className="exec-section-label">Run History</div>
              {executionRuns.length === 0 ? (
                <div className="exec-empty">No executions yet. Click ▶ on a Start node to begin.</div>
              ) : (
                <div className="exec-runs-list">
                  {executionRuns.map((run, idx) => (
                    <div key={run.id} className={`exec-run-item ${selectedRunIndex === idx ? 'active' : ''}`}>
                      <div className="exec-run-header">
                        <span className="exec-run-number">Run #{run.runNumber}</span>
                        <span className="exec-run-version">v{run.version?.toFixed(1)}</span>
                      </div>
                      <div className="exec-run-meta">
                        <span className={`exec-run-status ${run.status === 'Failed' ? 'error' : 'completed'}`}>
                          {run.status === 'Failed' ? '✕' : '✓'} {run.status}
                        </span>
                        <span className="exec-run-tat">TAT: {run.tat}s</span>
                      </div>
                      <div className="exec-run-actions">
                        <button
                          className="exec-eye-btn"
                          onClick={() => {
                            setSelectedRunIndex(idx);
                            setShowRunDetails(true);
                          }}
                          title="View details"
                        >
                          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                            <circle cx="12" cy="12" r="3" />
                          </svg>
                          Details
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              
              {/* Display error message below runtime history */}
              {globalExecutionError && (
                 <div style={{ marginTop: '16px', padding: '12px', background: 'var(--bg-card)', border: '1px solid rgba(239,68,68,0.5)', borderRadius: '6px', color: '#ef4444', fontSize: '13px', fontWeight: '500' }}>
                   {globalExecutionError}
                 </div>
              )}
            </div>
          </div>
        )}

        {/* ── Data Source Picker Modal (for Form 2 previous-node mapping) ── */}
        {showDataSourcePicker && (
          <div className="modal-overlay" style={{ zIndex: 99998 }} onClick={() => setShowDataSourcePicker(false)}>
            <div className="modal-content" style={{ width: '380px', maxWidth: '90vw' }} onClick={(e) => e.stopPropagation()}>
              <div className="modal-header" style={{ borderBottom: '1px solid var(--border)' }}>
                <h2 style={{ fontSize: '15px', fontWeight: 600 }}>Select Data Source</h2>
                <button className="btn-close" onClick={() => setShowDataSourcePicker(false)}>✕</button>
              </div>
              <div className="modal-body" style={{ padding: '12px 16px' }}>
                <p style={{ fontSize: '12px', color: 'var(--text-muted)', marginBottom: '12px' }}>Choose which form node's data to use for the Manager Review:</p>
                {nodes
                  .filter(n => (n.type === 'formNode' || (n.type === 'formTask' && n.data.taskMode === 'form1')) && n.data.filledData)
                  .map(fNode => (
                    <button
                      key={fNode.id}
                      onClick={() => {
                        setSelectedDataSource(fNode);
                        setShowDataSourcePicker(false);
                        // Trigger review on first Form 2 node
                        const reviewNode = nodes.find(n =>
                          n.type === 'managerNode' || (n.type === 'formTask' && n.data.taskMode === 'form2')
                        );
                        if (reviewNode) {
                          setNodes(nds => nds.map(n => {
                            if (n.id === reviewNode.id) {
                              return { ...n, data: { ...n.data, execStatus: 'running' } };
                            }
                            return n;
                          }));
                        }
                      }}
                      style={{
                        width: '100%',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '10px',
                        padding: '10px 12px',
                        background: 'var(--bg-hover)',
                        border: '1px solid var(--border)',
                        borderRadius: '8px',
                        color: 'var(--text-primary)',
                        fontSize: '12px',
                        cursor: 'pointer',
                        marginBottom: '8px',
                        transition: 'all 0.15s'
                      }}
                      onMouseEnter={(e) => e.currentTarget.style.borderColor = 'var(--accent-primary)'}
                      onMouseLeave={(e) => e.currentTarget.style.borderColor = 'var(--border)'}
                    >
                      <span style={{ fontSize: '18px' }}>📋</span>
                      <div style={{ textAlign: 'left' }}>
                        <div style={{ fontWeight: 600 }}>{fNode.data.label || 'Form Node'}</div>
                        <div style={{ fontSize: '10px', color: 'var(--text-muted)', marginTop: '2px' }}>
                          {fNode.data.filledData?.name || 'Filled'} — Req: {fNode.data.requestId || '—'}
                        </div>
                      </div>
                    </button>
                  ))
                }
              </div>
            </div>
          </div>
        )}

        {/* ── Canvas ── */}
        <div className="canvas-wrapper" ref={reactFlowWrapper}>
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={appMode === 'editor' ? onNodesChange : undefined}
            onEdgesChange={appMode === 'editor' ? onEdgesChange : undefined}
            onConnect={appMode === 'editor' ? onConnect : undefined}
            onNodeClick={appMode === 'editor' ? onNodeClick : (e, node) => {
              const isStart = node.data?.nodeType === 'start' || (node.data?.label || '').toLowerCase() === 'start';
              if (isStart && !isExecuting) handleTrigger(node.id);
            }}
            onNodeDragStop={appMode === 'editor' ? onNodeDragStop : undefined}
            onPaneClick={onPaneClick}
            onDrop={appMode === 'editor' ? onDrop : undefined}
            onDragOver={appMode === 'editor' ? onDragOver : undefined}
            onInit={setReactFlowInstance}
            nodeTypes={nodeTypes}
            defaultViewport={{ x: 50, y: 80, zoom: 0.85 }}
            defaultEdgeOptions={{
              type: 'smoothstep',
              animated: false,
              style: { strokeWidth: 2, stroke: '#7c3aed' },
            }}
            proOptions={{ hideAttribution: true }}
            nodesDraggable={appMode === 'editor'}
            nodesConnectable={appMode === 'editor'}
            elementsSelectable={true}
          >
            <Background color="#2e2e48" gap={20} size={1} />
            <Controls
              showInteractive={false}
              style={{ background: '#1c1c2e', borderColor: '#2e2e48' }}
            />
            <MiniMap
              nodeColor={minimapNodeColor}
              nodeStrokeWidth={3}
              maskColor="rgba(0,0,0,0.2)"
              pannable
              zoomable
            />
          </ReactFlow>
        </div>

        {/* ── Right properties panel ── */}
        {appMode === 'editor' && selectedNode && (
          <PropertiesPanel
            selectedNode={selectedNode}
            onUpdateNode={handleUpdateNode}
            onClose={() => setSelectedNode(null)}
            onDeleteNode={handleDeleteNode}
            allNodes={nodes}
            allEdges={edges}
            onOpenDbSettings={() => setIsSettingsOpen(true)}
          />
        )}

        {/* ── Execution Details Overlay ── */}
        {showRunDetails && selectedRunIndex !== null && executionRuns[selectedRunIndex] && (
          <div className="exec-details-overlay" onClick={() => setShowRunDetails(false)}>
            <div className="exec-details-modal" onClick={(e) => e.stopPropagation()}>
              <div className="exec-details-header">
                <h3>Run #{executionRuns[selectedRunIndex].runNumber} — Details</h3>
                <button className="exec-details-close" onClick={() => setShowRunDetails(false)}>✕</button>
              </div>
              <div className="exec-details-body">
                <div className="exec-detail-grid">
                  <div className="exec-detail-card tat-card">
                    <div className="exec-detail-card-icon">
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <circle cx="12" cy="12" r="10" />
                        <polyline points="12 6 12 12 16 14" />
                      </svg>
                    </div>
                    <div className="exec-detail-card-info">
                      <span className="exec-detail-card-label">Turn Around Time</span>
                      <span className="exec-detail-card-value tat-value">{executionRuns[selectedRunIndex].tat}s</span>
                    </div>
                  </div>
                  <div className="exec-detail-card">
                    <div className={`exec-detail-card-icon status-icon ${executionRuns[selectedRunIndex].status === 'Failed' ? 'error' : ''}`}>
                      {executionRuns[selectedRunIndex].status === 'Failed' ? (
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <circle cx="12" cy="12" r="10" />
                          <line x1="15" y1="9" x2="9" y2="15" />
                          <line x1="9" y1="9" x2="15" y2="15" />
                        </svg>
                      ) : (
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
                          <polyline points="22 4 12 14.01 9 11.01" />
                        </svg>
                      )}
                    </div>
                    <div className="exec-detail-card-info">
                      <span className="exec-detail-card-label">Status</span>
                      <span className={`exec-detail-card-value status-value ${executionRuns[selectedRunIndex].status === 'Failed' ? 'error' : ''}`}>{executionRuns[selectedRunIndex].status}</span>
                    </div>
                  </div>
                  <div className="exec-detail-card">
                    <div className="exec-detail-card-icon nodes-icon">
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <rect x="3" y="3" width="7" height="7" />
                        <rect x="14" y="3" width="7" height="7" />
                        <rect x="14" y="14" width="7" height="7" />
                        <rect x="3" y="14" width="7" height="7" />
                      </svg>
                    </div>
                    <div className="exec-detail-card-info">
                      <span className="exec-detail-card-label">Nodes Visited</span>
                      <span className="exec-detail-card-value">{executionRuns[selectedRunIndex].nodesVisited}</span>
                    </div>
                  </div>
                  <div className="exec-detail-card">
                    <div className="exec-detail-card-icon time-icon">
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
                        <line x1="16" y1="2" x2="16" y2="6" />
                        <line x1="8" y1="2" x2="8" y2="6" />
                        <line x1="3" y1="10" x2="21" y2="10" />
                      </svg>
                    </div>
                    <div className="exec-detail-card-info">
                      <span className="exec-detail-card-label">Started At</span>
                      <span className="exec-detail-card-value">{new Date(executionRuns[selectedRunIndex].startedAt).toLocaleTimeString()}</span>
                    </div>
                  </div>
                </div>

                {/* Step trace table */}
                <div className="exec-steps-section">
                  <h4>Execution Trace</h4>
                  <table className="exec-steps-table">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Node</th>
                        <th>Time</th>
                      </tr>
                    </thead>
                    <tbody>
                      {executionRuns[selectedRunIndex].steps.map((step, i) => (
                        <tr key={i}>
                          <td>{i + 1}</td>
                          <td>{step.label}</td>
                          <td>{new Date(step.time).toLocaleTimeString()}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── Toast ── */}
        {showToast && (
          <div className={`toast ${showToast.type}`}>
            {showToast.message}
          </div>
        )}

        {/* ── Open Workflow Modal ── */}
        {isModalOpen && (
          <div className="modal-overlay" onClick={() => setIsModalOpen(false)}>
            <div className="modal-content" onClick={(e) => e.stopPropagation()}>
              <div className="modal-header">
                <h2>Open Project</h2>
                <div className="modal-controls">
                  <label style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Sort by:</label>
                  <select 
                    className="modal-sort" 
                    value={sortOrder} 
                    onChange={(e) => setSortOrder(e.target.value)}
                  >
                    <option value="recent">Most Recent</option>
                    <option value="alphabetical">Alphabetical</option>
                  </select>
                  <button className="btn-close" onClick={() => setIsModalOpen(false)}>✕</button>
                </div>
              </div>
              <div className="modal-body">
                {(() => {
                  let flows = JSON.parse(localStorage.getItem('antigravity_workflows_array') || '[]');
                  if (flows.length === 0) return <div className="modal-empty">No saved workflows found.</div>;
                  
                  flows.sort((a, b) => {
                    if (sortOrder === 'recent') {
                      return new Date(b.savedAt) - new Date(a.savedAt);
                    } else {
                      return (a.name || '').localeCompare(b.name || '');
                    }
                  });

                  return flows.map(f => (
                    <div key={f.id} className={`modal-item ${f.id === currentWorkflowId ? 'active' : ''}`}>
                      <div className="modal-item-info">
                        <h4>{f.name || 'Untitled'} <span>v{f.version?.toFixed(1) || '1.0'}</span></h4>
                        <p>Saved: {new Date(f.savedAt).toLocaleString()}</p>
                      </div>
                      <div className="modal-item-actions">
                        <button className="btn-load" onClick={() => handleLoad(f)}>Load</button>
                        <button className="btn-trash" onClick={() => handleDeleteFlow(f.id)}>Delete</button>
                      </div>
                    </div>
                  ));
                })()}
              </div>
            </div>
          </div>
        )}

        {/* ── Node Result Modal ── */}
        {selectedResultNode && (() => {
          const node = nodes.find(n => n.id === selectedResultNode);
          if (!node) return null;
          
          let inputDataStr = 'No inputs';
          if (node.data.execInputContext && Object.keys(node.data.execInputContext).length > 0) {
            try { inputDataStr = JSON.stringify(node.data.execInputContext, null, 2); } 
            catch { inputDataStr = String(node.data.execInputContext); }
          }
          
          let outputDataStr = 'No output';
          if (node.data.execOutputData) {
             if (typeof node.data.execOutputData === 'object') {
                try { outputDataStr = JSON.stringify(node.data.execOutputData, null, 2); }
                catch { outputDataStr = String(node.data.execOutputData); }
             } else {
                outputDataStr = String(node.data.execOutputData);
             }
          }

          return (
            <div className="modal-overlay" onClick={() => setSelectedResultNode(null)}>
              <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ width: '600px', maxWidth: '90vw' }}>
                <div className="modal-header">
                  <h2>{node.data.label || 'Node'} - Execution Results</h2>
                  <div className="modal-controls">
                    <button className="btn-close" onClick={() => setSelectedResultNode(null)}>✕</button>
                  </div>
                </div>
                <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                  <div>
                    <h3 style={{ fontSize: '14px', marginBottom: '8px', color: 'var(--text-secondary)' }}>Input Context</h3>
                    <pre style={{ background: 'var(--bg-surface)', padding: '12px', borderRadius: '8px', fontSize: '12px', maxHeight: '200px', overflow: 'auto', border: '1px solid var(--border)' }}>
                      {inputDataStr}
                    </pre>
                  </div>
                  <div>
                    <h3 style={{ fontSize: '14px', marginBottom: '8px', color: 'var(--text-secondary)' }}>Output Result</h3>
                    <pre style={{ background: 'color-mix(in srgb, var(--node-accent, #3b82f6) 5%, var(--bg-surface))', padding: '12px', borderRadius: '8px', fontSize: '12px', maxHeight: '300px', overflow: 'auto', border: '1px solid color-mix(in srgb, var(--node-accent, #3b82f6) 20%, var(--border))', whiteSpace: 'pre-wrap' }}>
                      {outputDataStr}
                    </pre>
                  </div>
                </div>
              </div>
            </div>
          );
        })()}

        {/* ── Settings Modal ── */}
        {isSettingsOpen && (
          <div className="modal-overlay" onClick={() => !isTestingKey && setIsSettingsOpen(false)}>
            <div className="modal-content settings-modal" onClick={(e) => e.stopPropagation()}>
              <div className="modal-header">
                <h2>Global Settings</h2>
                <div className="modal-controls">
                  <button className="btn-close" onClick={() => !isTestingKey && setIsSettingsOpen(false)} disabled={isTestingKey}>✕</button>
                </div>
              </div>
              <div className="modal-body settings-body" style={{ padding: '16px' }}>
                <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: '8px', padding: '16px', marginBottom: '20px' }}>
                  <h3 style={{ fontSize: '15px', fontWeight: 600, marginBottom: '16px' }}>AI Model Configuration</h3>
                <div className="settings-field">
                  <label>Provider</label>
                  <select 
                    value={settingsProvider} 
                    onChange={(e) => {
                      setSettingsProvider(e.target.value);
                      setSettingsModel(''); // Reset model when provider changes
                      setSettingsError('');
                      setSettingsSuccessMessage('');
                    }}
                    disabled={isTestingKey}
                  >
                    <option value="Groq">Groq</option>
                    <option value="OpenAI">OpenAI</option>
                    <option value="Gemini">Gemini</option>
                    <option value="Anthropic">Anthropic</option>
                    <option value="Custom">Custom (OpenAI Compatible)</option>
                    <option value="MockAPI">MockAPI (Testing)</option>
                  </select>
                </div>

                <div className="settings-field">
                  <label>Model</label>
                  {settingsProvider === 'Groq' ? (
                    <select value={settingsModel} onChange={e => setSettingsModel(e.target.value)}>
                      <option value="">-- Default (llama-3.1-8b-instant) --</option>
                      <option value="llama-3.1-8b-instant">llama-3.1-8b-instant</option>
                      <option value="llama-3.1-70b-versatile">llama-3.1-70b-versatile</option>
                      <option value="llama3-8b-8192">llama3-8b-8192</option>
                      <option value="llama3-70b-8192">llama3-70b-8192</option>
                      <option value="gemma2-9b-it">gemma2-9b-it</option>
                    </select>
                  ) : settingsProvider === 'OpenAI' ? (
                    <select value={settingsModel} onChange={e => setSettingsModel(e.target.value)}>
                      <option value="">-- Default (gpt-4o) --</option>
                      <option value="gpt-4o">gpt-4o</option>
                      <option value="gpt-4o-mini">gpt-4o-mini</option>
                      <option value="gpt-4-turbo">gpt-4-turbo</option>
                    </select>
                  ) : settingsProvider === 'Gemini' ? (
                    <select value={settingsModel} onChange={e => setSettingsModel(e.target.value)}>
                      <option value="">-- Default (gemini-1.5-pro) --</option>
                      <option value="gemini-1.5-pro">gemini-1.5-pro</option>
                      <option value="gemini-1.5-flash">gemini-1.5-flash</option>
                    </select>
                  ) : (
                    <input 
                      type="text" 
                      placeholder="e.g. custom-model-name" 
                      value={settingsModel}
                      onChange={e => setSettingsModel(e.target.value)}
                    />
                  )}
                </div>

                {['Custom', 'MockAPI'].includes(settingsProvider) && (
                  <div className="settings-field">
                    <label>Base URL</label>
                    <input 
                      type="text" 
                      placeholder="e.g. http://localhost:11434/v1" 
                      value={settingsBaseUrl}
                      onChange={(e) => {
                        setSettingsBaseUrl(e.target.value);
                        setSettingsError('');
                        setSettingsSuccessMessage('');
                      }}
                      disabled={isTestingKey}
                    />
                  </div>
                )}

                {settingsProvider !== 'MockAPI' && (
                  <div className="settings-field">
                    <label>API Key</label>
                    <input 
                      type="password" 
                      placeholder={`Enter your ${settingsProvider} API Key`}
                      value={settingsApiKey}
                      onChange={(e) => {
                        setSettingsApiKey(e.target.value);
                        setSettingsError('');
                        setSettingsSuccessMessage('');
                      }}
                      disabled={isTestingKey}
                    />
                  </div>
                )}

                {settingsError && (
                  <div className="settings-error">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <circle cx="12" cy="12" r="10"></circle>
                      <line x1="12" y1="8" x2="12" y2="12"></line>
                      <line x1="12" y1="16" x2="12.01" y2="16"></line>
                    </svg>
                    {settingsError}
                  </div>
                )}

                {settingsSuccessMessage && (
                  <div className="settings-success" style={{
                    display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 12px',
                    background: 'color-mix(in srgb, #22c55e 10%, var(--bg-card))',
                    border: '1px solid color-mix(in srgb, #22c55e 30%, transparent)',
                    borderRadius: 'var(--radius-sm)', color: '#4ade80', fontSize: '12px', fontWeight: 500
                  }}>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                      <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    </svg>
                    {settingsSuccessMessage}
                  </div>
                )}
                
                <div className="settings-actions" style={{ display: 'flex', gap: '8px', justifyContent: 'flex-end', marginTop: '16px' }}>
                  <button 
                    className="btn-test-settings" 
                    onClick={handleTestConnection}
                    disabled={!settingsApiKey || isTestingKey}
                    style={{
                      padding: '10px 16px',
                      background: 'var(--bg-secondary)',
                      color: 'var(--text-primary)',
                      border: '1px solid var(--border)',
                      borderRadius: 'var(--radius-sm)',
                      cursor: 'pointer',
                      fontSize: '13px',
                      fontWeight: 600,
                      display: 'flex',
                      alignItems: 'center',
                      gap: '6px'
                    }}
                  >
                    {isTestingKey && (
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="spinner" style={{ animation: 'spinStatus 1s linear infinite' }}>
                        <path d="M21 12a9 9 0 1 1-6.219-8.56"></path>
                      </svg>
                    )}
                    {isTestingKey ? 'Connecting...' : 'Test'}
                  </button>
                  <button 
                    className="btn-save-settings" 
                    onClick={handleSaveAISettings}
                    disabled={isTestingKey}
                  >
                    Save
                  </button>
                </div>
              </div>

              <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: '8px', padding: '16px' }}>
                <h3 style={{ fontSize: '15px', fontWeight: 600, marginBottom: '16px' }}>Database Configuration</h3>

                <div className="settings-field">
                  <label>Host</label>
                  <input 
                    type="text" 
                    placeholder="e.g. localhost" 
                    value={dbSettingsHost}
                    onChange={(e) => setDbSettingsHost(e.target.value)}
                  />
                </div>

                <div className="settings-field">
                  <label>Port</label>
                  <input 
                    type="text" 
                    placeholder="e.g. 5432" 
                    value={dbSettingsPort}
                    onChange={(e) => setDbSettingsPort(e.target.value)}
                  />
                </div>

                <div className="settings-field">
                  <label>User</label>
                  <input 
                    type="text" 
                    placeholder="Database User" 
                    value={dbSettingsUser}
                    onChange={(e) => setDbSettingsUser(e.target.value)}
                  />
                </div>

                <div className="settings-field">
                  <label>Password</label>
                  <input 
                    type="password" 
                    placeholder="Database Password" 
                    value={dbSettingsPwd}
                    onChange={(e) => setDbSettingsPwd(e.target.value)}
                  />
                </div>

                <div className="settings-field">
                  <label>DB Name</label>
                  <input 
                    type="text" 
                    placeholder="Database Name" 
                    value={dbSettingsName}
                    onChange={(e) => setDbSettingsName(e.target.value)}
                  />
                </div>

                <div className="settings-actions" style={{ display: 'flex', gap: '8px', justifyContent: 'flex-end', marginTop: '16px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginRight: 'auto' }}>
                    {dbConnectionStatus === 'loading' && <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Testing...</span>}
                    {dbConnectionStatus === 'success' && <span style={{ fontSize: '12px', color: '#22c55e', fontWeight: 600 }}>Connection Successful!</span>}
                  </div>
                  <button 
                    className="btn-test-settings" 
                    onClick={() => {
                      setDbConnectionStatus('loading');
                      setTimeout(() => setDbConnectionStatus('success'), 1000);
                    }}
                    style={{
                      padding: '10px 16px',
                      background: 'var(--bg-secondary)',
                      color: 'var(--text-primary)',
                      border: '1px solid var(--border)',
                      borderRadius: 'var(--radius-sm)',
                      cursor: 'pointer',
                      fontSize: '13px',
                      fontWeight: 600,
                      display: 'flex',
                      alignItems: 'center',
                      gap: '6px'
                    }}
                  >
                    Test DB Connection
                  </button>
                  <button 
                    className="btn-save-settings" 
                    onClick={handleSaveDbSettings}
                  >
                    Save
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
        )}
      </div>
    </div>
  );
}

/* ── Standalone User Details Form Fill View ── */
function FormFillView({ nodeId, requestId }) {
  const [name, setName] = useState('');
  const [state, setState] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [motherName, setMotherName] = useState('');
  const [fatherName, setFatherName] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  // Node configuration state loaded from localStorage
  const [nodeData, setNodeData] = useState(null);

  useEffect(() => {
    const data = localStorage.getItem(`node_data_${nodeId}`);
    if (data) {
      try {
        setNodeData(JSON.parse(data));
      } catch {}
    }
  }, [nodeId]);

  const formSource = nodeData?.formSource || 'builtin'; // 'builtin' | 'pdf' | 'custom'

  // OCR Upload states
  const [pdfFile, setPdfFile] = useState(null); // { name, size, data }
  const [isExtracting, setIsExtracting] = useState(false);
  const [extractionProgress, setExtractionProgress] = useState(0);
  const [extractionStep, setExtractionStep] = useState('');

  const submitFormPayload = (formDataPayload) => {
    // Post message to parent window if opener is still available
    if (window.opener) {
      window.opener.postMessage({
        type: 'FORM_SUBMITTED',
        nodeId,
        requestId,
        formData: formDataPayload
      }, '*');
    }

    // Always write to localStorage as a robust fallback/focus sync
    localStorage.setItem(`form_fill_${nodeId}`, JSON.stringify({
      requestId,
      formData: formDataPayload,
      timestamp: Date.now()
    }));

    setSubmitted(true);
    setError('');

    setTimeout(() => {
      window.close();
    }, 1500);
  };

  const handlePdfUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (file.type !== 'application/pdf') {
      setError('Please upload a valid PDF file.');
      return;
    }

    setError('');
    setIsExtracting(true);
    setExtractionProgress(0);
    setExtractionStep('Uploading PDF registration form...');

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64Data = event.target.result;

      // Simulated OCR steps
      let progress = 0;
      const interval = setInterval(() => {
        progress += 10;
        setExtractionProgress(progress);

        if (progress === 30) {
          setExtractionStep('Scanning PDF layout & structure...');
        } else if (progress === 60) {
          setExtractionStep('Running OCR field extraction...');
        } else if (progress === 80) {
          setExtractionStep('Validating extracted fields...');
        } else if (progress === 100) {
          clearInterval(interval);
          setExtractionStep('OCR successfully extracted registration details!');
          
          const nameFromPdf = file.name.replace(/\.[^/.]+$/, "").replace(/[_-]/g, " ");
          const parsedName = nameFromPdf.replace(/\b\w/g, c => c.toUpperCase()) || 'Lakshmi Kiran';
          const parsedState = 'Andhra Pradesh';
          const parsedPhone = '+91 98765 43210';
          const parsedEmail = `${nameFromPdf.replace(/\s+/g, '.').toLowerCase()}@example.com`;
          const parsedMother = 'Savitri Devi';
          const parsedFather = 'Ramakrishna Rao';

          setName(parsedName);
          setState(parsedState);
          setPhone(parsedPhone);
          setEmail(parsedEmail);
          setMotherName(parsedMother);
          setFatherName(parsedFather);

          const pdfAttachment = {
            name: file.name,
            size: file.size,
            data: base64Data
          };
          setPdfFile(pdfAttachment);

          setTimeout(() => {
            setIsExtracting(false);
            
            // Auto submit if in PDF-only mode or Custom URL mode
            if (formSource === 'pdf' || formSource === 'custom') {
              const autoFormData = {
                name: parsedName,
                state: parsedState,
                phone: parsedPhone,
                email_id: parsedEmail,
                motherName: parsedMother,
                fatherName: parsedFather,
                attachments: [pdfAttachment]
              };
              submitFormPayload(autoFormData);
            }
          }, 800);
        }
      }, 200);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (formSource === 'custom') {
      try {
        const res = await fetch('http://localhost:3001/api/webhook/form/latest');
        const data = await res.json();
        
        if (data.success && data.submission?.data) {
          const ext = data.submission.data;
          const payload = ext.namedValues || ext;
          
          const customFormData = { attachments: [] };
          Object.keys(payload).forEach(key => {
             let val = payload[key];
             if (Array.isArray(val)) val = val[0];
             customFormData[key] = val;
          });

          submitFormPayload(customFormData);
        } else {
          setError('No submission found yet. Please submit the form first.');
        }
      } catch (err) {
        setError('Failed to fetch from backend webhook. Is the server running?');
      }
      return;
    }

    if (!name.trim() || !state.trim() || !phone.trim() || !email.trim() || !motherName.trim() || !fatherName.trim()) {
      setError('Please fill in all the details.');
      return;
    }

    const nameRegex = /^[A-Za-z\s\.]{2,50}$/;
    const phoneRegex = /^\+?[\d\s-]{10,15}$/;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!nameRegex.test(name.trim())) {
      setError('Please enter a valid name (letters and spaces only).');
      return;
    }
    if (!nameRegex.test(state.trim())) {
      setError('Please enter a valid state (letters and spaces only).');
      return;
    }
    if (!phoneRegex.test(phone.trim().replace(/[-\s]/g, ''))) {
      setError('Please enter a valid phone number (10-15 digits).');
      return;
    }
    if (!emailRegex.test(email.trim())) {
      setError('Please enter a valid email address.');
      return;
    }
    if (!nameRegex.test(motherName.trim())) {
      setError("Please enter a valid mother's name.");
      return;
    }
    if (!nameRegex.test(fatherName.trim())) {
      setError("Please enter a valid father's name.");
      return;
    }

    const formData = { 
      name, 
      state, 
      phone, 
      email_id: email, 
      motherName, 
      fatherName,
      attachments: pdfFile ? [pdfFile] : []
    };

    submitFormPayload(formData);
  };

  if (submitted) {
    return (
      <div className="form-fill-container submitted">
        <div className="form-fill-card success-card">
          <div className="success-icon-wrap">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#22c55e" strokeWidth="2.5">
              <polyline points="20 6 9 17 4 12" />
            </svg>
          </div>
          <h2>Details Attached!</h2>
          <p>The form has been successfully linked to the workflow.</p>
          <p className="subtext">This window will close automatically...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="form-fill-container">
      <div className="form-fill-card">
        <div className="form-fill-header">
          <div className="form-fill-logo">📋</div>
          <h2>
            {formSource === 'custom' ? 'External Form Link' : 
             formSource === 'pdf' ? 'Upload Registration PDF' : 
             'User Details'}
          </h2>
          <div className="form-fill-req-id">Request ID: {requestId}</div>
        </div>
        <form onSubmit={handleSubmit} className="form-fill-body">
          {error && <div className="form-fill-error">{error}</div>}

          {/* 1. Custom URL Mode: Link CTA for external forms */}
          {formSource === 'custom' && nodeData?.customUrl && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '14px', width: '100%', padding: '10px 0' }}>
              <div style={{
                background: 'rgba(59, 130, 246, 0.05)',
                border: '1px solid rgba(59, 130, 246, 0.3)',
                borderRadius: '8px',
                padding: '16px 18px',
                textAlign: 'left'
              }}>
                <div style={{ fontSize: '11px', color: '#60a5fa', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>Fill External Form</div>
                <p style={{ fontSize: '13px', color: 'var(--text-secondary)', margin: '6px 0 14px 0', lineHeight: '1.5' }}>
                  Please open the link below to complete the details in the external form. Once submitted there, click the button below to continue the workflow.
                </p>
                <a 
                  href={nodeData.customUrl} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '8px',
                    background: 'linear-gradient(135deg, #3b82f6, #1d4ed8)',
                    color: 'white',
                    textDecoration: 'none',
                    fontSize: '13px',
                    fontWeight: 600,
                    padding: '10px 18px',
                    borderRadius: '6px',
                    boxShadow: '0 2px 4px rgba(59, 130, 246, 0.2)'
                  }}
                >
                  🔗 Open External Form URL
                </a>
              </div>

              <div style={{ display: 'flex', gap: '10px' }}>
                <button
                  type="button"
                  className="form-fill-cancel-btn"
                  onClick={() => { window.close(); }}
                  style={{
                    flex: '0 0 auto',
                    padding: '12px 20px',
                    background: 'transparent',
                    border: '1px solid var(--border)',
                    borderRadius: '8px',
                    color: 'var(--text-secondary)',
                    fontSize: '14px',
                    fontWeight: 600,
                    cursor: 'pointer',
                    transition: 'all 0.2s ease'
                  }}
                >
                  Cancel
                </button>
                <button type="submit" className="form-fill-submit-btn" style={{ flex: 1, background: 'linear-gradient(135deg, #10b981, #059669)' }}>
                  Mark as Completed
                </button>
              </div>
            </div>
          )}

          {/* 2. PDF OCR Mode: Drag & Drop zone only, submits automatically */}
          {formSource === 'pdf' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', width: '100%', padding: '10px 0' }}>
              <div className="form-fill-group ocr-dropzone" style={{
                background: 'rgba(124, 58, 237, 0.05)',
                border: '1.5px dashed rgba(124, 58, 237, 0.4)',
                borderRadius: '10px',
                padding: '30px 20px',
                textAlign: 'center',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: '12px',
                transition: 'all 0.2s ease',
                position: 'relative'
              }}>
                {isExtracting ? (
                  <div style={{ width: '100%', padding: '10px 0' }}>
                    <div style={{ fontSize: '13px', color: '#a78bfa', fontWeight: 600, marginBottom: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}>
                      <span style={{ animation: 'spin 1.5s linear infinite', display: 'inline-block' }}>⏳</span> {extractionStep}
                    </div>
                    <div style={{ width: '100%', height: '6px', background: 'rgba(255,255,255,0.08)', borderRadius: '3px', overflow: 'hidden' }}>
                      <div style={{ width: `${extractionProgress}%`, height: '100%', background: 'linear-gradient(90deg, #7c3aed, #2dd4bf)', transition: 'width 0.15s ease-out' }}></div>
                    </div>
                    <div style={{ fontSize: '11px', color: 'var(--text-muted)', marginTop: '6px', textAlign: 'right' }}>
                      {extractionProgress}%
                    </div>
                  </div>
                ) : pdfFile ? (
                  <div style={{ width: '100%', padding: '10px 0', textAlign: 'center' }}>
                    <div style={{ fontSize: '32px', marginBottom: '8px' }}>🎉</div>
                    <div style={{ fontSize: '14px', color: '#10b981', fontWeight: 600 }}>OCR Parsing Complete!</div>
                    <div style={{ fontSize: '12px', color: 'var(--text-muted)', marginTop: '4px' }}>Submitting form details automatically...</div>
                  </div>
                ) : (
                  <>
                    <div style={{ fontSize: '32px' }}>📤</div>
                    <div style={{ fontSize: '14px', color: 'var(--text-primary)', fontWeight: 600 }}>Upload Registration PDF</div>
                    <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>We'll automatically extract all details and link them!</div>
                    <label className="file-upload-label" style={{
                      background: 'linear-gradient(135deg, #7c3aed, #2563eb)',
                      color: 'white',
                      padding: '8px 18px',
                      borderRadius: '6px',
                      fontSize: '12px',
                      fontWeight: 600,
                      cursor: 'pointer',
                      marginTop: '6px',
                      boxShadow: '0 2px 6px rgba(124, 58, 237, 0.3)'
                    }}>
                      Browse PDF File
                      <input 
                        type="file" 
                        accept=".pdf" 
                        onChange={handlePdfUpload} 
                        style={{ display: 'none' }} 
                      />
                    </label>
                  </>
                )}
              </div>
            </div>
          )}

          {/* 3. Manual Entry Mode: Input text fields only */}
          {formSource === 'builtin' && (
            <>
              <div className="form-fill-group">
                <label>Full Name</label>
                <input 
                  type="text" 
                  placeholder="e.g. Lakshmi Kiran" 
                  value={name} 
                  onChange={e => setName(e.target.value)} 
                  required
                />
              </div>

              <div className="form-fill-group">
                <label>State</label>
                <input 
                  type="text" 
                  placeholder="e.g. Andhra Pradesh" 
                  value={state} 
                  onChange={e => setState(e.target.value)} 
                  required
                />
              </div>

              <div className="form-fill-group">
                <label>Phone Number</label>
                <input 
                  type="tel" 
                  placeholder="e.g. +91 98765 43210" 
                  value={phone} 
                  onChange={e => setPhone(e.target.value)} 
                  required
                />
              </div>

              <div className="form-fill-group">
                <label>Email ID</label>
                <input 
                  type="email" 
                  placeholder="e.g. lakshmi.kiran@example.com" 
                  value={email} 
                  onChange={e => setEmail(e.target.value)} 
                  required
                />
              </div>

              <div className="form-fill-group">
                <label>Mother's Name</label>
                <input 
                  type="text" 
                  placeholder="Full Name" 
                  value={motherName} 
                  onChange={e => setMotherName(e.target.value)} 
                  required
                />
              </div>

              <div className="form-fill-group">
                <label>Father's Name</label>
                <input 
                  type="text" 
                  placeholder="Full Name" 
                  value={fatherName} 
                  onChange={e => setFatherName(e.target.value)} 
                  required
                />
              </div>

              <div style={{ display: 'flex', gap: '10px', marginTop: '12px' }}>
                <button
                  type="button"
                  className="form-fill-cancel-btn"
                  onClick={() => { window.close(); }}
                  style={{
                    flex: '0 0 auto',
                    padding: '12px 20px',
                    background: 'transparent',
                    border: '1px solid var(--border)',
                    borderRadius: '8px',
                    color: 'var(--text-secondary)',
                    fontSize: '14px',
                    fontWeight: 600,
                    cursor: 'pointer',
                    transition: 'all 0.2s ease'
                  }}
                >
                  Cancel
                </button>
                <button type="submit" className="form-fill-submit-btn" style={{ flex: 1 }}>
                  Submit & Attach Details
                </button>
              </div>
            </>
          )}
        </form>
      </div>
    </div>
  );
}

